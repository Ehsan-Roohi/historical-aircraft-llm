"""Read-only targeted review: render supplied notes without changing the PDF."""
from pathlib import Path
import argparse
import pypdfium2 as pdfium
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--pages', nargs='*', type=int)
args = parser.parse_args()
doc = pdfium.PdfDocument(r'C:/Users/roohie/Downloads/Telegram Desktop/Malaek design Notes(Complete Edition).pdf')
out = ROOT/'tmp/pdfs/malaek'; out.mkdir(exist_ok=True)
pages = args.pages or list(range(1, 174, 10))
for number in pages:
    doc[number-1].render(scale=1.25 if args.pages else .8).to_pil().convert('RGB').save(out/f'page-{number:03d}.png')
if not args.pages:
    for start in range(0, len(pages), 6):
        sheet = Image.new('RGB', (1500, 2100), '#ddd')
        draw = ImageDraw.Draw(sheet)
        for i, number in enumerate(pages[start:start+6]):
            im = Image.open(out/f'page-{number:03d}.png'); im.thumbnail((730, 650))
            x=(i%2)*750; y=(i//2)*700
            sheet.paste(im,(x,y+30)); draw.text((x+5,y+5),str(number),fill='black')
        sheet.save(out/f'overview-{start:02d}.png')
print('Rendered', pages, 'of',len(doc))
