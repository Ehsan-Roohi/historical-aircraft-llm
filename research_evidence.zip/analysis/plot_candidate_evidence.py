"""Render a source-driven evidence flow, not a flight-success comparison.

SVG retains text; PNG is a 300-dpi print preview. No font files are distributed.
"""
import hashlib
import json
from html import escape
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'analysis/results/trim_power_necessity_v1.json'
OUT = ROOT / 'output/figures'
W, H = 900, 570
SCALE = 180 / 25.4 * 300 / W


def main():
    data = json.loads(SOURCE.read_bytes())
    summaries = data['summary']
    # Recount source cases instead of trusting aggregate labels alone.
    for model, summary in summaries.items():
        cases = [c for c in data['cases'] if c['model'] == model]
        candidates = [p for c in cases for p in c['candidate_checks']]
        assert len(cases) == summary['scenario_count']
        assert len(candidates) == summary['candidate_count']
        assert sum(not c['candidate_checks'] for c in cases) == summary['scenarios_without_candidate']
        for label, count in summary['conditional_classification_counts'].items():
            assert sum(p['conditional_classification'] == label for p in candidates) == count
        assert sum(bool(p['mechanical_conflict_witness']) for p in candidates) == summary['mechanical_conflict_witness_count']
    OUT.mkdir(parents=True, exist_ok=True)
    image = Image.new('RGB', (round(W*SCALE), round(H*SCALE)), 'white')
    draw = ImageDraw.Draw(image)
    svg = [f'<svg xmlns="http://www.w3.org/2000/svg" width="180mm" height="114mm" viewBox="0 0 {W} {H}">',
           '<title>Conditional trim candidates and identified constraints</title>',
           '<desc>Counts describe hypothetical scenarios, not flight probabilities. Power targets are unverified. All Fable candidates have an interference witness.</desc>',
           '<rect width="900" height="570" fill="white"/>']
    text_boxes = []

    def text(x, y, value, size=18, bold=False, color='#222222'):
        font = ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf' if bold else 'C:/Windows/Fonts/arial.ttf', round(size*SCALE))
        box = draw.textbbox((x*SCALE, y*SCALE), value, font=font, anchor='lt')
        assert box[2] <= W*SCALE-12 and box[3] <= H*SCALE-12, value
        draw.text((x*SCALE, y*SCALE), value, font=font, fill=color, anchor='lt')
        svg.append(f'<text x="{x}" y="{y+size*.8}" font-family="Arial, Helvetica, sans-serif" font-size="{size}" font-weight="{700 if bold else 400}" fill="{color}">{escape(value)}</text>')
        text_boxes.append({'text': value, 'size_pt_at_180mm': size*180/W*72/25.4})

    def rect(x,y,w,h,fill):
        draw.rectangle((x*SCALE,y*SCALE,(x+w)*SCALE,(y+h)*SCALE),fill=fill,outline='#b7bec5',width=2)
        svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="#b7bec5"/>')

    text(28,22,'Conditional trim: what the checks establish',25,True)
    text(28,59,'Three clarified designs; hypothetical drag and moment scenarios',18)
    text(28,105,'DESIGN / SCENARIOS',17,True)
    text(262,105,'TRIM CANDIDATES',17,True)
    text(501,105,'IDENTIFIED CONSTRAINTS',17,True)
    for i, model in enumerate(('astra','fable','opus')):
        row = summaries[model]
        y = 141+i*113
        rect(28,y,206,96,'#f4f6f8')
        rect(262,y,210,96,'#f4f6f8')
        rect(501,y,371,96,'#ffffff')
        text(42,y+14,model.title()+' V1',22,True)
        text(42,y+51,f"{row['scenario_count']} scenarios",18)
        text(278,y+14,f"{row['candidate_count']} candidates",22,True)
        text(278,y+51,f"{row['scenarios_without_candidate']} without a root",18)
        for x in (239,477):
            text(x,y+33,'›',23,True)
        if model == 'fable':
            text(517,y+14,f"{row['mechanical_conflict_witness_count']} interference witnesses",20,True,color='#9b4500')
            text(517,y+49,'Available power unknown',18)
        else:
            counts = row['conditional_classification_counts']
            text(517,y+14,f"{counts['useful_power_exceeds_target']} exceed power target",20,True,color='#9b4500')
            text(517,y+49,f"{counts['not_excluded_by_available_checks']} not excluded by these checks",18)
    text(28,494,'Not excluded does not mean feasible.',20,True)
    text(28,525,'Counts are not probabilities or rankings. Engine targets are unverified.',18)
    svg.append('</svg>')
    (OUT/'candidate_evidence_v1.svg').write_text('\n'.join(svg),encoding='utf-8')
    image.save(OUT/'candidate_evidence_v1.png',dpi=(300,300))
    image.resize((900,570),Image.Resampling.LANCZOS).save(OUT/'candidate_evidence_v1_preview.png')
    manifest = {'source':str(SOURCE.relative_to(ROOT)), 'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
                'print_width_mm':180,'print_height_mm':114,'png_dpi':300,
                'font':'Arial; SVG fallback Helvetica, sans-serif; not embedded',
                'minimum_font_pt':min(t['size_pt_at_180mm'] for t in text_boxes),
                'counts_rechecked_against_cases':True,'text':text_boxes,
                'scope':'Scenario-specific evidence flow. No probability, ranking, or demonstrated flight claim.'}
    (OUT/'candidate_evidence_v1_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in manifest.items() if k != 'text'},indent=2))


if __name__ == '__main__':
    main()
