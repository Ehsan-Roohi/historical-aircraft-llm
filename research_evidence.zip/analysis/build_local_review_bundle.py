"""Create a private local review snapshot; no upload, solver or API execution."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT=Path(__file__).resolve().parents[1]
README='''# Aircraft comparison local review snapshot

Start with paper/engineering_decision_v1.md (Persian decision summary),
paper/technical_assessment_v1.md (technical report), and
paper/manuscript_draft_v1.md (English manuscript draft).

This is a PRIVATE LOCAL review package, not a public-release license grant.
It contains acquired third-party papers, drawings, coordinate data and the
archived solver executable for provenance. Their redistribution rights have
not been cleared. Do not publish this ZIP as a public supplement without a
file-by-file rights review. Font binaries are not included.

The study evaluates three frozen design artifacts, not model superiority.
Neither controlled flight nor superiority to the 1903 Wright Flyer is proven.
Preserve conditional exclusions, unknowns, original versions and failed runs.
The Word/PDF journal-format deliverable is not included or certified.

Folders
- analysis: scripts, inputs, archived selected and failed solver attempts,
  raw model records, sources and derived results.
- paper: manuscript, technical reports and provenance/validation records.
- received_2026-09-24/astra_fable_opus_designs: original supplied artifacts.
- unity_jobs/run_geometry_clarifications.py: source provenance only; do not
  execute it as part of reproduction (it is an external model API runner).
- aircraft_llm_prior_work: bounded literature-review outline and fields.
- output/figures: current Wright and fixed-control response figures.
- output/figure_svg_qa: independent vector-render QA manifest only.
- output/reproduction/postprocessing_attempt10: summary, input manifest,
  and run logs, not its duplicate workspace or archived-comparator trees.

Reproduction
Read paper/postprocessing_reproduction_v1.md. The verified attempt10 is a
same-host postprocessing replay, not a new solver or experimental run.
Python 3.14.7 was used for analysis; figure generation used Python 3.12.14
and Pillow 12.3.0. The current figure generator expects Windows Arial at
C:/Windows/Fonts/arial.ttf. The summary records font hashes; fonts are
external dependencies. The absolute interpreter path in the example command
must be replaced on another machine. Do not infer cross-platform validation.
Use a fresh output directory when replaying. No model API or Unity job is
needed for the documented postprocessing command.

MANIFEST.json lists SHA-256 and size for every payload file, including this
README. It does not recursively hash itself. verification.json beside the
ZIP records archive integrity and membership checks. These checks validate
the snapshot, not the scientific claims or publication permissions.
'''


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    out=args.output.resolve()
    if not out.is_relative_to((ROOT/'output/delivery').resolve()):
        raise ValueError('Destination must be under project output/delivery')
    if out.exists():
        raise ValueError('Use a new snapshot directory')
    selected=[]
    for rel in ('analysis','paper','aircraft_llm_prior_work','received_2026-09-24/astra_fable_opus_designs'):
        selected.extend(p for p in (ROOT/rel).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
    selected.append(ROOT/'unity_jobs/run_geometry_clarifications.py')
    selected.extend((ROOT/'output/figures').glob('wright_response_v1*'))
    selected.extend((ROOT/'output/figures').glob('fixed_control_response_v1*'))
    selected.append(ROOT/'output/figure_svg_qa/render_manifest.json')
    selected.extend(p for p in (ROOT/'output/reproduction/postprocessing_attempt10').iterdir() if p.is_file())
    selected=sorted(set(selected))
    payload={}
    suspicious=[]
    # A limited preflight, deliberately not represented as a comprehensive secret audit.
    patterns=[rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
              rb'\bAKIA[A-Z0-9]{16}\b',rb'\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{32,}\b']
    for p in selected:
        if p.is_symlink() or not p.resolve().is_relative_to(ROOT.resolve()):
            raise ValueError('Symlink or external target refused')
        rel=p.relative_to(ROOT).as_posix()
        raw=p.read_bytes()
        if p.suffix.lower() in ('.py','.json','.jsonl','.txt','.md','.toml','.yaml','.yml','.env'):
            if any(re.search(pattern,raw) for pattern in patterns):
                suspicious.append(rel)
        if p.name.lower() in ('.env','credentials','credentials.json'):
            suspicious.append(rel)
        payload[rel]=raw
    if suspicious:
        raise ValueError('Credential-like content requires review; paths only: '+', '.join(sorted(set(suspicious))))
    payload['README.md']=README.encode('utf-8')
    manifest={'scope':'Private local review snapshot; not public redistribution clearance',
              'files':{rel:{'sha256':sha(raw),'bytes':len(raw)} for rel,raw in sorted(payload.items())},
              'excluded':['Prior delivery bundles','Reproduction duplicate workspaces and comparator copies',
                          'Superseded figure binaries in output/figures','Font binaries','Python bytecode'],
              'secret_preflight':'Limited filename and credential-signature scan; no comprehensive assurance'}
    raw_manifest=(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
    out.mkdir(parents=True,exist_ok=False)
    (out/'MANIFEST.json').write_bytes(raw_manifest)
    (out/'README.md').write_text(README,encoding='utf-8')
    archive=out/'aircraft_local_review_v1.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for rel,raw in sorted(payload.items()):
            z.writestr(rel,raw)
        z.writestr('MANIFEST.json',raw_manifest)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert set(z.namelist())==set(payload)|{'MANIFEST.json'}
        assert len(z.namelist())==len(payload)+1
        for rel,raw in payload.items():
            assert z.read(rel)==raw,rel
        assert z.read('MANIFEST.json')==raw_manifest
    result={'archive':archive.name,'archive_sha256':sha(archive.read_bytes()),
            'archive_bytes':archive.stat().st_size,'payload_file_count':len(payload),
            'payload_bytes':sum(map(len,payload.values())),
            'manifest_sha256':sha(raw_manifest),'all_payload_bytes_verified':True,
            'crc_pass':True,'no_duplicate_or_extra_entries':True,
            'source_files_modified':False,'uploaded':False,
            'limits':['No clean-machine execution','No rights clearance','No comprehensive secret audit','No new physics validation']}
    (out/'verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
