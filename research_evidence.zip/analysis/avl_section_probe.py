"""Bounded synthetic-wing input probe. NOT a Wright aircraft calculation."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
from avl_reference_gate import EXE, parse
from audit_eiffel10 import EXPECTED

ROOT=Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def geometry(nc,ns,section):
    rows=['Synthetic AR10 section-input probe','0','0 0 0','10 1 10','.25 0 0','0',
          'SURFACE','wing',f'{nc} 1 {ns} 1','YDUPLICATE','0']
    for y in [0,5]:
        rows+=['SECTION',f'0 {y} 0 1 0']
        if section=='eiffel10_raw': rows+=['AFILE','section.dat']
    return '\n'.join(rows)+'\n'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    source=ROOT/'analysis/references/eiffel10_uiuc.dat'
    if sha(source)!=EXPECTED: raise ValueError('Unexpected source section')
    out=args.output.resolve(); out.mkdir(parents=True,exist_ok=False)
    records=[]
    for section in ['flat','eiffel10_raw']:
        for nc,ns in [(4,20),(8,40)]:
            for alpha in [0,4]:
                tag=f'{section}_c{nc}_s{ns}_a{alpha}'
                case=out/tag; case.mkdir()
                (case/'wing.avl').write_text(geometry(nc,ns,section),encoding='ascii')
                if section!='flat': (case/'section.dat').write_bytes(source.read_bytes())
                commands=f'load wing.avl\noper\na a {alpha}\nx\nft\nforces.txt\n\nquit\n'
                (case/'commands.txt').write_text(commands,encoding='ascii')
                row={'case':tag,'section':section,'nc':nc,'ns_half':ns,'requested_alpha_deg':alpha,
                     'geometry_sha256':sha(case/'wing.avl'),'commands_sha256':sha(case/'commands.txt')}
                try:
                    proc=subprocess.run([str(EXE)],cwd=case,input=commands,capture_output=True,text=True,
                                        timeout=25,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                    (case/'stdout.txt').write_text(proc.stdout,encoding='utf-8')
                    (case/'stderr.txt').write_text(proc.stderr,encoding='utf-8')
                    row['returncode']=proc.returncode
                    if proc.returncode!=0: raise RuntimeError('Nonzero AVL exit')
                    force=case/'forces.txt'; text=force.read_text()
                    row['forces_sha256']=sha(force)
                    row['coefficients']={k:parse(text,k) for k in ['Alpha','Beta','Mach','CLtot','CDind','Cmtot','Cltot','CYtot']}
                    if abs(row['coefficients']['Alpha']-alpha)>1e-6 or any(abs(row['coefficients'][k])>1e-6 for k in ['Beta','Mach']):
                        raise ValueError('Reported condition differs from request')
                    row['status']='completed'
                except subprocess.TimeoutExpired as exc:
                    row['status']='timed_out'
                    for label,value in [('stdout',exc.stdout),('stderr',exc.stderr)]:
                        if value:
                            (case/(label+'.partial.txt')).write_bytes(value if isinstance(value,bytes) else value.encode('utf-8'))
                except Exception as exc:
                    row.update(status='failed',error=str(exc))
                records.append(row)
                print(tag,row['status'],row.get('coefficients'),flush=True)
                result={'scope':__doc__,'solver_sha256':sha(EXE),'section_source_sha256':sha(source),
                        'moment_reference':'quarter chord of synthetic rectangular wing; x=.25 m',
                        'records':records,'complete':len(records)==8 and all(r['status']=='completed' for r in records)}
                (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    if not result['complete']: raise SystemExit(1)


if __name__=='__main__': main()
