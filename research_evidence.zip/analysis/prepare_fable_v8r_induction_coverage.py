#!/usr/bin/env python3
"""Freeze lower-angle V8-R root section coverage for a coupled-flow screen."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
PARENT=ROOT/'analysis/results/fable_v8r_root_inputs01'
OUT=ROOT/'analysis/results/fable_v8r_induction_inputs01'
ANGLES=(-2,0,1,2,3,4,5,6,7)
DENSITIES=(80,120,160)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    source=PARENT/'manifest.json'
    parent=json.loads(source.read_text())
    if parent['stage']!='fable_v8r_root_numerical_screen' or parent['densities']!=list(DENSITIES):
        raise ValueError('Unexpected V8-R root input')
    if OUT.exists():
        raise FileExistsError(OUT)
    OUT.mkdir(parents=True)
    for section in parent['sections']:
        path=PARENT/section['file']
        if sha(path)!=section['sha256']:
            raise ValueError('Parent contour changed')
        (OUT/section['file']).write_bytes(path.read_bytes())
    manifest={**parent,'stage':'fable_v8r_root_induction_coverage',
              'parent_manifest_sha256':sha(source),'angles_deg':list(ANGLES),
              'interpretation':'Lower-angle 2D root screen for frozen-Re coupled-flow research; not validated propeller data'}
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'cases':len(DENSITIES)*len(ANGLES),'parent_manifest_sha256':sha(source)}))

if __name__=='__main__':
    main()
