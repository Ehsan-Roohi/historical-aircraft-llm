"""Bounded local alpha probes at frozen conditional control settings, not dynamic stability."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import subprocess
from avl_aircraft_pilot import ROOT, EXE
from avl_control_probe import controlled_geometry
from avl_reference_gate import parse
from audit_mass_tables import summarize


def slopes(values, h):
    return {key:(values[str(4+h)][key]-values[str(4-h)][key])/(2*h)
            for key in ['CLtot','CDind','Cmtot']}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--models',nargs='+',choices=['astra','opus'],default=['astra','opus'])
    parser.add_argument('--fine-only',action='store_true')
    parser.add_argument('--timeout-seconds',type=int,default=180)
    args=parser.parse_args()
    if not 1 <= args.timeout_seconds <= 300: raise ValueError('Timeout must be 1..300 seconds')
    out=args.output.resolve(); out.mkdir(parents=True,exist_ok=False)
    (out/'runner_snapshot.py').write_bytes(Path(__file__).read_bytes())
    source=ROOT/'analysis/results/trim_control_grid_v1.json'
    source_data=json.loads(source.read_text())
    moment_file=ROOT/'analysis/results/longitudinal_geometry_v1.json'
    moments=json.loads(moment_file.read_text())
    records=[]
    for model,attempt in [('astra','01'),('opus','03')]:
        if model not in args.models: continue
        case,=[r for r in source_data['cases'] if r['model']==model and r['alpha_deg']==4 and r['added_CD']==.05 and r['added_drag_moment_arm_m']==0]
        candidate,=case['candidates']
        mass=summarize(json.loads((ROOT/f'analysis/{model}_v1_extracted.json').read_text(encoding='utf-8')))['mass_kg']
        arm=moments[model.upper()+'-V1']['pitch_coefficient_per_N_forward_thrust']
        for nc,ns in ([(12,80)] if args.fine_only else [(8,40),(12,80)]):
            work=out/f'{model}_c{nc}_s{ns}'; work.mkdir()
            geom=controlled_geometry(model,nc,ns)
            (work/'aircraft.avl').write_text(geom,encoding='ascii')
            foil=ROOT/f'analysis/results/avl_aircraft_pilot{attempt}/{model}_c8_s40_a4/section.dat'
            (work/'section.dat').write_bytes(foil.read_bytes())
            alphas=[3.5,3.75,4.0,4.25,4.5]
            command=f"load aircraft.avl\noper\nd1 d1 {candidate['control_deg']:.12f}\n"
            for i,a in enumerate(alphas): command+=f'a a {a}\nx\nft\nforces_{i}.txt\n'
            command+='\nquit\n'
            (work/'commands.txt').write_text(command,encoding='ascii')
            try:
                proc=subprocess.run([str(EXE)],input=command,cwd=work,capture_output=True,text=True,timeout=args.timeout_seconds,
                                    creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            except subprocess.TimeoutExpired as error:
                for label in ['stdout','stderr']:
                    value=getattr(error,label) or b''
                    if isinstance(value,bytes): value=value.decode(errors='replace')
                    (work/(label+'.txt')).write_text(value,encoding='utf-8')
                (work/'timeout.txt').write_text(str(error),encoding='utf-8')
                raise
            (work/'stdout.txt').write_text(proc.stdout,encoding='utf-8')
            (work/'stderr.txt').write_text(proc.stderr,encoding='utf-8')
            if proc.returncode: raise RuntimeError('AVL failed: '+work.name)
            values={str(a):{key:parse((work/f'forces_{i}.txt').read_text(),key) for key in ['CLtot','CDind','Cmtot']} for i,a in enumerate(alphas)}
            area,chord,_=map(float,geom.splitlines()[3].split())
            qS=.5*1.225*candidate['speed_m_s']**2*area
            center=values['4.0']; thrust=candidate['thrust_N']; a=math.radians(4)
            residual={'horizontal_N':thrust*math.cos(a)-qS*(center['CDind']+.05),
                      'vertical_N':qS*center['CLtot']+thrust*math.sin(a)-mass*9.80665,
                      'pitch_Nm':qS*chord*center['Cmtot']+arm*thrust}
            record={'model':model,'nc':nc,'ns':ns,'frozen_candidate':candidate,'values':values,
                    'slope_per_degree_h0_5':slopes(values,.5),'slope_per_degree_h0_25':slopes(values,.25),
                    'center_residual_at_original_candidate':residual,
                    'geometry_sha256':hashlib.sha256((work/'aircraft.avl').read_bytes()).hexdigest(),
                    'foil_sha256':hashlib.sha256(foil.read_bytes()).hexdigest(),
                    'force_sha256':{f'forces_{i}.txt':hashlib.sha256((work/f'forces_{i}.txt').read_bytes()).hexdigest() for i in range(5)}}
            records.append(record)
            result={'scope':'Fixed-control attached-flow aerodynamic alpha slopes at conditional candidate settings; NOT verified physical trim or dynamic modes',
                    'selection':'alpha 4 deg, added CD .05, added drag arm 0; Fable excluded because selected setting intersects fin',
                    'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
                    'process_timeout_seconds':args.timeout_seconds,
                    'moment_input_sha256':hashlib.sha256(moment_file.read_bytes()).hexdigest(),
                    'solver_sha256':hashlib.sha256(EXE.read_bytes()).hexdigest(),'records':records}
            (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
            print(json.dumps({'model':model,'nc':nc,'slope':record['slope_per_degree_h0_25'],'center_residual':residual}),flush=True)


if __name__=='__main__': main()
