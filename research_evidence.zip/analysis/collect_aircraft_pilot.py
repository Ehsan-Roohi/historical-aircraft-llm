"""Collect only explicitly selected, completed pilot cases; reject missing outputs."""
import hashlib
import json
from pathlib import Path
from avl_reference_gate import parse

ROOT=Path(__file__).resolve().parents[1]


def main():
    collected=[]
    comparisons=[]
    for model,attempt in [('astra','avl_aircraft_pilot01'),('fable','avl_aircraft_pilot03'),('opus','avl_aircraft_pilot03')]:
        for nc,ns in [(8,40),(12,80)]:
            for alpha in [0,4,8]:
                case=ROOT/f'analysis/results/{attempt}/{model}_c{nc}_s{ns}_a{alpha}'
                ft=case/'forces.txt'
                if not ft.is_file():
                    raise FileNotFoundError(f'Required completed case missing: {case}')
                text=ft.read_text()
                row={'model':model,'nc':nc,'ns_wing_half':ns,'alpha_deg':alpha,'case':str(case.relative_to(ROOT)),
                     'force_file_sha256':hashlib.sha256(ft.read_bytes()).hexdigest(),
                     'geometry_sha256':hashlib.sha256((case/'aircraft.avl').read_bytes()).hexdigest()}
                row.update({k:parse(text,k) for k in ['CLtot','CDind','Cmtot']})
                collected.append(row)
        for alpha in [0,4,8]:
            pair=[r for r in collected if r['model']==model and r['alpha_deg']==alpha]
            coarse,fine=pair
            comparisons.append({'model':model,'alpha_deg':alpha,
                                'CL_change_pct':100*(fine['CLtot']/coarse['CLtot']-1),
                                'CDind_change_pct':100*(fine['CDind']/coarse['CDind']-1),
                                'Cm_change_absolute':fine['Cmtot']-coarse['Cmtot']})
    result={'scope':'Unvalidated neutral-control idealized lifting surfaces, NOT powered trim or full-aircraft performance','records':collected,'mesh_changes':comparisons}
    (ROOT/'analysis/results/aircraft_pilot_selected_v1.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'fine_mesh':[r for r in collected if r['nc']==12],'mesh_changes':comparisons},indent=2))


if __name__=='__main__':
    main()
