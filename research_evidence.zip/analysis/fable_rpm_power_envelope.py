#!/usr/bin/env python3
"""Conditional RPM sweep for the Fable V3b/V5 two-by-two propeller proposal.

This is a sensitivity of frozen-Re, two-dimensional numerical polars, not an
engine/propeller operating-point match or an aircraft-flight prediction.
"""
import json
import math
from pathlib import Path

from fable_axial_induction_screen import (
    MANIFEST, OLD, OUT as BASE_OUT, PROPELLERS, ROOT, ROOT_ROWS, V,
    integrate, sha, solve_station,
)

OUT=ROOT/'analysis/results/fable_rpm_power_envelope01.json'
DRIVE=0.95
MODEL_ENGINE_TARGET_W=10700.0


def section_inputs(density=120):
    manifest=json.loads(MANIFEST.read_text())
    root_records=json.loads(ROOT_ROWS.read_text())
    pairs=[]
    for station in manifest['stations']:
        if station['family']!='fable':
            continue
        if station['radius_m']==.12:
            rows=[row for row in root_records
                  if row['geometry_file']==f'fable_v8r_r012_n{density}.dat']
        else:
            rows=[row for row in json.loads((OLD/station['stem']/'records.json').read_text())
                  if row['geometry_file']==f"{station['stem']}_n{density}.dat"]
        pairs.append((station,rows))
    if len(pairs)!=9:
        raise ValueError('Expected nine Fable stations')
    return pairs


def evaluate(rpm,pairs):
    omega=2*math.pi*rpm/60
    stations=[]
    for station,rows in pairs:
        try:
            value=solve_station(station,rows,2,omega)
            value['stem']=station['stem']
            stations.append(value)
        except ValueError as exc:
            return {'rpm_propeller':rpm,'status':'UNRESOLVED',
                    'first_failed_station':station['stem'],'reason':str(exc)}
    thrust=PROPELLERS*integrate(stations,'dTdr_N_m')
    shaft=PROPELLERS*omega*integrate(stations,'dQdr_Nm_m')
    ideal=PROPELLERS*integrate(stations,'dPdr_axial_ideal_W_m')
    return {'rpm_propeller':rpm,'rpm_engine_if_ratio_2':2*rpm,
            'status':'CONDITIONAL_NUMERICAL_SCREEN','T_all_propellers_N':thrust,
            'P_shaft_all_propellers_W':shaft,
            'P_engine_if_drive_095_W':shaft/DRIVE,
            'engine_target_minus_conditional_demand_W':MODEL_ENGINE_TARGET_W-shaft/DRIVE,
            'P_above_annular_axial_ideal_W':shaft-ideal,
            'max_polar_bracket_width_deg':max(s['polar_bracket_deg'][1]-s['polar_bracket_deg'][0] for s in stations),
            'max_frozen_Re_fractional_change':max(abs(s['Re_actual_at_induced_speed']/s['Re_frozen']-1) for s in stations),
            'stations':stations}


def linear_crossing(rows,key,target):
    """Return only an interpolation bracket, never an engine operating point."""
    valid=[row for row in rows if row['status']=='CONDITIONAL_NUMERICAL_SCREEN']
    for low,high in zip(valid,valid[1:]):
        if high['rpm_propeller']-low['rpm_propeller']!=10:
            continue
        a,b=low[key],high[key]
        if (a-target)*(b-target)<=0 and a!=b:
            fraction=(target-a)/(b-a)
            return {'rpm_linear_interpolation':low['rpm_propeller']+10*fraction,
                    'bracket_rpm':[low['rpm_propeller'],high['rpm_propeller']],
                    'other_quantity_at_interpolation':None}
    return None


def main():
    base=json.loads(BASE_OUT.read_text())
    if base['v3b_v5_model_proposed_blades_per_propeller']!=2:
        raise ValueError('Baseline blade-count provenance changed')
    pairs=section_inputs()
    rows=[evaluate(rpm,pairs) for rpm in range(500,701,10)]
    nominal=next(row for row in rows if row['rpm_propeller']==600)
    reference=base['results']['n120_b2']
    if nominal['status']!='CONDITIONAL_NUMERICAL_SCREEN' or abs(nominal['T_all_propellers_N']-reference['T_all_propellers_N'])>1e-8:
        raise ValueError('Sweep nominal point does not reproduce single-point gate')
    thrust_crossing=linear_crossing(rows,'T_all_propellers_N',412)
    power_crossing=linear_crossing(rows,'P_engine_if_drive_095_W',MODEL_ENGINE_TARGET_W)
    for crossing,other_key in ((thrust_crossing,'P_engine_if_drive_095_W'),
                               (power_crossing,'T_all_propellers_N')):
        if crossing is not None:
            low,high=(next(r for r in rows if r['rpm_propeller']==rpm)
                      for rpm in crossing['bracket_rpm'])
            fraction=(crossing['rpm_linear_interpolation']-low['rpm_propeller'])/10
            crossing['other_quantity_at_interpolation']=low[other_key]+fraction*(high[other_key]-low[other_key])
    out={'stage':'conditional_fable_fixed_V_rpm_power_envelope',
         'source_hashes':{'coupled_baseline':sha(BASE_OUT),'v5_manifest':sha(MANIFEST),'root_records':sha(ROOT_ROWS)},
         'conditions':{'V_m_s':V,'density_kg_m3':1.225,'blades_per_propeller':2,
                       'propeller_count':PROPELLERS,'drive_efficiency_assumed':DRIVE,
                       'model_engine_target_W_unverified':MODEL_ENGINE_TARGET_W,
                       'contour_density':120},
         'interpretation':'Rows are conditional polar-bracket screens. Model engine target is a scalar, not a torque curve; no running equilibrium or flight inference follows.',
         'rows':rows,'linear_interpolation_only':{
             'model_thrust_target_412_N':thrust_crossing,
             'model_engine_scalar_target_10700_W':power_crossing},
         'engine_map_available':False,'flight_conclusion':False}
    OUT.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps([{'rpm':r['rpm_propeller'],'status':r['status'],
                       'T_N':r.get('T_all_propellers_N'),
                       'P_engine_W':r.get('P_engine_if_drive_095_W'),
                       'failed_station':r.get('first_failed_station')}
                      for r in rows]))


if __name__=='__main__':
    main()
