// Render archived V0 artwork without redrawing or correcting its geometry.
const fs=require('node:fs'), path=require('node:path'), crypto=require('node:crypto');
const sharp=require('C:/Users/roohie/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const root=path.resolve(__dirname,'..'), out=path.join(root,'output','aircraft_atlas_v0');
async function main(){
 fs.mkdirSync(out,{recursive:true}); const records=[];
 for(const [label,folder] of [['astra','gpt-6-astra'],['fable','claude-fable-5-1'],['opus','claude-opus-5-5']]){
  for(const view of ['three_view','oblique']){
   const source=path.join(root,'received_2026-09-24','astra_fable_opus_designs',folder,view+'.svg');
   const bytes=fs.readFileSync(source), name=label+'_'+view+'_v0.png';
   await sharp(bytes,{density:180}).resize({width:3200}).png().toFile(path.join(out,name));
   await sharp(path.join(out,name)).resize({width:1100}).png().toFile(path.join(out,label+'_'+view+'_preview.png'));
   records.push({label,view,version:'V0 original model drawing; not corrected V1 geometry',source:path.relative(root,source),source_sha256:crypto.createHash('sha256').update(bytes).digest('hex'),png:name});
  }
 }
 fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify(records,null,2)+'\n');
 console.log(JSON.stringify({rendered:records.length,directory:out}));
}
main().catch(e=>{console.error(e);process.exitCode=1;});
