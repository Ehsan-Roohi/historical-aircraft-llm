"""Bounded local TeX build; retain diagnostics without remote submission."""
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
work=ROOT/'output/overleaf/aircraft_scientific_revision_v4'
exe=ROOT/'analysis/tools/tectonic/portable/tectonic.exe'
proc=subprocess.run([str(exe),'-X','compile','main.tex','--keep-logs','--keep-intermediates'],cwd=work,capture_output=True,timeout=180)
(work/'compile.stdout.txt').write_bytes(proc.stdout)
(work/'compile.stderr.txt').write_bytes(proc.stderr)
print('returncode',proc.returncode)
for line in (proc.stdout+proc.stderr).decode(errors='replace').splitlines():
    if 'error' in line.lower() or 'Overfull' in line or 'Writing' in line or 'warning:' in line:
        print(line[:500])
raise SystemExit(proc.returncode)
