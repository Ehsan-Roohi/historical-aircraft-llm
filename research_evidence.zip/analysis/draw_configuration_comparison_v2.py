"""Draw traceable lifting-surface geometry; never invent airframe members."""
from pathlib import Path
import hashlib
import json
from xml.sax.saxutils import escape

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/figures_v2'
OUT.mkdir(exist_ok=True)
paths=[
 ('Astra V1',ROOT/'analysis/results/avl_fixed_control_slope04/astra_c12_s80/aircraft.avl'),
 ('Fable V1',ROOT/'analysis/results/avl_control_grid01/fable/aircraft.avl'),
 ('Opus V1',ROOT/'analysis/results/avl_fixed_control_slope06/opus_c12_s80/aircraft.avl'),
 ('Wright reconstruction',ROOT/'analysis/results/wright_reconstruction_family01/flat_i-4_a0/wing.avl')]

def parse(path):
    lines=path.read_text().splitlines(); surfaces=[]; current=None
    for i,line in enumerate(lines):
        if line.strip()=='SURFACE':
            current={'name':lines[i+1],'sections':[],'mirror':False}; surfaces.append(current)
        elif line.strip()=='YDUPLICATE': current['mirror']=True
        elif line.strip()=='SECTION': current['sections'].append(list(map(float,lines[i+1].split()[:5])))
    return surfaces

svg=['<svg xmlns="http://www.w3.org/2000/svg" width="1400" height="1000" viewBox="0 0 1400 1000">',
     '<rect width="1400" height="1000" fill="white"/>',
     '<style>text{font-family:Times New Roman,serif;fill:#182737} .label{font-size:25px} .small{font-size:20px}</style>']
records=[]
for index,(title,path) in enumerate(paths):
    cx=350+(index%2)*700; cy=215+(index//2)*470
    surfaces=parse(path)
    svg.append(f'<text class="label" x="{cx-300}" y="{cy-165}">({chr(97+index)}) {escape(title)}</text>')
    # Fixed projection and identical metre scale for all four panels.
    def project(x,y,z): return cx+38*y+24*x,cy+23*x-40*z
    for surface in sorted(surfaces,key=lambda s:s['sections'][0][2]):
        ss=surface['sections']
        for sign in ([1,-1] if surface['mirror'] else [1]):
            poly=[project(x,sign*y,z) for x,y,z,c,a in ss]
            poly += [project(x+c,sign*y,z) for x,y,z,c,a in reversed(ss)]
            tail=('tail' in surface['name'] or 'canard' in surface['name'] or 'rear' in surface['name'])
            fill='#b9cad7' if not tail else '#e4c9a1'
            svg.append('<polygon points="'+' '.join(f'{x:.2f},{y:.2f}' for x,y in poly)+f'" fill="{fill}" fill-opacity="0.76" stroke="#263c50" stroke-width="1.6"/>')
    if index<3:
        cg=list(map(float,path.read_text().splitlines()[4].split()))
        px,py=project(*cg)
        svg.append(f'<circle cx="{px}" cy="{py}" r="5" fill="#a21c28"/>')
    label=['Tandem lifting surfaces','Biplane and aft tail','Biplane and aft tail','Biplane and forward canard'][index]
    svg.append(f'<text class="small" x="{cx-300}" y="{cy+190}">{label}</text>')
    records.append({'label':title,'input':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
svg += ['<line x1="60" y1="953" x2="212" y2="953" stroke="#263c50" stroke-width="2"/>',
        '<text class="small" x="60" y="985">4 m spanwise scale</text>',
        '<circle cx="310" cy="957" r="5" fill="#a21c28"/><text class="small" x="324" y="965">CG</text>',
        '<text class="small" x="490" y="965">Lifting-surface outlines only; airframe and propulsion omitted.</text>',
        '<text class="small" x="490" y="990">Chord-plane depiction; no fabricated structural connections.</text>','</svg>']
(OUT/'configuration_comparison_v2.svg').write_text('\n'.join(svg),encoding='utf-8')
(OUT/'configuration_comparison_v2.json').write_text(json.dumps({'inputs':records,'scope':'Researcher rendering of solver chord-plane outlines; not model-authored drawing or as-built aircraft','projection':'xscreen=38*y+24*x, yscreen=23*x-40*z; incidence/camber not depicted'},indent=2),encoding='utf-8')
