"""Reconstruct V0 request texts from recovered files; never execute the API driver."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODELS = ('gpt-6-astra', 'claude-fable-5-1', 'claude-opus-5-5')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def instruction_literal(script):
    values = [ast.literal_eval(n.value) for n in ast.parse(script).body
              if isinstance(n, ast.Assign) and any(
                  isinstance(t, ast.Name) and t.id == 'INSTRUCTIONS' for t in n.targets)]
    if len(values) != 1 or not isinstance(values[0], str):
        raise ValueError('Expected one literal instruction string')
    return values[0].encode('utf-8')


def check_record(record, model, stage, prompt, source, instructions):
    if ((record['model_requested'], record['stage']) != (model, stage)
            or record['status'] not in ('completed', 'incomplete')):
        raise ValueError('Record identity/status mismatch')
    for key, data in [('prompt_sha256', prompt), ('source_sha256', source),
                      ('instruction_sha256', instructions)]:
        if digest(data) != record[key]:
            raise ValueError('Hash mismatch: ' + model + ' ' + stage + ' ' + key)


def main():
    out = ROOT / 'analysis/prompts_v0'
    names = ['blind_piloted_design_1898.txt', 'period_packet_audited_1898.md',
             'blind_figure_request_1898.txt', 'blind_aircraft_eval.observed.py']
    inputs = {name: (out / name).read_bytes() for name in names}
    source = inputs[names[1]]
    prompt = inputs[names[0]] + b'\n' + source
    instructions = instruction_literal(inputs[names[3]].decode('utf-8'))
    pending = [(out / 'article.prompt.txt', prompt), (out / 'instructions.txt', instructions)]
    records = []
    for model in MODELS:
        folder = ROOT / 'received_2026-09-24/astra_fable_opus_designs' / model
        manifest_bytes = (folder / 'manifest.json').read_bytes()
        manifest = json.loads(manifest_bytes)
        article = (folder / 'article.md').read_bytes()
        figure_prompt = inputs[names[2]] + article
        for stage, data, name in [('article', prompt, 'article.prompt.txt'),
                                  ('figures', figure_prompt, model + '.figures.prompt.txt')]:
            matches = [r for r in manifest if r['stage'] == stage]
            if len(matches) != 1:
                raise ValueError('Ambiguous stage record')
            record = matches[0]
            check_record(record, model, stage, data, source, instructions)
            records.append({'model': model, 'stage': stage, 'prompt_file': name,
                            'prompt_bytes': len(data), 'prompt_sha256': digest(data),
                            'source_sha256': digest(source),
                            'instruction_sha256': digest(instructions),
                            'source_manifest_sha256': digest(manifest_bytes),
                            'generated_utc': record['generated_utc'],
                            'response_status': record['status'], 'stop_reason': record.get('stop_reason'),
                            'article_sha256': digest(article),
                            'matches_archived_metadata': True})
        pending.append((out / (model + '.figures.prompt.txt'), figure_prompt))
    for target, data in pending:
        if target.exists() and target.read_bytes() != data:
            raise ValueError('Refusing to replace differing recovered text: ' + str(target))
    for target, data in pending:
        if not target.exists():
            target.write_bytes(data)
    report = {
        'scope': 'Exact-hash reconstruction of three V0 article and three initial two-figure request texts; two figure responses were incomplete',
        'retrieval': 'Read-only Unity OnDemand file editor selection/copy on 2026-09-26; no Save or generation',
        'remote_directory': '/work/pi_roohie_umass_edu/wright1900-benchmark/wright1900',
        'input_file_sha256': {name: digest(data) for name, data in inputs.items()},
        'composition': {'article': 'base + LF + source', 'figures': 'draw + archived article response'},
        'records': records,
        'boundaries': ['The packet contains four paraphrases and links, not the full primary sources.',
                       'Fable and Opus initial two-figure responses stopped at max_tokens; later individual drawing attempts are not covered here.',
                       'A source hash on a figure record does not imply source text was included in that request.',
                       'Driver is a current observed copy, not independently authenticated historical execution code.',
                       'Matching prompt hashes do not establish full HTTP payloads, prior attempts, or reasoning settings accepted by providers.',
                       'No training-data cutoff or absence of modern aviation recall is established.']}
    (out / 'manifest.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'verified_stage_records': len(records), 'article_prompt_sha256': digest(prompt),
                      'source_sha256': digest(source), 'instructions_sha256': digest(instructions)}, indent=2))


if __name__ == '__main__':
    main()
