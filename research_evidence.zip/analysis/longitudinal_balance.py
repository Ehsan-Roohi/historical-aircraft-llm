"""Geometry-to-moment adapter in x-forward, y-right, z-down body axes.

No aerodynamic closure: supplies exact vector moments for supplied loads only.
"""
import json
import math
from pathlib import Path
from audit_mass_tables import summarize

ROOT=Path(__file__).resolve().parents[1]


def body_arm(point, cg, source_x):
    if source_x not in ('forward','aft'):
        raise ValueError('Unknown source x convention')
    sign=1 if source_x=='forward' else -1
    return (sign*(point[0]-cg[0]),point[1]-cg[1],-(point[2]-cg[2]))


def pitch_moment(arm, lift, drag, alpha_rad=0, free_pitch_moment=0):
    """Wind-axis L up, D opposite velocity; alpha relative to body x axis.

    No sideslip. Freestream velocity direction is (cos(alpha),0,sin(alpha)).
    Caller supplies aerodynamic free moment about the SAME reference point.
    """
    x, _, z=arm
    fx=lift*math.sin(alpha_rad)-drag*math.cos(alpha_rad)
    fz=-lift*math.cos(alpha_rad)-drag*math.sin(alpha_rad)
    return z*fx-x*fz+free_pitch_moment


def main():
    results={}
    for name in ('astra','fable','opus'):
        data=json.loads((ROOT/f'analysis/{name}_v1_extracted.json').read_text(encoding='utf-8'))
        cg=summarize(data)['cg_original_axes_m']
        refs=data['aerodynamic_references']
        keys=('forward_left','forward_right','rear') if name=='astra' else ('wing','horizontal_tail')
        arms={key:body_arm(refs[key],cg,data['axes']['x']) for key in keys}
        prop=data['propulsion']
        hub=prop['hubs'][0] if name=='fable' else prop['hub']
        results[data['baseline_id']]={
            'source':'fresh extracted leaf-table CG; Opus uses displayed S1 precision',
            'cg_original_axes_m':cg,
            'arms_body_m':arms,
            'pitch_coefficient_per_N_at_alpha_zero':{key:{'lift':pitch_moment(arm,1,0),'drag':pitch_moment(arm,0,1)} for key,arm in arms.items()},
            'pitch_coefficient_per_N_forward_thrust':body_arm(hub,cg,data['axes']['x'])[2],
            'closure':'unknown loads, free moments and power/control limits; not a trim solution'}
    (ROOT/'analysis/results/longitudinal_geometry_v1.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(results,indent=2))


if __name__=='__main__':
    main()
