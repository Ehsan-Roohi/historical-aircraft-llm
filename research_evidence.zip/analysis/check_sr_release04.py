"""Static integrity checks; not a TeX compilation."""
from pathlib import Path
import re
import zipfile
from PIL import Image

root = Path(__file__).resolve().parents[1]
p = root / "output/overleaf/scientific_reports_aircraft_2026_09_28_release04"
main = (p / "main.tex").read_text(encoding="utf-8")
supp = (p / "supplementary.tex").read_text(encoding="utf-8")
refs = (p / "references_scientific_reports.tex").read_text(encoding="utf-8")
assert main.count(r"\begin{figure}") == 7
assert main.count(r"\begin{table}") == 2
assert supp.count(r"\begin{figure}") == 6
assert supp.count(r"\begin{table}") == 8
for body in (main, supp):
    for graphic in re.findall(r"\\includegraphics\[[^]]*\]\{([^}]+)\}", body):
        assert (p / graphic.replace(r"\figdir", "figures")).is_file(), graphic
    for group in re.findall(r"\\cite\{([^}]+)\}", body):
        for key in group.split(","):
            assert rf"\bibitem{{{key.strip()}}}" in refs, key
assert "Astra V1 & Opus V1 & Fable V1" in main
assert "fig:v2forces" in main
assert "Supplementary Table~S8" in main
assert "$C_{m_q}=-4.706$" in main
assert "aircraft-sr-2026-09-28-r2" in main
abstract = re.search(r"\\begin\{abstract\}(.*?)\\end\{abstract\}", main, re.S).group(1)
assert len(re.findall(r"\b[\w-]+\b", abstract)) <= 200
with Image.open(p / "figures/v2_force_moment_comparison.png") as im:
    assert im.size == (3600, 2460)
    assert im.info["dpi"][0] >= 300
with zipfile.ZipFile(root / "output/delivery/scientific_reports_aircraft_overleaf_release04.zip") as z:
    assert z.testzip() is None
    assert "DATA_AVAILABILITY.md" in z.namelist()
    assert "audit_data/v2_rate_derivatives_fine.json" in z.namelist()
    assert "audit_data/v2_rate_derivatives_coarse.json" in z.namelist()
print("release04 static checks passed; TeX compile not tested")
