"""Check exact selected V1 responses and their registered V0 source artifacts."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    registry_path = ROOT/"paper/baselines/baseline_registry_v1.json"
    registry = json.loads(registry_path.read_text(encoding="utf-8"))
    rows = []
    for entry in registry["models"]:
        source = entry["response"]
        raw_path = ROOT/source["local_archive_path"]
        raw_hash = digest(raw_path)
        if raw_hash != source["sha256"]:
            raise ValueError(f"Raw hash mismatch: {entry['baseline_id']}")
        raw = json.loads(raw_path.read_bytes())
        for key in ("model_requested", "model_returned"):
            if raw[key] != entry[key]:
                raise ValueError(f"Model identity mismatch: {key}")
        for key in ("status", "stop_reason", "token_limit", "generated_utc"):
            if raw[key] != source[key]:
                raise ValueError(f"Response metadata mismatch: {key}")
        if len(raw["response"]) != source["response_characters"]:
            raise ValueError("Response character count mismatch")
        artifacts = {}
        for field in ("article", "three_view"):
            path = ROOT/entry["original"][field+"_path"]
            actual = digest(path)
            if actual != entry["original"][field+"_sha256"]:
                raise ValueError(f"V0 {field} hash mismatch")
            artifacts[field] = {"path":path.relative_to(ROOT).as_posix(), "sha256":actual}
        if raw["source_article_sha256"] != artifacts["article"]["sha256"]:
            raise ValueError("V1 is not linked to the registered V0 article")
        transfer = json.loads((ROOT/source["local_transfer_record"]).read_text(encoding="utf-8"))
        if transfer["registered_sha256"] != raw_hash or transfer["response_id"] != raw["response_id"]:
            raise ValueError("Transfer record mismatch")
        rows.append({
            "baseline_id":entry["baseline_id"], "raw_path":source["local_archive_path"],
            "raw_sha256":raw_hash, "raw_bytes":raw_path.stat().st_size,
            "response_id":raw["response_id"], "source_artifacts":artifacts,
            "all_checked_fields_match":True
        })
    result = {
        "baseline_set_id":registry["baseline_set_id"],
        "registry_sha256":digest(registry_path),
        "checked_selected_responses":len(rows), "rows":rows,
        "scope":"Selected V1 raw bytes, registered metadata and V0 article/drawing linkage only",
        "not_covered":["all historical API attempts", "prompt text and supplied historical packet archive", "physical validity", "complete executable analysis package"]
    }
    (ROOT/"analysis/results/source_archive_check_v1.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2))


if __name__ == "__main__":
    main()
