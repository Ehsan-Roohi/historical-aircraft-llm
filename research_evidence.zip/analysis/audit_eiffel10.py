"""Audit a sourced section proxy and coordinate datum; no polar or flight inference."""
import hashlib
import json
import math
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
EXPECTED='d58a4780ccf261336dc1a2588faa65501ac62389edb2fe4bdff95bb4dc9e6255'


def paired_stations(text):
    lines=text.splitlines()
    points=[tuple(map(float,line.split())) for line in lines[1:] if line.strip()]
    if any(len(p)!=2 or not all(math.isfinite(v) for v in p) for p in points):
        raise ValueError('Invalid coordinates')
    halves=len(points)//2
    upper=list(reversed(points[:halves])); lower=points[halves:]
    if len(upper)!=len(lower) or len(upper)<3:
        raise ValueError('Expected paired station branches')
    if any(abs(a[0]-b[0])>1e-12 or a[1]<b[1] for a,b in zip(upper,lower)):
        raise ValueError('Unpaired or crossed branches')
    if any(upper[i+1][0]<=upper[i][0] for i in range(len(upper)-1)):
        raise ValueError('Nonmonotone stations')
    return [{'x':a[0],'upper_y':a[1],'lower_y':b[1],'mean_y':(a[1]+b[1])/2,'vertical_thickness':a[1]-b[1]} for a,b in zip(upper,lower)]


def endpoint_frame(points):
    x0,z0=points[0]; dx=points[-1][0]-x0; dz=points[-1][1]-z0
    length2=dx*dx+dz*dz
    if length2<=0: raise ValueError('Degenerate mean endpoint chord')
    normalized=[[(dx*(x-x0)+dz*(z-z0))/length2,(dx*(z-z0)-dz*(x-x0))/length2] for x,z in points]
    return normalized,math.degrees(math.atan2(dz,dx)),math.sqrt(length2)


def main():
    path=ROOT/'analysis/references/eiffel10_uiuc.dat'; raw=path.read_bytes()
    actual=hashlib.sha256(raw).hexdigest()
    if actual!=EXPECTED: raise ValueError('Source hash mismatch')
    stations=paired_stations(raw.decode('utf-8'))
    normalized,angle,length=endpoint_frame([(r['x'],r['mean_y']) for r in stations])
    result={
        'source_url':'https://m-selig.ae.illinois.edu/ads/coord/eiffel10.dat',
        'source_sha256':actual,
        'attribution_note_url':'https://m-selig.ae.illinois.edu/ads/ref/misc_refs.html',
        'identity_status':'UIUC labels this a close approximation; not confirmed as the 1903 or Ames as-tested section',
        'scope':'Coordinate bookkeeping and researcher-defined mean-endpoint datum, not solver-equivalent preprocessing or aerodynamic validation',
        'source_points':2*len(stations),'paired_stations':stations,
        'max_tabulated_vertical_thickness':max(r['vertical_thickness'] for r in stations),
        'max_tabulated_raw_mean_ordinate':max(r['mean_y'] for r in stations),
        'mean_endpoint_chord_angle_deg':angle,'mean_endpoint_chord_length_raw_units':length,
        'researcher_normalized_meanline_x_z':normalized,
        'max_tabulated_normalized_meanline_ordinate':max(p[1] for p in normalized),
        'bounds':['Maxima describe tabulated stations with piecewise-linear interpolation, not a spline or continuous measured shape.',
                  'Finite leading/trailing vertical gaps are retained, not repaired.',
                  'Mean endpoint line is an explicit analyst convention, not a uniquely established historical chord.',
                  'Rotation changes the incidence datum; do not substitute this meanline at unchanged incidence and call the geometry equivalent.',
                  'A full upper/lower contour transformed and resampled need not yield the same meanline as transforming paired means.',
                  'No canard section, stall, drag, deformation or as-tested wing identity is established.']}
    (ROOT/'analysis/results/eiffel10_section_audit_v1.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('paired_stations','researcher_normalized_meanline_x_z','bounds')},indent=2))


if __name__=='__main__': main()
