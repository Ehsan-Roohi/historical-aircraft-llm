#!/usr/bin/env python3
"""Freeze model-specific V6 feedback with complete V5 provenance."""
import argparse
import hashlib
import json
from pathlib import Path

MODELS = ('gpt-6-astra', 'claude-fable-5-1', 'claude-opus-5-5')
STAGE = 'v6_propeller_geometry_repair'
INSTRUCTIONS = """You are revising one proposed period-plausible aircraft propeller for a
research comparison with the Wright 1903 Flyer. This is a modern,
researcher-assisted design iteration following the historical-information
initial prompt, not an 1898-blind experiment. Treat XFOIL as a numerical
diagnostic, not measured evidence of thrust, stability or flight. Preserve the
initial design and every V2-V5 revision as separate baselines. Do not invent
engine curves, transmission efficiency, material strength, thrust, torque,
power, CFD, wind-tunnel results, or flight capability. A failed XFOIL point is
not proof of physical impossibility; a successful point is not proof of
propeller performance. Return one strict JSON object without markdown.
"""

COMMON = """Stage V6: reply to the independently audited V5 geometry and
full radial-section numerical screen. Parent model-response job: 64962376.
Radial XFOIL array: 64965852, frozen solver SHA-256
000b0468d9a7f4fce42d6fac24bd14147d7d326c8a9035909c8e9f98d180f50e.
The array tested 16 model/station combinations x two contour resolutions x
nine angles = 288 cases. It yielded 269 numerical-screen rows, 18 cases with
zero stored polar rows and VISCAL convergence failure, and one rejected row.
The complete aircraft, engine and drive remain unvalidated. This round is a
geometry/assembly clarification; do not claim any propeller performance.
If no geometry change is justified, explicitly return NO_CHANGE and give a
bounded test plan instead of a speculative redesign.

Return JSON keys: model, stage, parent_response_sha256, disposition,
baseline_preserved, geometry_revision, radial_station_table, assembly_frame,
manufacturing, test_plan, assumptions, unresolved, status. Set
stage="v6_propeller_geometry_repair" and status="UNVALIDATED". Every radial
station needs numeric r, chord, section ID and beta in degrees. For each new
section, state complete upper/lower coordinates or analytic curves; chord
datum, LE radius, TE thickness and actual maximum thickness; both as
dimensionless ratios and, for a station, in metres. Give one concrete
position/rotation check reconciling local and body axes. Label any changed
diameter, rpm, pitch, mass, location, blade count or thrust direction as a
separate redesign rather than silently replacing its accepted baseline.
"""

SPECIFIC = {
    'gpt-6-astra': """Astra V5c: seven stations at r=[0.15,0.30,0.45,0.65,0.80,
1.00,1.20] m, one 2-blade propeller, D=2.4 m, 900 rpm, V=18 m/s. Your V5
smooth symmetric t/c=0.12 section reproduced its claimed geometry. The radial
screen passed 123/126 cases. At r=0.45 m the 161-node alpha=6 deg case had
zero polar rows; at r=1.20 m the 241-node alpha=14 deg case had zero rows and
the 161-node alpha=14 deg stored row was rejected for warning/drag mismatch.
Both contour resolutions still bracket the no-induction geometric incidence
at all seven stations. Explain whether a geometry change is actually needed
or whether an uncertainty/sensitivity test is appropriate. Your V5 local shaft
+x axis conflicts with the V4 +z local shaft convention: provide the explicit
rotation into the V2 aircraft body frame and a numerical blade-point check.
Do not use successful 2D rows to assert thrust or engine adequacy. State what
engine torque-vs-rpm and drive data remain missing.
""",
    'claude-fable-5-1': """Fable V5: two opposite-hand 2-blade propellers,
each D=2.3 m, 600 rpm, V=13 m/s, proposed 412 N total thrust demand. Your
rounded-nose family has m=0.06 and radial thickness parameters
[0.30,0.20,0.15,0.12,0.11,0.10,0.09,0.08,0.08] at r=[0.12,0.25,0.40,
0.55,0.70,0.85,1.00,1.10,1.15] m. The screen passed 146/162 cases, but the
thick inner r=0.12 m section passed only 11/18. Its no-induction geometric
incidence is 4.913 degrees, yet the only angles accepted at BOTH contour
resolutions are 0 and 2 degrees, with |delta CL| up to 0.1294 and |delta CD|
up to 0.01248. Seven cases there had zero rows and VISCAL failure. The
operating angle cannot be bracketed there without extrapolation. Other Fable
stations each have a two-resolution bracket. Your V5 r=0.55 m trailing edge
is only 0.504 mm thick at c=0.2 m, conflicting with the proposed wooden
construction. Propose a minimal explicit root/hub transition and a
manufacturable trailing edge, or state what evidence is needed to choose one.
If r=0.12 m is now a nonlifting structural root, give exact hub radius and
load-bearing/section boundary and do not silently exclude it from integration.
Preserve V2 native body axes (+x aft, +y right, +z up) and explicitly map both
opposite-hand local blade frames into them. Keep the V3b 12 kg assembly mass
as a proposal, not a measured aircraft fact. Do not invent improved polars.
""",
    'claude-opus-5-5': """Opus V5A was NOT screened. Independent substitution
in your analytic formula at t=0.10 gives trailing-edge thickness 0.006c,
not the claimed 0.0081c (difference 0.0021c or 0.546 mm at c=0.26 m).
Your nonzero pitch-reference conversion for the original V4 flat lower line
also conflicts with that baseline: its lower line and chord coincide, so the
V4 baseline correction is 0 degrees. First repair these algebraic and
reference-line inconsistencies, keeping V4 unchanged as a separate baseline.
Provide exact coefficients/formula or a complete x/c,y/c table, numerical
thickness/TE calculations and pitch-reference definition for every station.
Do not relabel the untested V5A as accepted, and do not claim thrust from
any section. If the true model geometry is ambiguous, explicitly say so
and request the minimum missing dimensions instead of fabricating them.
""",
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--project-root', type=Path, default=Path('.'))
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    root = args.project_root.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    instructions = INSTRUCTIONS.encode('utf-8')
    (output / 'instructions.txt').write_bytes(instructions)
    expected = json.loads((root / 'analysis/results/v5_section_geometry_audit01.json').read_text())['records']
    rows = []
    for model in MODELS:
        source = root / 'received_v5_64962376/responses' / model / 'response.json'
        source_bytes = source.read_bytes()
        if sha(source_bytes) != expected[model]['response_sha256']:
            raise ValueError(f'V5 response hash mismatch for {model}')
        response = json.loads(source_bytes)
        if response['status'] != 'completed' or response['model_returned'] != model:
            raise ValueError(f'V5 response status/model mismatch for {model}')
        prompt = (COMMON + '\nMODEL-SPECIFIC AUDIT:\n' + SPECIFIC[model] +
                  '\nYOUR COMPLETE V5 RESPONSE (unaltered, for continuity; not evidence):\n' +
                  response['response'] + '\n')
        filename = model + '.prompt.txt'
        prompt_bytes = prompt.encode('utf-8')
        (output / filename).write_bytes(prompt_bytes)
        rows.append(dict(model_requested=model, prompt_file=filename,
                         prompt_sha256=sha(prompt_bytes),
                         parent_response_sha256=sha(source_bytes), sent=False))
    manifest = dict(stage=STAGE, parent_model_job='64962376', parent_radial_job='64965852',
                    maximum_output_tokens=20000, instructions_sha256=sha(instructions),
                    records=rows)
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(dict(output=str(output), models=len(rows),
                          stage=STAGE)))


if __name__ == '__main__':
    main()
