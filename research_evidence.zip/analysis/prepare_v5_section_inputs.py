"""Sample the exact Astra and Fable V5 section proposals for XFOIL.

Representative sections only; this does not merge V5 into any aircraft.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path

SOURCE_HASHES = {
    'astra': '39452d0e399a6fc7884b7dfc6c480ef2a657ebc6357d740cb39acb7e00825f61',
    'fable': 'f42e6c956bd4f323480400c8136218662970edd47a9f03f411f84f1a98e829c3',
}


def ordinates(family, x):
    if family == 'astra':
        a = 27 / (35 * math.sqrt(21))
        upper = a * math.sqrt(x * (1 - x)) * (1 - 20*x/27)
        return upper, -upper
    if family == 'fable':
        t, m = .12, .06
        camber = 4*m*x*(1-x)
        half = 5*t*(.2969*math.sqrt(x)-.1260*x-.3516*x*x+.2843*x**3-.1015*x**4)
        return camber + half, camber - half
    raise ValueError(family)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    records = []
    for family in SOURCE_HASHES:
        for density in (80, 120):
            xs = [(1-math.cos(math.pi*i/density))/2 for i in range(density+1)]
            upper = [(x, ordinates(family, x)[0]) for x in reversed(xs)]
            lower = [(x, ordinates(family, x)[1]) for x in xs[1:]]
            file = args.output / f'{family}_t12_n{density}.dat'
            data = family + f'_V5_t12_n{density}\n' + ''.join(f'{x:.12f} {y:.12f}\n' for x,y in upper+lower)
            file.write_text(data)
            records.append(dict(file=file.name, sha256=hashlib.sha256(file.read_bytes()).hexdigest(),
                                family=family, points=len(upper+lower),
                                response_sha256=SOURCE_HASHES[family],
                                status='GEOMETRY_ONLY_NOT_POLAR'))
    manifest = dict(stage='v5_section_candidate', parent_model_job='64962376',
                    sections=records, geometry_only=True)
    (args.output/'manifest.json').write_text(json.dumps(manifest, indent=2))
    print(json.dumps(manifest, indent=2))


if __name__ == '__main__':
    main()
