#!/usr/bin/env python3
"""Audit the frozen radial XFOIL screen; never infer propeller performance."""
import argparse
import hashlib
import json
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(manifest, result_dir):
    stations = []
    all_records = []
    for station in manifest['stations']:
        stem = station['stem']
        records = json.loads((result_dir / stem / 'records.json').read_text())
        if len(records) != 18 or {r['case'] for r in records} != {
            f'{stem}_n{n}_a{a:+03d}' for n in (80, 120)
            for a in station['alpha_screen_deg']
        }:
            raise ValueError(f'Case inventory mismatch at {stem}')
        all_records.extend(records)
        by_case = {r['case']: r for r in records}
        paired = []
        for alpha in station['alpha_screen_deg']:
            low = by_case[f'{stem}_n80_a{alpha:+03d}']
            high = by_case[f'{stem}_n120_a{alpha:+03d}']
            if low['status'] == high['status'] == 'NUMERICAL_SCREEN':
                lc, hc = low['reader']['coefficients'], high['reader']['coefficients']
                paired.append(dict(alpha_deg=alpha,
                                   abs_delta_CL=abs(lc['CL'] - hc['CL']),
                                   abs_delta_CD=abs(lc['CD'] - hc['CD'])))
        operational_alpha = station['geometric_incidence_no_induction_deg']
        below = [p['alpha_deg'] for p in paired if p['alpha_deg'] <= operational_alpha]
        above = [p['alpha_deg'] for p in paired if p['alpha_deg'] >= operational_alpha]
        bracket = [max(below), min(above)] if below and above else None
        stations.append(dict(stem=stem, family=station['family'],
                             reynolds_no_induction=station['reynolds_no_induction'],
                             mach_no_induction=station['mach_no_induction'],
                             geometric_incidence_no_induction_deg=operational_alpha,
                             screened=sum(r['status'] == 'NUMERICAL_SCREEN' for r in records),
                             paired_angles_deg=[p['alpha_deg'] for p in paired],
                             operational_bracket_paired_deg=bracket,
                             max_abs_delta_CL=max((p['abs_delta_CL'] for p in paired), default=None),
                             max_abs_delta_CD=max((p['abs_delta_CD'] for p in paired), default=None),
                             paired_deltas=paired))
    failures = [dict(case=r['case'], status=r['status'],
                     reader_error=r.get('reader_error'),
                     terminal_warning=(r.get('reader') or {}).get('terminal_warning'))
                for r in all_records if r['status'] != 'NUMERICAL_SCREEN']
    statuses = {s: sum(r['status'] == s for r in all_records)
                for s in sorted({r['status'] for r in all_records})}
    return dict(stage='radial_section_numerical_screen_only', job_id=None,
                stations=stations, status_counts=statuses, failures=failures,
                all_stations_have_paired_operational_bracket=all(
                    s['operational_bracket_paired_deg'] is not None for s in stations),
                aerodynamic_validation=False, propeller_performance_calculated=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--manifest', type=Path, required=True)
    ap.add_argument('--result-dir', type=Path, required=True)
    ap.add_argument('--archive', type=Path, required=True)
    ap.add_argument('--expected-archive-sha256', required=True)
    ap.add_argument('--job-id', required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    if digest(args.archive).lower() != args.expected_archive_sha256.lower():
        raise ValueError('Downloaded archive checksum mismatch')
    report = audit(json.loads(args.manifest.read_text()), args.result_dir)
    report['job_id'] = args.job_id
    report['archive_sha256'] = digest(args.archive)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('job_id', 'status_counts',
        'all_stations_have_paired_operational_bracket', 'propeller_performance_calculated')}))


if __name__ == '__main__':
    main()
