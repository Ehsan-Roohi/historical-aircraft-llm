"""Astra V1 command allocation only; no aerodynamic or mechanical clearance."""
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW_SHA = '7c1de0d7b13d2640399603539c4bedc471f19654c8bfef48375f49be937daa12'


def allocation(collective_deg, differential_deg, limit_deg=6.0):
    if not all(math.isfinite(v) for v in (collective_deg, differential_deg, limit_deg)) or limit_deg <= 0:
        raise ValueError('Finite commands and a positive limit required')
    left = collective_deg + differential_deg
    right = collective_deg - differential_deg
    margin = limit_deg - max(abs(left), abs(right))
    return {'left_incidence_deg': left, 'right_incidence_deg': right,
            'within_nominal_limits': margin >= 0,
            'remaining_limit_margin_deg': margin,
            'maximum_abs_differential_at_fixed_collective_deg': max(0.0, limit_deg-abs(collective_deg)),
            'collective_feasible_at_zero_differential': abs(collective_deg) <= limit_deg}


def main():
    raw = ROOT/'analysis/raw_v1/verified/gpt-6-astra.json'
    if hashlib.sha256(raw.read_bytes()).hexdigest() != RAW_SHA:
        raise ValueError('Frozen source hash mismatch')
    source = json.loads(raw.read_text(encoding='utf-8'))['response']
    for phrase in ['nominal front and rear chord incidence', 'Positive forward incidence raises the leading edge',
                   r'\alpha_L=c+d,\qquad \alpha_R=c-d', 'A mechanism enforcing those combined limits has not been designed.']:
        if phrase not in source:
            raise ValueError('Expected source convention missing: '+phrase)
    path = ROOT/'analysis/results/trim_control_grid_v1.json'
    grid = json.loads(path.read_text(encoding='utf-8'))
    rows = []
    for case in grid['cases']:
        if case['model'] != 'astra':
            continue
        for candidate in case['candidates']:
            c = candidate['control_deg']
            rows.append({k: case[k] for k in ['alpha_deg','added_CD','added_drag_moment_arm_m']} |
                        {'collective_deg': c, 'allocation_at_zero_differential': allocation(c, 0)})
    result = {'scope': 'Nominal command allocation; not roll authority, clearance, or flight feasibility',
              'raw_sha256': RAW_SHA, 'trim_grid_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
              'nominal_incidence_deg': 0, 'limit_deg': 6,
              'rounding_note': 'Use source prose exact V1 +/-6 degrees; printed 0.104720 rad is rounded.',
              'AVL_collective_to_source_incidence_sign': 1,
              'sign_reason': 'AVL +y right-hand normal rotation lowers TE, equivalent to source LE-up incidence; vertices do not rotate.',
              'coupled_constraint': 'abs(collective)+abs(differential)<=6 degrees',
              'mechanical_status': 'Unresolved root interface, mixer, cable route and load path',
              'candidates': rows}
    out = ROOT/'analysis/results/astra_control_budget_v1.json'
    out.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'candidate_count': len(rows), 'outside_nominal_limits': sum(not r['allocation_at_zero_differential']['within_nominal_limits'] for r in rows)}))


if __name__ == '__main__':
    main()
