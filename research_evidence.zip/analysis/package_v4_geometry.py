"""Package immutable V4 requests with the existing bounded Unity transport wrapper."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]


def main():
    folder = ROOT/'analysis/prompts_v4_propulsion_geometry'
    manifest = json.loads((folder/'manifest.json').read_bytes())
    for row in manifest['records']:
        raw = (folder/row['prompt_file']).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == row['prompt_sha256']
        assert row['sent'] is False
        row['maximum_output_tokens'] = 32000
    runner = (ROOT/'unity_jobs/run_design_revision_v3b.py').read_text().replace('revision_v3b', 'revision_v4g')
    batch = (ROOT/'unity_jobs/run_design_revision_v3b.sbatch').read_text().replace('revision_v3b', 'revision_v4g').replace('design-v3b', 'design-v4g')
    dest = ROOT/'output/delivery/design_revision_v4g_attempt01.zip'
    with ZipFile(dest, 'x', ZIP_DEFLATED) as z:
        for row in manifest['records']:
            z.write(folder/row['prompt_file'], 'prompts/'+row['prompt_file'])
        z.writestr('prompts/manifest.json', json.dumps(manifest, indent=2))
        z.writestr('prompts/instructions.txt', 'Return complete reproducible geometry JSON. No invented aerodynamic data or feasibility claims.')
        z.writestr('run_design_revision_v4g.py', runner)
        z.writestr('run_design_revision_v4g.sbatch', batch)
    print(hashlib.sha256(dest.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
