"""Package only frozen requests and the bounded runner; does not submit jobs."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
dest = ROOT/'output/delivery/design_revision_v2_attempt01.zip'
files = {ROOT/'unity_jobs/run_design_revision_v2.py':'run_design_revision_v2.py',
         ROOT/'unity_jobs/run_design_revision_v2.sbatch':'run_design_revision_v2.sbatch'}
for path in sorted((ROOT/'analysis/prompts_v2_retrim').iterdir()):
    if path.is_file():
        files[path] = 'prompts/' + path.name
readme = '''Prepared locally; NOT SUBMITTED. Extract into a new directory named
design_revision_v2_attempt01 under the existing Unity wright1900 project. Preserve
the exact prompts. Before submission, inspect the existing frontier_wright_eval.py
transport for endpoint mapping, retries and credential handling. The wrapper calls
that existing transport once per model and permits no automatic requeue/retry.
Three array tasks, 1 CPU and 2 GiB each, maximum wall time 2 hours; maximum output
32,000 tokens/model. Keys remain in the established remote environment, not this ZIP.
Do not rerun after an uncertain API outcome without inspecting the immutable records.
No manuscript compilation, journal submission or public upload is included.
'''
with zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED) as archive:
    manifest = []
    for path, name in files.items():
        data = path.read_bytes()
        # Unix shell scripts need LF even when this package is built on Windows.
        if name.endswith('.sbatch'):
            data = data.replace(b'\r\n', b'\n')
        archive.writestr(name, data)
        manifest.append({'path': name, 'sha256': hashlib.sha256(data).hexdigest()})
    archive.writestr('README.txt', readme)
    archive.writestr('PACKAGE_MANIFEST.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(dest) as archive:
    assert archive.testzip() is None
print(json.dumps({'file': str(dest), 'bytes': dest.stat().st_size,
                  'submitted': False, 'sha256': hashlib.sha256(dest.read_bytes()).hexdigest()}, ensure_ascii=True))
