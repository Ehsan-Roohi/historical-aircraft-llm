"""Bounded feedback to close bookkeeping and explicitly unresolved propulsion gates."""
import json,hashlib
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
ROOT=Path(__file__).resolve().parents[1]
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    out=ROOT/'analysis/prompts_v3c_propulsion';out.mkdir(exist_ok=False)
    inp=json.loads((ROOT/'analysis/v3b_propulsion_inputs.json').read_bytes())['records']
    results=json.loads((ROOT/'analysis/results/v3b_propulsion_check01/summary.json').read_bytes())['records']
    focus={
      'gpt-6-astra':'Independent ideal-inflow geometry check at 400 N,18 m/s,900 rpm gives root alpha=-2.94 deg, midspan alpha up to 13.75 deg for your symmetric polygonal section. Stall is UNKNOWN; do not declare these angles acceptable without polars. Return a candidate twist revision targeting alpha_geometric=5 deg at this ideal-inflow operating point, keep chord/rpm/diameter. It is an evaluator-requested design candidate, NOT demonstrated 400 N. Give old/new beta at each radius and explicitly leave thrust/torque/eta validation open.',
      'claude-fable-5-1':'V2 already includes P08L and P08R at 2.5 kg EACH, not zero! Your proposed 12 kg total therefore adds 7 kg (not 12 and not zero), all at x=3,z=.8. Baseline total295, CG=(1.5608813559322034,0,.7538813559322034). Reconcile revised total and CG, explicitly excluding unquantified shaft/gear mass changes. At 10700 W target and drive=.95, required prop efficiency=.526906 baseline or .658633 for +25% demand, not established by geometry. Do NOT adopt a higher eta to assert success. Give a precise FAIL/UNKNOWN operating-point disposition and constrained corrective options without a fabricated efficiency claim.',
      'claude-opus-5-5':'Your V_m_s=14.908 is AXIAL inflow; actual aircraft speed is15 m/s, alpha=6.3468008853 deg. Clarify both to prevent double cosine correction. Engine1000 rpm, prop400, ratio2.5; required eta_prop=.538483 baseline/.673104 +25% at drive=.95 and13kW target. Your phrase looking forward (+x) is wrong for V2 x AFT: forward is -x. Resolve rotation viewing convention and reaction torque explicitly. Numeric torque264.606Nm base/330.757Nm stress; no dynamic control approval. Do not claim a fixed prop at unchanged RPM produces25% extra thrust.'}
    records=[]
    for row,res in zip(inp,results):
        model=row['model'];assert model==res['model']
        prompt='''V3c focused propulsion feedback, researcher-assisted historical study cutoff1898-12-31.
Reply under800 words as ONE JSON object (no code execution), keys: model, corrections,
revised_numeric_definition, closed_checks, unresolved_gates, acceptance_disposition.
Do not redesign the whole aircraft. No invented polars, engine curves, material
allowables or test results. The engine power targets are UNVERIFIED. A conditional
power budget is not proof that the specified geometry produces thrust. Preserve
V2 and V3b as immutable. Explicitly identify any new proposal as unaccepted.
'''+focus[model]+'\nV3b numeric subset:\n'+json.dumps(row)+'\nIndependent checks:\n'+json.dumps(res)
        p=out/f'{model}.prompt.txt';p.write_text(prompt,encoding='utf-8')
        records.append(dict(model_requested=model,prompt_file=p.name,prompt_sha256=sha(p.read_bytes()),maximum_output_tokens=32000,sent=False,response=None))
    (out/'instructions.txt').write_text('Resolve the specific feedback concisely. No fabricated evidence or flight claim. Respond with valid JSON.',encoding='utf-8')
    (out/'manifest.json').write_text(json.dumps(dict(stage='v3c_propulsion_feedback',records=records),indent=2),encoding='utf-8')
    runner=(ROOT/'unity_jobs/run_design_revision_v3b.py').read_text(encoding='utf-8').replace('revision_v3b','revision_v3c')
    batch=(ROOT/'unity_jobs/run_design_revision_v3b.sbatch').read_text(encoding='utf-8').replace('revision_v3b','revision_v3c').replace('design-v3b','design-v3c')
    dest=ROOT/'output/delivery/design_revision_v3c_attempt01.zip'
    with ZipFile(dest,'x',ZIP_DEFLATED) as z:
        for p in sorted(out.iterdir()):z.write(p,'prompts/'+p.name)
        z.writestr('run_design_revision_v3c.py',runner);z.writestr('run_design_revision_v3c.sbatch',batch)
    print(sha(dest.read_bytes()))
if __name__=='__main__':main()
