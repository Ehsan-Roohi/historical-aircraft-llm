"""Traceable planar reconstruction only; no aerodynamic solver or area fitting."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def polygon_area(points):
    if len(points) < 3:
        raise ValueError('Need at least three vertices')
    return abs(sum(x*y1-x1*y for (x,y),(x1,y1) in zip(points, points[1:]+points[:1]))) / 2


def area_reading_bound(points, epsilon):
    if epsilon < 0:
        raise ValueError('Negative reading allowance')
    # Shoelace linear perturbation plus conservative quadratic remainder.
    n = len(points)
    return epsilon/2*sum(abs(points[(i+1)%n][1]-points[i-1][1])+
                         abs(points[i-1][0]-points[(i+1)%n][0]) for i in range(n)) + n*epsilon**2


def reconstruct(data):
    cal = data['calibration']
    span_px = cal['span_endpoints_u_px'][1]-cal['span_endpoints_u_px'][0]
    eps = data['reading_allowance_px']
    if eps < 0 or span_px <= 2*eps or cal['span_m'] <= 0:
        raise ValueError('Invalid calibration')
    scale = cal['span_m']/span_px
    scales = [cal['span_m']/(span_px+2*eps), cal['span_m']/(span_px-2*eps)]
    u0,v0 = cal['origin_uv_px']
    result = {'scale_m_per_pixel': scale, 'reading_only_scale_bounds_m_per_pixel': scales, 'outlines': {}}
    for name, points in data['outlines_uv_px'].items():
        area_px = polygon_area(points)
        error_px = area_reading_bound(points, eps)
        transformed = [[(v0-v)*scale,(u-u0)*scale] for u,v in points]
        result['outlines'][name] = {'coordinates_x_aft_y_image_right_m': transformed,
                                   'projected_area_m2': area_px*scale**2,
                                   'reading_only_area_bounds_m2': [max(0,area_px-error_px)*scales[0]**2,(area_px+error_px)*scales[1]**2],
                                   'span_m': (max(p[0] for p in points)-min(p[0] for p in points))*scale,
                                   'fore_aft_extent_m': (max(p[1] for p in points)-min(p[1] for p in points))*scale}
    check = data['independent_annotation_checks']
    a,b = check['main_chord_pixel_pair']
    main_chord = abs(a[1]-b[1])*scale
    wing = result['outlines']['main_wing_projection']
    canard = result['outlines']['canard_projection']
    result['checks_not_fitted'] = {
        'main_chord_at_selected_station_m': main_chord,
        'main_chord_annotation_m': check['main_chord_m'],
        'canard_span_relative_difference_percent': 100*(canard['span_m']/check['canard_span_m']-1),
        'canard_extent_relative_to_chord_annotation_percent': 100*(canard['fore_aft_extent_m']/check['canard_chord_m']-1),
        'hypothetical_two_identical_projected_wings_area_m2': 2*wing['projected_area_m2'],
        'two_wings_area_annotation_m2': check['two_main_wings_area_m2'],
        'two_wings_area_relative_difference_percent': 100*(2*wing['projected_area_m2']/check['two_main_wings_area_m2']-1)}
    return result


def main():
    path = ROOT/'analysis/references/wright_planform_pixels_v1.json'
    raw = path.read_bytes()
    data = json.loads(raw)
    if hashlib.sha256((ROOT/data['source_file']).read_bytes()).hexdigest() != data['source_sha256']:
        raise ValueError('Source hash mismatch')
    result = reconstruct(data)
    result.update(input_sha256=hashlib.sha256(raw).hexdigest(), source_sha256=data['source_sha256'],
                  scope='Projected piecewise-linear researcher trace, not a matched Wright aerodynamic model',
                  boundaries=data['not_established'])
    (ROOT/'analysis/results/wright_planform_trace_v1.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result['checks_not_fitted'],indent=2))


if __name__ == '__main__': main()
