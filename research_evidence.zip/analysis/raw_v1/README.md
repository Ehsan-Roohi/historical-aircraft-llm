# V1 response archive

Authoritative local raw files belong in `verified/`. The top-level JSON is a retained editor-transfer candidate, not the authoritative byte archive. For Opus it contains one extra terminal LF introduced during text-file authoring.

On 2026-09-26 the complete selected Opus JSON was read through the Unity OOD editor's select-all/copy action without saving or changing the remote file. Its text was transferred with apply_patch. `archive_raw_v1.py` accepted only removal of that one LF because the resulting 21,980 bytes match the previously registered remote SHA-256 exactly:

`2498aa6b1a4bbf440912bb28d2c2c6d1e91d01c68e5ec48cd17d807eea6ae76e`

This establishes identity with the registered source, not a fresh independent remote hash measurement. No response text, numbers, JSON ordering or whitespace inside the file were repaired. The transfer record preserves the candidate hash and source path. Re-running promotion checks the archive and refuses to overwrite different bytes.

```powershell
python analysis/archive_raw_v1.py claude-opus-5-5
python analysis/verify_opus_extraction.py
```

The extraction check parses all 24 Table A leaf rows directly from the verified raw response and matches IDs, masses and displayed CG values to the existing extraction. It retains the displayed S1 precision; it does not silently replace 1.256 with 1.25625 from a separate source calculation. It validates transcription, not the physical assumptions or every field of the design.

Fable was also transferred on 2026-09-26. Removing one authoring-added terminal LF produced 20,722 bytes with registered SHA-256 `7122da0b6980e4760937f2db78920591b6ba6761fb6d75db656f8861ce3bc20f`. The verified file and transfer record are in `verified/`. `verify_fable_extraction.py` matched all 15 leaf mass/CG rows, including the explicit symmetric-pair aggregation of P03. Its 6 kg total is counted once. The P07 centroid contradiction is retained, not repaired.

```powershell
python analysis/archive_raw_v1.py claude-fable-5-1
python analysis/verify_fable_extraction.py
```

Astra was transferred on 2026-09-26 using the same method. Removing one authoring-added terminal LF produced 32,287 bytes matching registered SHA-256 `7c1de0d7b13d2640399603539c4bedc471f19654c8bfef48375f49be937daa12`. `verify_astra_extraction.py` matched all 24 mass/CG rows, preserving the original forward-positive x axis and separate left/right assemblies.

```powershell
python analysis/archive_raw_v1.py gpt-6-astra
python analysis/verify_astra_extraction.py
python analysis/check_source_archive.py
```

All three selected raw responses are now present and hash-verified. The cross-archive check also verifies their model/status/budget/date metadata, lengths, transfer response IDs and links to the registered V0 article and drawing hashes. Across the three extraction checks, 63 mass/CG rows match. This does not establish physical correctness, archive all historical API attempts, or supply the complete prompt/source-packet history. Original drawings are V0, not revised V1 drawings.
