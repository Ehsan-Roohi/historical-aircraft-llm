"""Inventory the original UIUC simulation files without treating them as test data."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FOLDER = ROOT/'analysis/references/uiuc_wright1903'
BASE = 'https://m-selig.ae.illinois.edu/apasim/Aircraft-uiuc/wrightFlyer1903-nl-v1/'


def curves(path):
    groups = []
    current = {'parameter':None,'points':[]}
    for line in path.read_text().splitlines():
        content = line.split('#')[0].strip()
        if not content:
            continue
        values = [float(v) for v in content.split()]
        if len(values) == 1:
            if current['points']:
                groups.append(current)
            current = {'parameter':values[0],'points':[]}
        elif len(values) == 2:
            current['points'].append(values)
        else:
            raise ValueError(f'Unexpected columns: {path}')
    if current['points']:
        groups.append(current)
    for group in groups:
        xs = [p[0] for p in group['points']]
        if not all(a < b for a,b in zip(xs,xs[1:])):
            raise ValueError(f'Nonmonotone abscissa: {path}')
    return groups


def main():
    files = []
    for name in ['aircraft.dat','wrightFlyerCDfa.dat','wrightFlyerCLfade.dat','wrightFlyerCmfa2.dat','wrightFlyerCmfade6.dat']:
        path = FOLDER/name
        row = {'file':name,'url':BASE+name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size}
        if name != 'aircraft.dat':
            row['curve_groups'] = [{'parameter':g['parameter'],'point_count':len(g['points']),
                                     'abscissa_range':[g['points'][0][0],g['points'][-1][0]]} for g in curves(path)]
        files.append(row)
    result = {'retrieved':'2026-09-26','kind':'Published simulation model with empirical and estimated components; NOT raw tunnel dataset',
              'files':files,'not_validated':['lookup-table interpretation in FlightGear code','reference point consistency','canard command convention','geometry correspondence to Run 33']}
    (FOLDER/'manifest.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
