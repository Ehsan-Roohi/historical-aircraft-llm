"""Two-panel fixed-control response, retaining raw moment offsets and mesh pairs."""
import hashlib
import json
import re
from html import escape
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'analysis/results/fixed_control_slope_selected_v1.json'
OUT=ROOT/'output/figures'
W,H=920,435
SCALE=180/25.4*300/W


def main():
    data=json.loads(SOURCE.read_bytes())
    assert data['completed_selected_cases']==20 and len(data['records'])==4
    rows={}
    for r in data['records']:
        key=(r['model'],r['nc'])
        assert key not in rows
        rows[key]=r
        for i,alpha in enumerate((3.5,3.75,4.0,4.25,4.5)):
            name=f'forces_{i}.txt'
            raw=(ROOT/r['selected_directory']/name).read_bytes()
            assert hashlib.sha256(raw).hexdigest()==r['force_sha256'][name]
            cm=float(re.search(rb'Cmtot\s*=\s*([-+\d.eE]+)',raw).group(1))
            assert cm==r['values'][str(alpha)]['Cmtot']
    image=Image.new('RGB',(round(W*SCALE),round(H*SCALE)),'white')
    draw=ImageDraw.Draw(image)
    svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="180mm" height="{180*H/W:.6f}mm" viewBox="0 0 {W} {H}">',
         '<title>Fixed-control pitch-moment response for Astra and Opus</title>',
         '<desc>Raw aerodynamic pitch-moment coefficients on two meshes near conditional candidates. Not exact equilibria or dynamic stability evidence.</desc>',
         f'<rect width="{W}" height="{H}" fill="white"/>']
    def text(x,y,value,size=19,anchor='start'):
        font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',round(size*SCALE))
        width=draw.textlength(value,font=font)
        left=x*SCALE-{'start':0,'middle':.5,'end':1}[anchor]*width
        assert 0<=left and left+width<=W*SCALE
        draw.text((left,y*SCALE),value,font=font,fill='black',anchor='lt')
        svg.append(f'<text x="{x}" y="{y+size*.8}" text-anchor="{anchor}" font-family="Arial, Helvetica, sans-serif" font-size="{size}">{escape(value)}</text>')
    def line(a,b,color='#222222',width=1):
        draw.line(tuple(v*SCALE for v in (*a,*b)),fill=color,width=max(1,round(width*SCALE)))
        svg.append(f'<line x1="{a[0]}" y1="{a[1]}" x2="{b[0]}" y2="{b[1]}" stroke="{color}" stroke-width="{width}"/>')
    def marker(x,y,nc):
        color='#666666' if nc==8 else '#0072b2'
        box=tuple(v*SCALE for v in (x-5,y-5,x+5,y+5))
        if nc==8:
            draw.ellipse(box,fill='white',outline=color,width=round(1.5*SCALE))
            svg.append(f'<circle cx="{x}" cy="{y}" r="5" fill="white" stroke="{color}" stroke-width="1.5"/>')
        else:
            draw.rectangle(box,fill=color)
            svg.append(f'<rect x="{x-5}" y="{y-5}" width="10" height="10" fill="{color}"/>')
    for model,left,right,lo,hi,label in (('astra',88,422,-.031,-.023,'(a) Astra V1'),('opus',568,902,.013,.021,'(b) Opus V1')):
        top,bottom=55,313
        text((left+right)/2,12,label,21,'middle')
        text(left,37,'Cm',17)
        def pos(alpha,cm):
            assert lo<=cm<=hi
            return left+(alpha-3.45)/1.1*(right-left),bottom-(cm-lo)/(hi-lo)*(bottom-top)
        for value in ([ -.030,-.028,-.026,-.024] if model=='astra' else [.014,.016,.018,.020]):
            y=pos(4,value)[1]
            line((left,y),(right,y),'#dddddd',.6)
            text(left-12,y-8,f'{value:.3f}',18,'end')
        for alpha in (3.5,3.75,4,4.25,4.5):
            x=pos(alpha,lo)[0]
            line((x,bottom),(x,bottom+5))
            text(x,bottom+12,f'{alpha:g}',18,'middle')
        line((left,top),(left,bottom)); line((left,bottom),(right,bottom))
        text((left+right)/2,350,'Angle of attack (deg)',20,'middle')
        for nc in (8,12):
            coords=[pos(float(a),v['Cmtot']) for a,v in rows[(model,nc)]['values'].items()]
            for a,b in zip(coords,coords[1:]):
                line(a,b,'#666666' if nc==8 else '#0072b2',1.4)
            for x,y in coords:
                marker(x,y,nc)
    for nc,x,label in ((8,272,'8 × 40'),(12,515,'12 × 80')):
        line((x,405),(x+36,405),'#666666' if nc==8 else '#0072b2',1.4)
        marker(x+18,405,nc)
        text(x+49,396,label,20)
    svg.append('</svg>')
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'fixed_control_response_v1.svg').write_text('\n'.join(svg),encoding='utf-8')
    image.save(OUT/'fixed_control_response_v1.png',dpi=(300,300))
    image.resize((W,H),Image.Resampling.LANCZOS).save(OUT/'fixed_control_response_v1_preview.png')
    manifest={'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'raw_force_files_checked':20,
              'coefficient_points':20,'print_width_mm':180,'minimum_font_pt':17*180/W*72/25.4,
              'vertical_range_span_each_panel':.008,'center_offsets_removed':False,
              'records':[{'model':r['model'],'nc':r['nc'],'ns':r['ns'],'control_deg':r['frozen_candidate']['control_deg'],
                          'values':r['values'],'center_residual':r['center_residual_at_original_candidate']} for r in data['records']],
              'scope':'Fixed commands near conditional candidates, not dynamically validated or fine-grid retrimmed states'}
    (OUT/'fixed_control_response_v1_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print('20 plotted Cm values match 20 hash-verified force files.')


if __name__=='__main__':
    main()
