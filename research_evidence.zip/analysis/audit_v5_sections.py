"""Independent algebraic checks of the received V5 section proposals.

The proposed formulas remain attributed to their models. This script checks
their stated geometric metrics; it does not compute aerodynamic performance.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path

EXPECTED_HASHES = {
    'gpt-6-astra': '39452d0e399a6fc7884b7dfc6c480ef2a657ebc6357d740cb39acb7e00825f61',
    'claude-fable-5-1': 'f42e6c956bd4f323480400c8136218662970edd47a9f03f411f84f1a98e829c3',
    'claude-opus-5-5': '378f2e74786667fdb2205cdcb2f220e2b97b7e74fe6f14ec48f4691024d77ebc',
}
REQUIRED = ('model', 'stage', 'parent', 'baseline_section', 'revised_sections',
            'station_assignment', 'manufacturing', 'frame_mapping', 'changes',
            'assumptions', 'requested_evaluator_tests', 'unresolved', 'status')


def p(x, last):
    return .2969 * math.sqrt(x) - .1260 * x - .3516 * x*x + .2843 * x**3 - last * x**4


def peak(fn):
    n = 100000
    i = max(range(n + 1), key=lambda j: fn(j / n))
    return {'x_over_c': i / n, 'value_over_c': fn(i / n)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--responses', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    receipt = {}
    for model, expected_hash in EXPECTED_HASHES.items():
        file = args.responses / model / 'response.json'
        raw = file.read_bytes()
        if hashlib.sha256(raw).hexdigest() != expected_hash:
            raise ValueError(f'V5 response hash mismatch: {model}')
        outer = json.loads(raw)
        response = json.loads(outer['response'])
        if outer['status'] != 'completed' or outer['model_returned'] != model:
            raise ValueError(f'Incomplete/misidentified response: {model}')
        missing = [k for k in REQUIRED if k not in response]
        if missing or response['stage'] != 'v5_section_candidate' or response['status'] != 'UNVALIDATED':
            raise ValueError(f'Invalid V5 schema: {model}: {missing}')
        receipt[model] = {'response_sha256': expected_hash, 'schema_complete': True,
                          'model_status': response['status']}

    a = 27 / (35 * math.sqrt(21))
    astra = lambda x: 2 * a * math.sqrt(x * (1 - x)) * (1 - 20*x/27)
    ap_a = peak(astra)
    receipt['gpt-6-astra']['geometry_checks'] = {
        'peak_thickness': ap_a,
        'claimed_t_over_c_0p12_matches': abs(ap_a['value_over_c'] - .12) < 1e-7,
        'claimed_peak_x_0p3_matches': abs(ap_a['x_over_c'] - .3) < 1e-5,
        'LE_radius_over_c': a*a/2,
        'parent_V4_frame_compatibility': 'NOT_ESTABLISHED: V5 uses local shaft +x; V4 used +z',
    }
    f = peak(lambda x: 10 * .12 * p(x, .1015))
    receipt['claude-fable-5-1']['geometry_checks'] = {
        'representative_t_parameter': .12,
        'actual_peak_thickness': f,
        'actual_TE_thickness_over_c': 10*.12*p(1, .1015),
        'claimed_TE_thickness_0p00252_matches': abs(10*.12*p(1, .1015) - .00252) < 1e-10,
        'old_new_max_thickness_location_changed': True,
        'wood_TE_thickness_m_at_c_0p2': .2*10*.12*p(1, .1015),
    }
    t = .10
    op = peak(lambda x: 10*t*p(x, .1036) + .006*x)
    true_te = 10*t*p(1, .1036) + .006
    claimed_te = .021*t + .006
    receipt['claude-opus-5-5']['geometry_checks'] = {
        'representative_t_parameter': t,
        'actual_peak_thickness': op,
        'actual_TE_thickness_over_c': true_te,
        'claimed_TE_thickness_over_c_at_t0p1': claimed_te,
        'TE_claim_error_over_c': claimed_te - true_te,
        'TE_claim_error_m_at_c0p26': (claimed_te - true_te)*.26,
        'V4_flat_lower_face_to_chord_beta_conversion_deg': 0,
        'model_claimed_nonzero_V4_beta_conversion': True,
        'disposition': 'REVISE_TE_AND_BETA_CLAIMS_BEFORE_GEOMETRY_ADOPTION',
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps({'source_job': '64962376', 'records': receipt,
                                       'aerodynamic_validation': False}, indent=2))
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
