"""Isolated, axial, uniform actuator disks: optimistic bounds, not propeller predictions."""
import hashlib
import json
import math
from pathlib import Path
from audit_mass_tables import summarize

ROOT = Path(__file__).resolve().parents[1]


def disk(thrust, speed, area, rho):
    if not all(math.isfinite(x) for x in [thrust,speed,area,rho]) or min(thrust,speed)<0 or min(area,rho)<=0:
        raise ValueError('Nonnegative thrust/speed and positive area/density required')
    induced = (math.sqrt(speed**2+2*thrust/(rho*area))-speed)/2
    power = thrust*(speed+induced)
    return {'induced_speed_m_s':induced, 'minimum_disk_power_W':power,
            'ideal_propulsive_efficiency':thrust*speed/power if power>0 else None}


def static_limit(power, area, rho):
    if not all(math.isfinite(x) for x in [power,area,rho]) or power<0 or min(area,rho)<=0:
        raise ValueError('Nonnegative power and positive area/density required')
    return (2*rho*area*power**2)**(1/3)


def main():
    inputs = ROOT/'analysis/power_scenarios_v1.json'
    scenarios = json.loads(inputs.read_text(encoding='utf-8'))
    definitions = {'astra':('gpt-6-astra',1,2.4), 'fable':('claude-fable-5-1',2,2.3), 'opus':('claude-opus-5-5',1,2.4)}
    rows=[]
    for case in scenarios['cases']:
        model=case['model']; folder,count,diameter=definitions[model]
        article=ROOT/f'received_2026-09-24/astra_fable_opus_designs/{folder}/article.md'
        massfile=ROOT/f'analysis/{model}_v1_extracted.json'
        mass=summarize(json.loads(massfile.read_text(encoding='utf-8')))['mass_kg']
        thrust=mass*9.80665/case['lift_drag_ratio']
        area=count*math.pi*diameter**2/4
        bound=disk(thrust,case['speed_m_s'],area,1.225)
        power=case['target_engine_shaft_power_W']
        rows.append({'model':model,'disk_count':count,'diameter_m':diameter,'total_area_m2':area,
                     'article_sha256':hashlib.sha256(article.read_bytes()).hexdigest(),
                     'mass_input_sha256':hashlib.sha256(massfile.read_bytes()).hexdigest(),
                     'mass_kg':mass,'speed_m_s':case['speed_m_s'],'assumed_required_thrust_N':thrust,
                     **bound,'source_assumed_efficiency':case['propeller_efficiency'],
                     'efficiency_above_ideal_bound':case['propeller_efficiency']>bound['ideal_propulsive_efficiency'],
                     'target_engine_power_W':power,
                     'ideal_static_thrust_ceiling_N':static_limit(power,area,1.225) if power is not None else None})
    out={'scope':'V0 disk sizes and aerodynamic assumptions with V1 masses; not propulsion matching or takeoff validation',
         'theory_source':'https://www.grc.nasa.gov/WWW/k-12/airplane/propanl.html',
         'input_sha256':hashlib.sha256(inputs.read_bytes()).hexdigest(), 'rho_kg_m3':1.225,
         'assumptions':'Uniform axial isolated disks, no swirl/profile/tip/transmission losses; equal loading for Fable disks. Ignore installed airframe interference.',
         'records':rows}
    (ROOT/'analysis/results/ideal_propulsion_bound_v1.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(rows,indent=2))


if __name__=='__main__':
    main()
