# Selected V1 clarification request archive

The three `.prompt.txt` files and `instructions.txt` are recovered exact-hash request texts, not new requests. `manifest.json` links each to the selected raw response ID/hash and V0 article hash. All reconstructed prompt/instruction SHA-256 values match the corresponding fields in the locally verified responses.

Recovery parses only the literal COMMON, QUESTIONS and INSTRUCTIONS assignments in `unity_jobs/run_geometry_clarifications.py`, then repeats its documented concatenation with the original UTF-8 article bytes. It does not import or execute that runner, call an API, read credentials, or infer missing prose. Prompt files have no added trailing newline. Existing differing files are never overwritten.

Run `python analysis/recover_clarification_prompts.py` from the project root to verify/recover the files. This proves consistency with the hashes stored in the selected response metadata, not an independent retrieval of remote prompt files or proof of the provider's complete HTTP payload. The currently archived runner is recorded by hash; remote byte identity of that entire script is not established by matching the prompt text.

The V1 user prompt includes the V0 article and model-specific discrepancy feedback. It does **not** include the SVG drawing or the full historical reading packet. The instruction to keep drawings immutable is not evidence that drawings were supplied. This is a fresh clarification request, not a continuation with earlier conversation memory.

`paper/geometry_clarification_requests.md` is a planning record, not the exact transmitted request. In particular, its draft common text asks for a revised drawing; the hash-matched actual prompt explicitly excludes SVG generation in this response. Do not quote the planning record as the experiment's exact prompt.

These files close the selected V1 prompt-text gap only. V0 generation prompts, the historical packet as actually supplied, all incomplete retry responses, and full transport/provider configuration remain separate provenance requirements. The source runner records intended reasoning settings, but text-hash agreement alone does not prove which settings the API accepted.
