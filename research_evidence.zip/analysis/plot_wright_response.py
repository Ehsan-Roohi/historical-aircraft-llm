"""Journal-style coefficient curves from the 12 audited reconstruction cases."""
import hashlib
import json
from html import escape
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'analysis/results/wright_reconstruction_audit_v1.json'
OUT=ROOT/'output/figures'
W,H=920,470
SCALE=180/25.4*300/W


def main():
    data=json.loads(SOURCE.read_bytes())
    assert data['verified_count']==len(data['records'])==12
    indexed={(r['canard_section'],r['alpha_deg'],r['canard_incidence_deg']):r['coefficients'] for r in data['records']}
    assert len(indexed)==12
    series=[]
    for section in ('flat','eiffel10_raw'):
        for alpha in (0,4):
            series.append({'section':section,'alpha':alpha,'points':[
                {'incidence':i,**indexed[(section,alpha,i)]} for i in (-4,0,4)]})
    image=Image.new('RGB',(round(W*SCALE),round(H*SCALE)),'white')
    draw=ImageDraw.Draw(image)
    svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="180mm" height="{180*H/W:.6f}mm" viewBox="0 0 {W} {H}">',
         '<title>Lift and pitch-moment response of a provisional Wright reconstruction</title>',
         '<desc>Twelve audited inviscid cases at three canard incidences, two angles of attack and two assumed canard sections. Not experimental data.</desc>',
         f'<rect width="{W}" height="{H}" fill="white"/>']
    def text(x,y,value,size=19,anchor='start'):
        font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',round(size*SCALE))
        width=draw.textlength(value,font=font)
        offset={'start':0,'middle':.5,'end':1}[anchor]
        left=x*SCALE-offset*width
        assert left>=0 and left+width<=W*SCALE,value
        draw.text((left,y*SCALE),value,font=font,fill='black',anchor='lt')
        svg.append(f'<text x="{x}" y="{y+size*.8}" text-anchor="{anchor}" font-family="Arial, Helvetica, sans-serif" font-size="{size}">{escape(value)}</text>')
    def line(a,b,color='#222222',width=1.2,dashed=False):
        x1,y1=a; x2,y2=b
        if dashed:
            length=((x2-x1)**2+(y2-y1)**2)**.5
            n=max(1,int(length/5))
            for k in range(0,n,2):
                t=k/n; u=min((k+1)/n,1)
                draw.line(((x1+t*(x2-x1))*SCALE,(y1+t*(y2-y1))*SCALE,(x1+u*(x2-x1))*SCALE,(y1+u*(y2-y1))*SCALE),fill=color,width=max(1,round(width*SCALE)))
        else:
            draw.line((x1*SCALE,y1*SCALE,x2*SCALE,y2*SCALE),fill=color,width=max(1,round(width*SCALE)))
        dash=' stroke-dasharray="5 5"' if dashed else ''
        svg.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="{width}"{dash}/>')
    def marker(x,y,section,alpha):
        color='#0072b2' if section=='flat' else '#b24c00'
        fill=color if section=='flat' else 'white'
        r=5
        box=((x-r)*SCALE,(y-r)*SCALE,(x+r)*SCALE,(y+r)*SCALE)
        if alpha==0:
            draw.ellipse(box,fill=fill,outline=color,width=round(1.7*SCALE))
            svg.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{color}" stroke-width="1.7"/>')
        else:
            draw.rectangle(box,fill=fill,outline=color,width=round(1.7*SCALE))
            svg.append(f'<rect x="{x-r}" y="{y-r}" width="{2*r}" height="{2*r}" fill="{fill}" stroke="{color}" stroke-width="1.7"/>')
    for left,right,key,lo,hi,ticks,title in (
        (76,421,'CLtot',.54,.87,[.55,.60,.65,.70,.75,.80,.85],'(a) Lift coefficient, CL'),
        (556,901,'Cmtot',-.09,.10,[-.08,-.04,0,.04,.08],'(b) Pitch-moment coefficient, Cm')):
        top,bottom=48,327
        text((left+right)/2,12,title,20,'middle')
        def pos(i,value):
            assert lo<=value<=hi
            return left+(i+5)/10*(right-left),bottom-(value-lo)/(hi-lo)*(bottom-top)
        for tick in ticks:
            y=pos(0,tick)[1]
            line((left,y),(right,y),'#d8dce0',.6)
            line((left-5,y),(left,y))
            text(left-11,y-8,'0' if tick==0 else f'{tick:.2f}',18,'end')
        for tick in (-4,0,4):
            x=pos(tick,lo)[0]
            line((x,bottom),(x,bottom+5))
            text(x,bottom+12,str(tick),19,'middle')
        line((left,top),(left,bottom));line((left,bottom),(right,bottom))
        text((left+right)/2,366,'Canard incidence (deg)',20,'middle')
        for s in series:
            coords=[pos(p['incidence'],p[key]) for p in s['points']]
            color='#0072b2' if s['section']=='flat' else '#b24c00'
            for a,b in zip(coords,coords[1:]):
                line(a,b,color,1.7,s['alpha']==4)
            for x,y in coords:
                marker(x,y,s['section'],s['alpha'])
    for s,x,y in zip(series,(92,92,510,510),(416,447,416,447)):
        color='#0072b2' if s['section']=='flat' else '#b24c00'
        line((x,y),(x+35,y),color,1.7,s['alpha']==4)
        marker(x+17,y,s['section'],s['alpha'])
        label='Flat' if s['section']=='flat' else 'Eiffel 10 proxy'
        text(x+48,y-9,f"{label}, α = {s['alpha']}°",19)
    svg.append('</svg>')
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'wright_response_v1.svg').write_text('\n'.join(svg),encoding='utf-8')
    image.save(OUT/'wright_response_v1.png',dpi=(300,300))
    image.resize((W,H),Image.Resampling.LANCZOS).save(OUT/'wright_response_v1_preview.png')
    manifest={'source':SOURCE.relative_to(ROOT).as_posix(),'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
              'series':series,'case_count':12,'coefficient_points':24,'print_width_mm':180,
              'minimum_font_pt':18*180/W*72/25.4,'font':'Arial, nonembedded SVG with Helvetica/sans-serif fallback',
              'scope':'Assumed geometry and sections; inviscid numerical cases, not historical validation.'}
    (OUT/'wright_response_v1_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print('Rendered 12 source cases (24 coefficient points).')


if __name__=='__main__':
    main()
