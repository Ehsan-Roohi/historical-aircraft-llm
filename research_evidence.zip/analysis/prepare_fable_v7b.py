#!/usr/bin/env python3
"""Freeze a compact, bounded clarification after the truncated V7 call."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'analysis/prompts_fable_v7b_frozen'
MODEL = 'claude-fable-5-1'
STAGE = 'v7b_fable_compact_disposition'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    parent_path = ROOT/'analysis/results/fable_v7_attempt01/responses'/MODEL/'response.json'
    parent_raw = parent_path.read_bytes()
    parent = json.loads(parent_raw)
    if parent['status'] != 'incomplete' or parent['stop_reason'] != 'max_tokens':
        raise ValueError('Expected bounded, truncated V7 response')
    v3raw = (ROOT/'analysis/v3b_propulsion_inputs.json').read_bytes()
    stations = next(x['stations'] for x in json.loads(v3raw)['records'] if x['model']==MODEL)
    if stations != [[.12,.10,64.8],[.25,.16,45.5],[.40,.19,32.5],[.55,.20,24.8],
                    [.70,.19,20],[.85,.17,16.7],[1,.14,14.3],[1.10,.10,13],[1.15,.04,12.5]]:
        raise ValueError('Archived V3b stations changed')
    instructions = ('Give one compact JSON object, no markdown and no extended reasoning. '
                    'Do not invent polar values, thrust, material strengths, engine data or validation. '
                    'Status must be UNVALIDATED. Keep the original and V2/V3b/V4/V5/V6 immutable. '
                    'Limit response to 1000 words.\n')
    prompt = (
        'Your previous V7 call (Unity 64967153) stopped at max_tokens=16000, so it is NOT an accepted revision. '
        'Give a concise, independently complete engineering disposition of these specific corrections. '
        'In V6 you silently changed five archived V3b chords; original archived [r,c,beta] is '
        + json.dumps(stations,separators=(',',':')) + '. V6 chords were '
        '[.14,.18,.20,.20,.19,.17,.14,.11,.08] m; treat these as a separately named, unadopted planform candidate. '
        'At tip c=.04 m, proposed constant 1.5 mm blunt TE means 3.75% chord, so do not silently adopt it. '
        'At root r=.12 m, V=13 m/s and rpm=600, Vrel=15.02827 m/s, not 14.03. '
        'V5 root alpha 0/2 degree accepted at both panel densities does not bracket the no-induction 4.913 degree incidence. '
        'Do not integrate those rows as thrust bounds. Your propeller-B local chord cross upper-surface vector points -z, '
        'so state the mirrored-frame parity correctly. Your truncated V7 text said: retract V6 planform, keep '
        'archived chords, retain V5-RN accepted section baseline, mark root aerodynamic contribution UNKNOWN, '
        'propose V7-RN-TE only pending tests, and correct propeller-B as mirrored left-handed. '
        'Confirm or change each choice with a brief reason. Return keys model,stage,parent_v6_sha256,'
        'parent_v7_attempt_sha256,disposition,archived_stations,tip_te_ratio,root_status,propeller_B_frame,'
        'proposed_tests,unresolved,status. No more than six proposed_tests. '
        'Parent V6 SHA-256 e0376f6ee668c13aaa1cc5ba6f0f1ff30308c4318bf56101cf94f6fc5c1b2e67; '
        'parent V7 attempt SHA-256 '+sha(parent_raw)+'. Stage '+STAGE+'. '
        'The next researcher gate is full radial section coverage, then BEM/shaft power; not flight certification.\n'
    )
    if OUT.exists():
        raise FileExistsError(OUT)
    OUT.mkdir(parents=True)
    (OUT/'instructions.txt').write_bytes(instructions.encode())
    (OUT/'prompt.txt').write_bytes(prompt.encode())
    manifest = dict(stage=STAGE,model_requested=MODEL,sent=False,maximum_output_tokens=6000,
                    parent_response_sha256=sha(parent_raw),parent_v3b_sha256=sha(v3raw),
                    instructions_sha256=sha(instructions.encode()),prompt_sha256=sha(prompt.encode()))
    (OUT/'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
    print(json.dumps({'prompt_sha256':manifest['prompt_sha256'],'prompt_characters':len(prompt)}))

if __name__=='__main__':
    main()
