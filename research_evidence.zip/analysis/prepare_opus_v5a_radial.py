#!/usr/bin/env python3
"""Freeze Opus V5A 2-D radial sections using the archived V3b chord table.

This is a numerical-screen input generator, not a propeller or flight model.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path

RHO = 1.225
MU = 1.81e-5
A_SOUND = 340.0
ANGLES = (-2, 0, 2, 4, 6, 8, 10, 12, 14)
EXPECTED_V6_SHA = '375680c87121f5fc9c260563ad56da4d4fd562e4521f2d3d1627d40795e2e7d3'
MODEL = 'claude-opus-5-5'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def polynomial(x):
    return .2969*math.sqrt(x)-.1260*x-.3516*x*x+.2843*x**3-.1036*x**4


def ordinates(x, t):
    m = min(.04, t/2)
    p = .4
    if x <= p:
        yc = m/p**2*(2*p*x-x*x)
    else:
        yc = m/(1-p)**2*(1-2*p+2*p*x-x*x)
    yt = 5*t*polynomial(x)+.003*x
    return yc+yt, yc-yt


def contour(t, density, label):
    xs = [(1-math.cos(math.pi*i/density))/2 for i in range(density+1)]
    upper = [(x, ordinates(x,t)[0]) for x in reversed(xs)]
    lower = [(x, ordinates(x,t)[1]) for x in xs[1:]]
    return label+'\n'+''.join(f'{x:.12f} {y:.12f}\n' for x,y in upper+lower)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--project-root', type=Path, default=Path('.'))
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    root = args.project_root.resolve()
    source = root/'design_revision_v6_attempt01/responses'/MODEL/'response.json'
    if sha(source) != EXPECTED_V6_SHA:
        raise ValueError('Opus V6 raw carrier hash mismatch')
    response = json.loads(json.loads(source.read_text(encoding='utf-8'))['response'])
    if response['stage'] != 'v6_propeller_geometry_repair' or response['status'] != 'UNVALIDATED':
        raise ValueError('Unexpected Opus stage/status')
    if response['disposition']['code'] != 'NO_CHANGE':
        raise ValueError('Opus V5A formula no longer frozen')
    v3path = root/'analysis/v3b_propulsion_inputs.json'
    baseline = next(row for row in json.loads(v3path.read_text(encoding='utf-8'))['records']
                    if row['model'] == MODEL)
    if len(baseline['stations']) != 8 or len(response['radial_station_table']) != 8:
        raise ValueError('Station count mismatch')
    if abs(polynomial(1)) > 1e-12:
        raise ValueError('Opus corrected polynomial must have closed P(1)')
    args.output.mkdir(parents=True, exist_ok=False)
    stations, sections = [], []
    for index, ((radius,chord,beta), row) in enumerate(zip(baseline['stations'],
                                                            response['radial_station_table'])):
        if abs(radius-row['r_m']) > 1e-9 or abs(beta-row['beta_deg']) > 1e-9:
            raise ValueError('V6/V3b radius or pitch mismatch at station '+str(index))
        t = row['t']
        if not math.isclose(t, [.30,.18,.13,.10,.09,.08,.07,.06][index], abs_tol=1e-12):
            raise ValueError('Unexpected Opus thickness schedule')
        speed = math.hypot(baseline['V'],2*math.pi*baseline['rpm']/60*radius)
        reynolds = RHO*speed*chord/MU
        incidence = beta-math.degrees(math.atan2(baseline['V'],2*math.pi*baseline['rpm']/60*radius))
        stem = f'opus_v5a_r{round(radius*100):03d}'
        stations.append(dict(stem=stem,family='opus_v5a',model=MODEL,
                             radius_m=radius,chord_m=chord,thickness_parameter=t,
                             beta_deg=beta,rpm=baseline['rpm'],
                             advance_speed_m_s=baseline['V'],
                             relative_speed_no_induction_m_s=speed,
                             reynolds_no_induction=reynolds,mach_no_induction=speed/A_SOUND,
                             geometric_incidence_no_induction_deg=incidence,
                             alpha_screen_deg=list(ANGLES),
                             input_qualification='isolated 2-D, no induction or installation effect'))
        for density in (80,120):
            name = f'{stem}_n{density}.dat'
            path = args.output/name
            path.write_text(contour(t,density,name),encoding='utf-8')
            sections.append(dict(file=name,sha256=sha(path),stem=stem,
                                 station_index=index,points=2*density+1))
    manifest = dict(stage='opus_v5a_first_radial_section_screen',
                    parent_v3b_sha256=sha(v3path),parent_v6_response_sha256=sha(source),
                    parent_v6_model_job='64966337',rho_kg_m3=RHO,
                    dynamic_viscosity_Pa_s=MU,speed_of_sound_m_s=A_SOUND,
                    stations=stations,sections=sections,
                    interpretation='2-D numerical screen only; no thrust, torque or flight result')
    (args.output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(stations=len(stations),contours=len(sections),
                          incidence_min=min(s['geometric_incidence_no_induction_deg'] for s in stations),
                          incidence_max=max(s['geometric_incidence_no_induction_deg'] for s in stations))))


if __name__ == '__main__':
    main()
