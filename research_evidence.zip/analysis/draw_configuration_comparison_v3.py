"""Make a print-resolution, metric planform comparison from frozen AVL inputs.

This is a lifting-surface diagram, not a reconstruction of unprovided airframe
members. Each aircraft keeps its own coordinate origin. The Wright CG is omitted.
"""

from pathlib import Path
import hashlib
import json
from xml.sax.saxutils import escape

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "output/figures_v2"
OUT.mkdir(parents=True, exist_ok=True)
INPUTS = [
    ("(a) Astra V1", "Tandem supporting surfaces", ROOT / "analysis/results/avl_fixed_control_slope04/astra_c12_s80/aircraft.avl"),
    ("(b) Fable V1", "Two wing decks; aft tail", ROOT / "analysis/results/avl_control_grid01/fable/aircraft.avl"),
    ("(c) Opus V1", "Two wing decks; aft tail", ROOT / "analysis/results/avl_fixed_control_slope06/opus_c12_s80/aircraft.avl"),
    ("(d) Wright 1903", "Reconstructed decks; canard", ROOT / "analysis/results/wright_reconstruction_family01/flat_i-4_a0/wing.avl"),
]

W, H = 2400, 1580
SCALE = 47.0  # identical x/y metric scale in every panel
BG, INK, MUTED, RULE = "#FFFFFF", "#173143", "#596B78", "#BECBD3"
BLUE, TAN, RED, BLUE_EDGE, TAN_EDGE = "#D7E8F0", "#F2DFC1", "#B42C37", "#22536B", "#885D26"
im = Image.new("RGB", (W, H), BG)
draw = ImageDraw.Draw(im)


def font(size, bold=False):
    names = ["arialbd.ttf", "DejaVuSans-Bold.ttf"] if bold else ["arial.ttf", "DejaVuSans.ttf"]
    for name in names:
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            pass
    return ImageFont.load_default()


F_TITLE, F_SUB, F_NOTE, F_SMALL = font(37, True), font(27), font(25), font(22)
svg = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
       '<rect width="100%" height="100%" fill="white"/>',
       '<style>text{font-family:Arial,Helvetica,sans-serif}</style>']


def text(x, y, value, color=INK, f=F_NOTE, size=27, weight="normal"):
    draw.text((x, y), value, fill=color, font=f)
    svg.append(f'<text x="{x}" y="{y+size}" font-size="{size}" font-weight="{weight}" fill="{color}">{escape(value)}</text>')


def line(points, color=RULE, width=2, dash=None):
    if dash:
        a, b = points
        dx, dy = b[0]-a[0], b[1]-a[1]
        dist = (dx*dx+dy*dy)**0.5
        step = dash[0]+dash[1]
        for t in range(0, int(dist), step):
            u0, u1 = t/dist, min(t+dash[0], dist)/dist
            p0 = (a[0]+u0*dx, a[1]+u0*dy)
            p1 = (a[0]+u1*dx, a[1]+u1*dy)
            draw.line([p0,p1], fill=color, width=width)
        svg.append(f'<line x1="{a[0]:.1f}" y1="{a[1]:.1f}" x2="{b[0]:.1f}" y2="{b[1]:.1f}" stroke="{color}" stroke-width="{width}" stroke-dasharray="{dash[0]},{dash[1]}"/>')
    else:
        draw.line(points, fill=color, width=width)
        a,b=points
        svg.append(f'<line x1="{a[0]:.1f}" y1="{a[1]:.1f}" x2="{b[0]:.1f}" y2="{b[1]:.1f}" stroke="{color}" stroke-width="{width}"/>')


def polygon(points, fill, outline):
    draw.polygon(points, fill=fill, outline=outline, width=4)
    pts=" ".join(f"{x:.1f},{y:.1f}" for x,y in points)
    svg.append(f'<polygon points="{pts}" fill="{fill}" stroke="{outline}" stroke-width="4"/>')


def rect(box, outline=RULE, fill=BG, width=2):
    draw.rectangle(box, fill=fill, outline=outline, width=width)
    x0,y0,x1,y1=box
    svg.append(f'<rect x="{x0}" y="{y0}" width="{x1-x0}" height="{y1-y0}" fill="{fill}" stroke="{outline}" stroke-width="{width}"/>')


def parse(path):
    rows=path.read_text(encoding="utf-8").splitlines()
    cg=tuple(map(float,rows[4].split()))
    surfaces=[]
    active=None
    for i,row in enumerate(rows):
        key=row.strip()
        if key=="SURFACE":
            active={"name":rows[i+1].strip(),"sections":[],"mirror":False}
            surfaces.append(active)
        elif key=="YDUPLICATE" and active is not None:
            active["mirror"]=True
        elif key=="SECTION" and active is not None:
            active["sections"].append(tuple(map(float,rows[i+1].split()[:5])))
    return cg,surfaces


records=[]
for index,(title,subtitle,path) in enumerate(INPUTS):
    col,row=index%2,index//2
    left,top=40+col*1180,45+row*760
    right,bottom=left+1135,top+710
    rect((left,top,right,bottom),outline="#AABDC8",width=3)
    text(left+32,top+22,title,f=F_TITLE,size=37,weight="bold")
    text(left+32,top+72,subtitle,color=MUTED,f=F_SUB,size=27)
    x0,y0=left+420,top+386
    line([(left+85,y0),(left+790,y0)],"#CAD5DC",2,(12,10))
    line([(x0,top+116),(x0,top+650)],"#E0E8EC",2,(10,10))
    cg,surfaces=parse(path)
    # Project the actual SECTION leading/trailing-edge stations, not a new
    # idealized wing shape. Two decks coincide in plan and are labelled as such.
    def project(x,y):
        return (x0+SCALE*x,y0+SCALE*y)
    for surface in sorted(surfaces,key=lambda s:min(q[2] for q in s["sections"])):
        sections=surface["sections"]
        if len(sections)<2:
            continue
        secondary=any(token in surface["name"].lower() for token in ("tail","canard","rear"))
        fill,edge=(TAN,TAN_EDGE) if secondary else (BLUE,BLUE_EDGE)
        for sign in ([1,-1] if surface["mirror"] else [1]):
            pts=[project(x,sign*y) for x,y,z,c,a in sections]
            pts += [project(x+c,sign*y) for x,y,z,c,a in reversed(sections)]
            polygon(pts,fill,edge)
    if index<3:
        cx,cy=project(cg[0],0)
        draw.ellipse((cx-9,cy-9,cx+9,cy+9),fill=RED)
        svg.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="9" fill="{RED}"/>')
        line([(cx+13,cy-10),(cx+82,cy-55)],RED,3)
        text(cx+84,cy-84,"CG",color=RED,f=F_NOTE,size=25,weight="bold")
    else:
        text(left+824,top+173,"CG not assigned",color=MUTED,f=F_SMALL,size=22)
    # Consistent key and horizontal scale are repeated in each panel so the
    # figure remains readable if panels are excerpted.
    rx=left+824
    text(rx,top+250,"Lifting surfaces",f=F_NOTE,size=25,weight="bold")
    rect((rx,top+304,rx+32,top+330),outline=BLUE_EDGE,fill=BLUE,width=2)
    text(rx+43,top+298,"Main wing(s)",f=F_SMALL,size=22)
    rect((rx,top+351,rx+32,top+377),outline=TAN_EDGE,fill=TAN,width=2)
    text(rx+43,top+346,"Fore/aft plane",f=F_SMALL,size=22)
    text(rx,top+418,"+x aft",color=MUTED,f=F_SMALL,size=22)
    line([(rx+95,top+435),(rx+182,top+435)],INK,3)
    line([(rx+182,top+435),(rx+169,top+425)],INK,3)
    line([(rx+182,top+435),(rx+169,top+445)],INK,3)
    text(rx,top+467,"+y right",color=MUTED,f=F_SMALL,size=22)
    line([(rx+123,top+487),(rx+123,top+541)],INK,3)
    line([(rx+123,top+541),(rx+113,top+529)],INK,3)
    line([(rx+123,top+541),(rx+133,top+529)],INK,3)
    line([(left+85,top+659),(left+85+2*SCALE,top+659)],INK,4)
    line([(left+85,top+650),(left+85,top+668)],INK,3)
    line([(left+85+2*SCALE,top+650),(left+85+2*SCALE,top+668)],INK,3)
    text(left+198,top+638,"2 m",f=F_SMALL,size=22)
    note="Two decks overlap in plan" if index in (1,2,3) else "Both surfaces carry lift"
    text(rx,top+577,note,color=MUTED,f=F_SMALL,size=22)
    records.append({"label":title,"input":path.relative_to(ROOT).as_posix(),"sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"cg_marker":index<3})

svg.append("</svg>")
stem=OUT/"configuration_comparison_v3"
im.save(stem.with_suffix(".png"),dpi=(300,300),optimize=True)
stem.with_suffix(".svg").write_text("\n".join(svg),encoding="utf-8")
stem.with_suffix(".json").write_text(json.dumps({"inputs":records,"scale_px_per_m":SCALE,"scope":"Metric plan of frozen solver lifting surfaces; no airframe or propulsion reconstruction. Wright panel has no historical CG marker."},indent=2)+"\n",encoding="utf-8")
print(stem.with_suffix(".png").relative_to(ROOT).as_posix())
