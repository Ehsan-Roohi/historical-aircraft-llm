"""Independent, reproducible arithmetic audit of the three V6 model replies."""
import hashlib
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RESPONSES = ROOT / 'design_revision_v6_attempt01' / 'responses'
MANIFEST = ROOT / 'analysis' / 'prompts_v6_propeller_feedback' / 'manifest.json'
V3B = ROOT / 'analysis' / 'v3b_propulsion_inputs.json'
OUT = ROOT / 'analysis' / 'results' / 'v6_propeller_response_audit_64966337.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def parse(model):
    folder = RESPONSES / model
    raw = (folder / 'response.json').read_bytes()
    carrier = json.loads(raw)
    outcome = json.loads((folder / 'outcome.json').read_text(encoding='utf-8'))
    request = json.loads((folder / 'request.json').read_text(encoding='utf-8'))
    try:
        content = json.loads(carrier['response'])
        json_valid = True
    except (ValueError, TypeError, KeyError):
        content = {}
        json_valid = False
    return dict(folder=folder, raw=raw, carrier=carrier, outcome=outcome,
                request=request, content=content, json_valid=json_valid)


def fable_p(x):
    return 0.2969*math.sqrt(x)-0.1260*x-0.3516*x*x+0.2843*x**3-0.1015*x**4


def opus_p(x):
    return 0.2969*math.sqrt(x)-0.1260*x-0.3516*x*x+0.2843*x**3-0.1036*x**4


def extrema(function):
    candidates = [(function(i/100000), i/100000) for i in range(100001)]
    return max(candidates)


def cross_z(xi, eta):
    return xi[0]*eta[1]-xi[1]*eta[0]


def main():
    manifest = json.loads(MANIFEST.read_text(encoding='utf-8'))
    v3b = {r['model']: r for r in json.loads(V3B.read_text(encoding='utf-8'))['records']}
    records = {r['model_requested']: r for r in manifest['records']}
    report = {'stage': 'v6_propeller_geometry_repair', 'slurm_array_job': '64966337',
              'raw_archive_sha256': 'fb9e48c8f0a251b25003a493f0f5d88cca71619264ad41978f67dc9366f1e841',
              'models': {}, 'independent_checks': {}, 'flight_validated': False}
    for model in records:
        data = parse(model)
        row = records[model]
        checks = {
            'transport_completed': data['carrier'].get('status') == 'completed',
            'outcome_completed': data['outcome'].get('status') == 'completed',
            'raw_response_sha_matches_outcome': sha(data['raw']) == data['outcome'].get('response_sha256'),
            'prompt_sha_matches_manifest': data['request'].get('prompt_sha256') == row['prompt_sha256'],
            'parent_sha_matches_manifest': data['request'].get('parent_response_sha256') == row['parent_response_sha256'],
            'response_is_json': data['json_valid'],
            'response_stage_matches': data['content'].get('stage') == manifest['stage'],
            'response_status_unvalidated': data['content'].get('status') == 'UNVALIDATED',
        }
        report['models'][model] = {
            'carrier_sha256': sha(data['raw']),
            'carrier_status': data['carrier'].get('status'),
            'model_returned': data['carrier'].get('model_returned'),
            'model_reported_disposition': data['content'].get('disposition'),
            'checks': checks,
            'all_provenance_checks_pass': all(checks.values()),
        }

    fb = parse('claude-fable-5-1')['content']
    stations = fb['radial_station_table']['stations']
    sample = fb['geometry_revision']['dimensionless_example_V6_RN_12_TE_at_r0p55']
    sample_rows = []
    for x, yu_claim, yl_claim in sample['points_x_yu_yl']:
        yc = 4*0.06*x*(1-x)
        yt = 5*0.12*fable_p(x)+sample['k']*x
        sample_rows.append({'x_over_c': x, 'yu_claim': yu_claim, 'yl_claim': yl_claim,
                            'yu_formula': yc+yt, 'yl_formula': yc-yt,
                            'yu_error': yu_claim-(yc+yt), 'yl_error': yl_claim-(yc-yt)})
    speeds = []
    for s in stations:
        r = s['r_m']
        speed = math.hypot(13, 2*math.pi*600/60*r)
        speeds.append({'r_m': r, 'claimed_m_s': s['V_rel_m_s'], 'calculated_m_s': speed,
                       'error_m_s': s['V_rel_m_s']-speed})
    k_rows = []
    chord_rows = []
    for s in stations:
        baseline_chord = next(x[1] for x in v3b['claude-fable-5-1']['stations']
                              if abs(x[0]-s['r_m']) < 1e-9)
        chord_rows.append({'r_m': s['r_m'], 'V3b_chord_m': baseline_chord,
                           'V6_claimed_chord_m': s['chord_m'],
                           'difference_m': s['chord_m']-baseline_chord})
        k_exact = 0.0015/(2*s['chord_m']) - 0.0105*s['t']
        k_claim = next(t['k'] for t in fb['geometry_revision']['sections']
                       if t['id'] == s['section_id'])
        k_rows.append({'r_m': s['r_m'], 'k_claim': k_claim, 'k_formula': k_exact,
                       'error': k_claim-k_exact})
    a = fb['assembly_frame']['propeller_A']['local_frame_for_blade_along_plus_z']
    b = fb['assembly_frame']['propeller_B']['local_frame_for_blade_along_plus_z']
    beta = math.radians(64.8)
    report['independent_checks']['fable'] = {
        'V5_polynomial_at_TE': fable_p(1),
        'V6_TE_formula_m_at_r0p55': 2*0.2*(5*0.12*fable_p(1)+sample['k']),
        'k_by_station': k_rows,
        'V3b_to_V6_chord_comparison': chord_rows,
        'number_of_chords_changed_despite_no_change_claim': sum(abs(r['difference_m']) > 1e-9 for r in chord_rows),
        'baseline_root_Re_at_nu_1p46e_minus5':
            math.hypot(13, 2*math.pi*600/60*0.12)*0.1/1.46e-5,
        'V6_claimed_root_Re_approx': stations[0]['Re_approx'],
        'sample_coordinate_check': sample_rows,
        'maximum_abs_sample_coordinate_error': max(max(abs(r['yu_error']),abs(r['yl_error'])) for r in sample_rows),
        'relative_speeds': speeds,
        'root_no_induction_incidence_deg': 64.8-math.degrees(math.atan2(13, 2*math.pi*600/60*0.12)),
        'root_accepted_angles_deg': [0,2],
        'root_operating_point_bracketed': False,
        'root_interval_0_to_2_is_not_valid_bound_at_4p913': True,
        'A_local_frame_cross_product_z': cross_z((math.sin(beta),math.cos(beta)),(-math.cos(beta),math.sin(beta))),
        'B_local_frame_cross_product_z': cross_z((math.sin(beta),-math.cos(beta)),(-math.cos(beta),-math.sin(beta))),
        'B_claimed_right_handed_but_is_left_handed': cross_z((math.sin(beta),-math.cos(beta)),(-math.cos(beta),-math.sin(beta))) < 0,
    }

    op = parse('claude-opus-5-5')['content']
    table = op['radial_station_table']
    t = 0.10
    xval, max_thick = None, None
    max_thick, xval = extrema(lambda x: 10*t*opus_p(x)+0.006*x)
    report['independent_checks']['opus'] = {
        'P_at_TE': opus_p(1),
        'V4_TE_over_c': 10*t*opus_p(1),
        'V5A_TE_over_c': 10*t*opus_p(1)+0.006,
        'V5A_TE_m_at_chord_0p26': (10*t*opus_p(1)+0.006)*0.26,
        'V5A_exact_max_thickness_over_c_t0p10': max_thick,
        'V5A_exact_max_thickness_location_t0p10': xval,
        'V5A_claimed_S4_max_thickness_over_c': next(s['V5A_tmax_c'] for s in table if s['station']=='S4'),
        'stations_missing_chord': [s['station'] for s in table if s['chord_m'] is None],
        'V3b_chords_by_radius_m': v3b['claude-opus-5-5']['stations'],
        'proposal_screened': False,
    }

    ast = parse('gpt-6-astra')['content']
    q = ast['assembly_frame']['C_to_V5']['Q']
    m = ast['assembly_frame']['V5_to_body']['M']
    bmat = [[sum(m[i][k]*q[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
    report['independent_checks']['astra'] = {
        'all_seven_stations_present': len(ast['radial_station_table']) == 7,
        'stations_missing_chord': [s['r_m'] for s in ast['radial_station_table'] if s['chord_m'] is None],
        'V3b_chords_by_radius_m': v3b['gpt-6-astra']['stations'],
        'M_times_Q': bmat,
        'claimed_B_equals_MQ': bmat == ast['assembly_frame']['C_to_body']['B'],
        'Astra_V5c_no_new_contour': not ast['geometry_revision']['new_sections'],
        'assembly_sign_convention_still_requires_baseline_confirmation': True,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(report, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    print(json.dumps({'output': str(OUT), 'all_provenance_checks_pass':
                      all(x['all_provenance_checks_pass'] for x in report['models'].values()),
                      'fable_sample_max_error': report['independent_checks']['fable']['maximum_abs_sample_coordinate_error'],
                      'fable_B_cross_z': report['independent_checks']['fable']['B_local_frame_cross_product_z'],
                      'opus_TE_m': report['independent_checks']['opus']['V5A_TE_m_at_chord_0p26']}, indent=2))


if __name__ == '__main__':
    main()
