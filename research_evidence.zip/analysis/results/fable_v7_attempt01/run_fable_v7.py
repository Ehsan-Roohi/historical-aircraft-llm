"""One bounded, hash-verified Fable V7 correction call; no auto-retry."""
import argparse
import hashlib
import json
import os
import signal
import sys
from datetime import datetime, timezone
from pathlib import Path

MODEL='claude-fable-5-1'
STAGE='v7_fable_planform_and_root_correction'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_new(path,obj):
    with path.open('x',encoding='utf-8') as stream:
        json.dump(obj,stream,ensure_ascii=False,indent=2)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--prompt-dir',type=Path,required=True)
    ap.add_argument('--output-dir',type=Path,required=True)
    ap.add_argument('--transport-dir',type=Path)
    ap.add_argument('--dry-run',action='store_true')
    args=ap.parse_args()
    manifest_bytes=(args.prompt_dir/'manifest.json').read_bytes()
    manifest=json.loads(manifest_bytes)
    if manifest['stage']!=STAGE or manifest['model_requested']!=MODEL or manifest['sent'] is not False:
        raise ValueError('Unexpected V7 manifest')
    prompt=(args.prompt_dir/'prompt.txt').read_bytes()
    instructions=(args.prompt_dir/'instructions.txt').read_bytes()
    if sha(prompt)!=manifest['prompt_sha256'] or sha(instructions)!=manifest['instructions_sha256']:
        raise ValueError('Prompt hash mismatch')
    metadata=dict(stage=STAGE,model_requested=MODEL,prompt_sha256=sha(prompt),
                  instructions_sha256=sha(instructions),manifest_sha256=sha(manifest_bytes),
                  parent_response_sha256=manifest['parent_response_sha256'],
                  parent_v3b_sha256=manifest['parent_v3b_sha256'],
                  wrapper_max_calls=1,wrapper_timeout_seconds=5400)
    if args.dry_run:
        print(json.dumps(dict(metadata,dry_run=True,prompt_characters=len(prompt))))
        return 0
    if args.transport_dir is None or not hasattr(signal,'SIGALRM'):
        raise RuntimeError('Linux transport and alarm support required')
    transport=args.transport_dir.resolve()/'frontier_wright_eval.py'
    metadata['transport_sha256']=sha(transport.read_bytes())
    key=os.environ.get('ANTHROPIC_API_KEY')
    if not key:
        raise RuntimeError('Required credential absent; no request made')
    sys.path.insert(0,str(transport.parent))
    from frontier_wright_eval import generate
    args.output_dir.mkdir(parents=True,exist_ok=True)
    case=args.output_dir/MODEL
    case.mkdir(exist_ok=False)
    metadata.update(started_utc=datetime.now(timezone.utc).isoformat(),
                    slurm_job_id=os.environ.get('SLURM_JOB_ID'))
    write_new(case/'request.json',metadata)
    (case/'prompt.txt').write_bytes(prompt)
    (case/'instructions.txt').write_bytes(instructions)

    def expired(signum,frame):
        raise TimeoutError('Bounded request expired')

    signal.signal(signal.SIGALRM,expired)
    signal.alarm(5400)
    try:
        result=generate(MODEL,prompt.decode('utf-8'),16000,key,
                        reasoning_effort='low',instructions=instructions.decode('utf-8'))
        write_new(case/'response.json',result)
        complete=result.get('status')=='completed' and bool(result.get('response'))
        outcome=dict(status='completed' if complete else 'incomplete',
                     response_sha256=sha((case/'response.json').read_bytes()),
                     model_returned=result.get('model_returned'),engineering_validation='not_evaluated')
    except Exception as error:
        complete=False
        outcome=dict(status='error_or_uncertain',error_type=type(error).__name__,automatic_retry=False)
    finally:
        signal.alarm(0)
    outcome['finished_utc']=datetime.now(timezone.utc).isoformat()
    write_new(case/'outcome.json',outcome)
    print(MODEL,outcome['status'],flush=True)
    return 0 if complete else 2


if __name__=='__main__':
    raise SystemExit(main())
