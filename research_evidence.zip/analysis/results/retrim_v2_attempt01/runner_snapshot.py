"""Bounded direct AVL retrim of unchanged V1 geometry, alpha=4 deg.

Predeclared: 2 bracket endpoints at frozen delta +/-0.1 deg, 1 secant
candidate, 1 independent candidate replay, then 2 fixed-control alpha
probes only if verified. Maximum six new solver processes/model, 300 s
each; no automatic retry. These are conditional numerical closure targets.
"""
import concurrent.futures
import hashlib
import json
import math
from pathlib import Path
import subprocess

from audit_mass_tables import summarize
from avl_reference_gate import parse
from flight_mechanics_revision_v2 import balance

ROOT=Path(__file__).resolve().parents[1]
EXE=ROOT/'analysis/tools/avl/avl352.exe'
OUT=ROOT/'analysis/results/retrim_v2_attempt01'


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def condition(aero, mass, area, chord, arm, alpha=4.):
    a=math.radians(alpha)
    cd=aero['CDind']+.05
    den=aero['CLtot']+cd*math.tan(a)
    if den<=0 or cd<0: raise ValueError('Nonphysical force-balance denominator')
    q=mass*9.80665/(area*den)
    v=math.sqrt(2*q/1.225)
    thrust=q*area*cd/math.cos(a)
    b=balance(aero['CLtot'],cd,aero['Cmtot'],v,thrust,alpha,mass,area,chord,arm)
    norms={'Rx_over_W':abs(b['horizontal_residual_N'])/(mass*9.80665),
           'Rz_over_W':abs(b['vertical_residual_N'])/(mass*9.80665),
           'Rm_over_Wcref':abs(b['pitch_residual_Nm'])/(mass*9.80665*chord)}
    return {'speed_m_s':v,'thrust_N':thrust,'balance':b,'normalized_absolute_residuals':norms,
            'numerical_acceptance':all(x<=.001 for x in norms.values()),
            'normalized_pitch_coefficient':aero['Cmtot']+arm*cd/(chord*math.cos(a)),
            'useful_power_W':q*area*cd*v}


def evaluate(work, source, delta, alpha):
    work.mkdir()
    for name in ['aircraft.avl','section.dat']: (work/name).write_bytes((source/name).read_bytes())
    cmd=f'load aircraft.avl\noper\nd1 d1 {delta:.12f}\na a {alpha:.12f}\nx\nft\nforces.txt\nfn\nsurface_forces.txt\nfs\nstrip_forces.txt\n\nquit\n'
    (work/'commands.txt').write_text(cmd,encoding='ascii')
    r={'delta_deg':delta,'alpha_deg':alpha,'timeout_seconds':300,'directory':work.relative_to(ROOT).as_posix()}
    try:
        p=subprocess.run([str(EXE)],input=cmd,cwd=work,capture_output=True,text=True,timeout=300,
                         creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        for n in ['stdout','stderr']: (work/(n+'.txt')).write_text(getattr(p,n),encoding='utf-8')
        r['returncode']=p.returncode
        r['status']='completed' if p.returncode==0 else 'failed'
        if p.returncode==0:
            raw=(work/'forces.txt').read_text()
            if abs(parse(raw,'Alpha')-alpha)>5.01e-6 or abs(parse(raw,'pitch')-delta)>5.01e-6:
                raise ValueError('Condition mismatch')
            r['aerodynamic_coefficients']={k:parse(raw,k) for k in ['CLtot','CDind','Cmtot','CZtot','CXtot']}
    except subprocess.TimeoutExpired as error:
        r['status']='timeout'
        for n in ['stdout','stderr']:
            v=getattr(error,n) or b''
            if isinstance(v,bytes): v=v.decode(errors='replace')
            (work/(n+'.txt')).write_text(v,encoding='utf-8')
        (work/'timeout.txt').write_text(str(error),encoding='utf-8')
    r['file_sha256']={p.name:sha(p) for p in sorted(work.iterdir()) if p.is_file()}
    (work/'summary.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
    return r


def solve_model(r, moments, power):
    name=r['model']; source=ROOT/r['selected_directory']; dest=OUT/name; dest.mkdir()
    geom=source/'aircraft.avl'
    if sha(geom)!=r['geometry_sha256'] or sha(source/'section.dat')!=r['foil_sha256']: raise ValueError('Frozen input changed')
    area,chord,_=map(float,geom.read_text().splitlines()[3].split())
    masspath=ROOT/f'analysis/{name}_v1_extracted.json'
    mass=summarize(json.loads(masspath.read_bytes()))['mass_kg']
    arm=moments[name.upper()+'-V1']['pitch_coefficient_per_N_forward_thrust']
    records=[]
    result={'model':name,'geometry_sha256':sha(geom),'foil_sha256':sha(source/'section.dat'),
            'mass_input_sha256':sha(masspath),'mass_kg':mass,'Sref_m2':area,'Cref_m':chord,
            'thrust_pitch_arm_m':arm,'records':records,'status':'in_progress'}
    def save():
        (dest/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    def run(tag,d,a=4.):
        row=evaluate(dest/tag,source,d,a)
        if row['status']=='completed': row['rebalanced_state']=condition(row['aerodynamic_coefficients'],mass,area,chord,arm,a)
        records.append(row); save()
        return row
    d0=r['frozen_candidate']['control_deg']
    low=run('01_bracket_low',d0-.1)
    if low['status']!='completed': result['status']='blocked_first_endpoint';save();return result
    high=run('02_bracket_high',d0+.1)
    if high['status']!='completed': result['status']='blocked_second_endpoint';save();return result
    fl=low['rebalanced_state']['normalized_pitch_coefficient'];fh=high['rebalanced_state']['normalized_pitch_coefficient']
    if fl*fh>0 or fh==fl:
        result['status']='no_bracket_within_predeclared_window';save();return result
    d=low['delta_deg']-fl*(high['delta_deg']-low['delta_deg'])/(fh-fl)
    candidate=run('03_direct_candidate',d)
    if candidate['status']!='completed': result['status']='candidate_failed';save();return result
    if not candidate['rebalanced_state']['numerical_acceptance']:
        result['status']='candidate_outside_tolerance_no_unplanned_iteration';save();return result
    verification=run('04_independent_verification',d)
    if verification['status']!='completed': result['status']='verification_failed';save();return result
    same=verification['file_sha256']['forces.txt']==candidate['file_sha256']['forces.txt']
    if not same or not verification['rebalanced_state']['numerical_acceptance']:
        result['status']='verification_not_accepted';save();return result
    accepted=verification['rebalanced_state']
    accepted['delta_deg']=d
    accepted['verification_FT_byte_identical']=same
    eta=power[name]['propeller_efficiency'];target=power[name]['target_engine_shaft_power_W']
    accepted['power']={'source_assumed_efficiency':eta,'shaft_power_required_W':accepted['useful_power_W']/eta,
                       'unverified_engine_target_W':target,'margin_to_target_W':target-accepted['useful_power_W']/eta,
                       'minimum_efficiency_at_target':accepted['useful_power_W']/target}
    result['accepted_state']=accepted
    result['status']='numerical_trim_accepted_not_physical_flight'
    minus=run('05_alpha_minus',d,3.75)
    plus=run('06_alpha_plus',d,4.25)
    if minus['status']=='completed' and plus['status']=='completed':
        slopes={k:(plus['aerodynamic_coefficients'][k]-minus['aerodynamic_coefficients'][k])/.5 for k in ['CLtot','Cmtot','CDind','CZtot']}
        result['fixed_control_alpha_probe']={'slopes_per_degree':slopes,
                 'effective_margin_percent_Cref':-100*slopes['Cmtot']/slopes['CLtot'],
                 'scope':'Fixed accepted delta, beta0, attached inviscid model; actual V,T held at accepted values when computing perturbation residuals.',
                 'perturbed_balances_at_fixed_V_T':[]}
        for row in [minus,plus]:
            aero=row['aerodynamic_coefficients']
            b=balance(aero['CLtot'],aero['CDind']+.05,aero['Cmtot'],accepted['speed_m_s'],accepted['thrust_N'],
                      row['alpha_deg'],mass,area,chord,arm)
            result['fixed_control_alpha_probe']['perturbed_balances_at_fixed_V_T'].append({'alpha_deg':row['alpha_deg'],'balance':b})
    else: result['fixed_control_alpha_probe']={'status':'incomplete_no_retry'}
    save();return result


def main():
    OUT.mkdir(exist_ok=False)
    (OUT/'runner_snapshot.py').write_bytes(Path(__file__).read_bytes())
    paths={k:ROOT/v for k,v in {'selection':'analysis/results/fixed_control_slope_selected_v1.json',
                               'moments':'analysis/results/longitudinal_geometry_v1.json',
                               'power':'analysis/power_scenarios_v1.json',
                               'protocol':'paper/revision_experiment_v2.md'}.items()}
    source=json.loads(paths['selection'].read_bytes())
    moments=json.loads(paths['moments'].read_bytes())
    power={r['model']:r for r in json.loads(paths['power'].read_bytes())['cases']}
    plan={'scope':__doc__,'solver_sha256':sha(EXE),'input_sha256':{k:sha(v) for k,v in paths.items()},
          'alpha_deg':4,'added_CD':.05,'added_drag_arm_m':0,'rho_kg_m3':1.225,
          'limits':{'max_evaluations_per_model':6,'max_trim_evaluations':4,'per_process_timeout_s':300},
          'acceptance':{'abs_Rx_over_W':.001,'abs_Rz_over_W':.001,'abs_Rm_over_Wcref':.001}}
    (OUT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
    rows=[r for r in source['records'] if r['nc']==12]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        result=list(pool.map(lambda r:solve_model(r,moments,power),rows))
    summary={'plan_sha256':sha(OUT/'plan.json'),'records':result}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({r['model']:{'status':r['status'],'accepted':r.get('accepted_state'),'derivatives':r.get('fixed_control_alpha_probe')} for r in result},indent=2))


if __name__=='__main__': main()
