"""Two bounded local AVL replays; unchanged frozen fine-mesh inputs.

No remote submission or model query. One attempt per model, each <=300 s.
FN is surface forces; FS is strip forces. Retain both, plus FT cross-check.
"""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess
from avl_reference_gate import parse

ROOT=Path(__file__).resolve().parents[1]
EXE=ROOT/'analysis/tools/avl/avl352.exe'
OUT=ROOT/'analysis/results/surface_loads_v2_attempt01'


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def run(row):
    model=row['model']
    source=ROOT/row['selected_directory']
    dest=OUT/model
    dest.mkdir()
    for name,key in [('aircraft.avl','geometry_sha256'),('section.dat','foil_sha256')]:
        if sha(source/name)!=row[key]: raise ValueError('Frozen source changed')
        (dest/name).write_bytes((source/name).read_bytes())
    delta=row['frozen_candidate']['control_deg']
    command=f'load aircraft.avl\noper\nd1 d1 {delta:.12f}\na a 4.0\nx\nft\nforces.txt\nfn\nsurface_forces.txt\nfs\nstrip_forces.txt\n\nquit\n'
    (dest/'commands.txt').write_text(command,encoding='ascii')
    result={'model':model,'source_directory':source.relative_to(ROOT).as_posix(),
            'timeout_seconds':300,'solver_sha256':sha(EXE),
            'geometry_sha256':sha(dest/'aircraft.avl'),'foil_sha256':sha(dest/'section.dat')}
    try:
        proc=subprocess.run([str(EXE)],input=command,cwd=dest,capture_output=True,text=True,timeout=300,
                            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        for name in ['stdout','stderr']: (dest/(name+'.txt')).write_text(getattr(proc,name),encoding='utf-8')
        result['returncode']=proc.returncode
        result['status']='completed' if proc.returncode==0 else 'failed'
        if proc.returncode==0:
            original=(source/'forces_2.txt').read_text()
            replay=(dest/'forces.txt').read_text()
            keys=['Alpha','pitch','Sref','Cref','Xref','Zref','CLtot','CDind','Cmtot','CXtot','CZtot']
            result['FT_delta']={k:parse(replay,k)-parse(original,k) for k in keys}
            if any(v!=0 for v in result['FT_delta'].values()): result['status']='coefficient_mismatch'
            result['surface_and_strip_files_present']=all((dest/n).is_file() for n in ['surface_forces.txt','strip_forces.txt'])
            if not result['surface_and_strip_files_present']: result['status']='missing_load_output'
    except subprocess.TimeoutExpired as exc:
        result['status']='timeout'
        for name in ['stdout','stderr']:
            value=getattr(exc,name) or b''
            if isinstance(value,bytes): value=value.decode(errors='replace')
            (dest/(name+'.txt')).write_text(value,encoding='utf-8')
        (dest/'timeout.txt').write_text(str(exc),encoding='utf-8')
    result['file_sha256']={p.name:sha(p) for p in sorted(dest.iterdir()) if p.is_file()}
    (dest/'run_summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    return result


def main():
    OUT.mkdir(exist_ok=False)
    (OUT/'runner_snapshot.py').write_bytes(Path(__file__).read_bytes())
    source=ROOT/'analysis/results/fixed_control_slope_selected_v1.json'
    rows=[r for r in json.loads(source.read_bytes())['records'] if r['nc']==12]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: results=list(pool.map(run,rows))
    summary={'scope':__doc__,'selection_sha256':sha(source),'records':results}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2))


if __name__=='__main__': main()
