# Version 2 — Researcher-assisted revision of the screw-driven biplane

**Provenance tags:** [V0]/[V1] inherited (immutable), [A2] new assumption, [D2] arithmetic in this response, [E] evaluator's conditional modern calculation, [MR] possible modern recall, UNKNOWN = not determinable.

## 1. What the evaluator record does and does not show

- The single "balance" is an *interpolated algebraic root* [E], not a fixed-control trim of the full model; `fixed_control_results` is empty. It shows that a balance of forces and pitching moment is arithmetically possible near V ≈ 12.8 m/s with ≈ −11.3° tail deflection and ≈ 10.0 kW shaft power at an *assumed* screw efficiency. It omits: hinge-moment/pilot load, propeller slipstream over the tail, downwash modelling detail, ground effect, structural deflection, dynamics (no inertias exist), and any airfoil data for the actual arc section.
- Two hardware faults were found and are confirmed by me [D2]: (a) the v1 all-moving tail P11 (continuous y ±1.70, LE hinge x 5.40) sweeps its trailing edge to z ≈ 0.98 at 12° and passes through both the fixed fin (z 0.80–1.80, y 0) and the body-frame envelope (y ±0.40, z 0.20–1.20, extending to x 6.60). Every trim candidate therefore "conflicted with the fin" because the hardware was impossible, not because of a coefficient. (b) The combined screw row P08 had centroid y = 0, which lies in the 0.90 m gap between the two discs — outside its own envelope.
- Trim at −11.3° against a ±12° limit leaves almost no nose-down control travel; that is a design defect, not a numerical curiosity.
- Engine power: the packet (Chanute 1894) states explicitly that available motor power per unit weight is *unsolved*. Nothing in v0/v1 established that an 85 kg engine delivers ~10 kW. That remains UNKNOWN and is carried as a **requirement**, not a capability.

## 2. Changes v1 → v2 (all listed in the JSON change_log)

1. **Tail hardware rebuilt.** Horizontal tail becomes two outboard halves (|y| 0.45–2.75, chord 1.00, x 5.40–6.40) on a common steel torque tube through the frame at x 5.65, z 0.775 (hinge at 25 % tail chord to reduce hinge moment). Area 4.60 m² (v1 3.40). Fixed fin moved onto the frame top (z 1.20–1.80, x 5.40–6.60); rudder hinge to the frame end x 6.60. Sweep check [D2]: at ±12° the halves occupy z 0.72–0.93 outboard of |y| 0.45; fin base z 1.20, frame side y ±0.40; rudder at 20° reaches |y| 0.31 only at x ≥ 7.4. No intersections.
2. **Tail rigging incidence −4°** relative to deck chords [A2] so estimated trim deflection is ≈ −2.3° (TE up), leaving ≈ 9–10° each way.
3. **Deck LE moved 1.00 → 0.95**; screws, posts, tip pivots move with it; skids shortened to x ≤ 2.75. Resulting CG ≈ 33 % chord (estimated neutral point ≈ 40 %, very uncertain — see §4).
4. **Ledger repaired:** P08 and P03 and P11 split left/right; P16 torque tube added (1 kg); all-up mass 295 kg; CG (1.561, 0, 0.754) from the same ledger.
5. **Body-frame lattice topology defined** (resolves v1 blocker B-1) as a Pratt-braced box girder tapering to the tail; member sizes are assumptions, allowables UNKNOWN from packet.
6. **Airfoil ordinates:** the v0 arc ordinates are not reproduced in this request; v2 adopts a circular arc of camber 1/20 [A2] pending reconciliation with v0. This single assumption drives most of the trim result (a 1/12 arc would require an unrealizable tail load — computed and rejected).

## 3. Estimated flight state (my simplified estimate, not validation)

ρ 1.225, V 13.0 m/s, q 103.5 Pa, W 2894 N. Wing CL 0.704 (α ≈ 4.9° geometric with arc zero-lift −5.7°), wing lift 3061 N; tail lift −203 N (CLt −0.43); thrust 412 N along body x (vertical component +36 N); drag 411 N (CD0 0.06 assumed for struts, wires, exposed operator and engine — likely optimistic). Wing moment about CG −810 N·m (camber term −0.157 dominates), thrust moment −19 N·m, tail +830 N·m; residuals within rounding. Required shaft power 5.35 kW propulsive → **10.7 kW (14 hp) at 50 % assumed screw efficiency**. Whether any engine of ≤ 85 kg available in 1898 does this is UNKNOWN.

## 4. Restoring tendency vs. pilot-stabilizable flight

Estimated fixed-control Cmα ≈ −0.29 /rad about the CG (static margin ≈ 0.07 c ≈ 0.13 m), from an assumed biplane ac at 0.25 c, downwash factor 0.6, tail efficiency 0.9. The neutral-point estimate could easily move ±5 % c with biplane interference, real arc section behaviour and slipstream over the tail (the screws sit directly upstream of the tail halves, so tail effectiveness changes with power). No mass moments of inertia exist, so **no dynamic (phugoid / short-period / lateral) statement can be made**; a positive margin here means only a restoring *tendency*, not safety. Whether the machine is pilot-stabilizable in gusts (Lilienthal's difficulty) cannot be established on paper.

## 5. Suspected modern recall
Lifting-line-type lift slopes, downwash and neutral-point formulae, thin-airfoil arc Cm = −πh/c, CD0 ~0.06, 50 % screw efficiency, and the sense that ~14 hp/85 kg engines existed around 1900–1903 are all post-1898 knowledge. They are labelled as estimates or assumptions, not period evidence.

```json
{
  "schema_version": "2.0",
  "parent_model": "v1 (immutable) — 'Proposal for a Man-Carrying, Screw-Driven Soaring Apparatus', clarification response; v0 article underlying",
  "coordinate_convention": "Body frame B, right-handed: origin = body-frame front cross-member at centreline (x=0, as in v1); x aft, y to operator's right, z up. Ground plane at level rest z=-0.75. Angles in degrees; positive control = trailing edge down (elevator), trailing edge to operator's left (rudder), left tip trailing edge down (tip panels). Pitching moment positive nose-up.",
  "units": "SI (m, kg, N, N·m, W, kg·m², deg)",
  "change_log": [
    {"id": "C2-01", "type": "A2", "change": "Horizontal tail rebuilt as two outboard halves |y| 0.45–2.75 on a torque tube through the frame; hinge moved from LE (x 5.40) to 25% chord (x 5.65, z 0.775); area 3.40 -> 4.60 m2", "reason": "Evaluator: all trim candidates conflicted with fixed fin; v1 continuous tail also passed through frame envelope. Verified by sweep check."},
    {"id": "C2-02", "type": "A2", "change": "Fixed fin moved onto frame top: x 5.40–6.60, z 1.20–1.80; rudder hinge x 6.30 -> 6.60, rudder x 6.60–7.50", "reason": "Clear tail sweep; fin no longer inside frame envelope."},
    {"id": "C2-03", "type": "A2", "change": "Tail rigging incidence -4.0 deg relative to deck chord (was UNKNOWN/0)", "reason": "Evaluator trim at -11.3 deg vs +/-12 limit; estimated v2 trim -2.3 deg."},
    {"id": "C2-04", "type": "A2", "change": "Deck LE 1.00 -> 0.95; spars 1.15/2.55; tip pivot x 1.505; screw plane 3.05 -> 3.00; skids shortened to x<=2.75", "reason": "Keep 0.20 m TE-to-disc gap; CG-to-chord relation retuned with new tail mass."},
    {"id": "C2-05", "type": "D2", "change": "Mass ledger: P03, P08, P11 split L/R; P16 torque tube 1 kg added; all-up 292 -> 295 kg; CG (1.561, 0, 0.754) = 33.0% chord", "reason": "Evaluator: centroid outside envelope (P08 combined y=0 in disc gap)."},
    {"id": "C2-06", "type": "A2", "change": "Body-frame lattice topology defined (Pratt box girder tapering aft)", "reason": "v1 blocker B-1."},
    {"id": "C2-07", "type": "A2", "change": "Deck section: circular arc camber 1/20, normalized ordinates supplied", "reason": "v0 ordinates not available in this request; camber drives trim; 1/12 arc computed to need CLt < -0.7, rejected."},
    {"id": "C2-08", "type": "D2", "change": "Engine power recorded as REQUIREMENT 10.7 kW shaft; capability UNKNOWN", "reason": "Evaluator: engine available power unestablished; packet (Chanute) says motor power/weight unsolved."},
    {"id": "C2-09", "type": "D2", "change": "Ground nose-up limit 21.2 -> 19.8 deg (rudder bottom at x 7.50)", "reason": "Consequence of C2-02."}
  ],
  "lifting_surfaces": [
    {
      "id": "P01_lower_deck",
      "type": "wing, single-surface arc, no stagger, no dihedral",
      "stations": [
        {"y": -5.75, "leading_edge_xyz": [0.95, -5.75, 0.00], "chord": 1.85, "incidence_deg": 0.0, "twist_deg": 0.0, "dihedral_deg": 0.0, "note": "aft-outboard corner rounded r=0.80 (V1)"},
        {"y": 0.0, "leading_edge_xyz": [0.95, 0.0, 0.00], "chord": 1.85, "incidence_deg": 0.0, "twist_deg": 0.0, "dihedral_deg": 0.0},
        {"y": 5.75, "leading_edge_xyz": [0.95, 5.75, 0.00], "chord": 1.85, "incidence_deg": 0.0, "twist_deg": 0.0, "dihedral_deg": 0.0}
      ],
      "section_normalized": {"x_c": [0.0, 0.25, 0.5, 0.75, 1.0], "upper_z_c": [0.0, 0.0375, 0.05, 0.0375, 0.0], "lower_z_c": [0.0, 0.0375, 0.05, 0.0375, 0.0], "note": "circular arc camber 1/20 [A2]; fabric single surface; v0 ordinates not reproduced here"},
      "area_m2": 21.00
    },
    {
      "id": "P02_upper_deck_fixed",
      "type": "wing, same section",
      "stations": [
        {"y": -4.25, "leading_edge_xyz": [0.95, -4.25, 1.85], "chord": 1.85, "incidence_deg": 0.0, "twist_deg": 0.0, "dihedral_deg": 0.0},
        {"y": 4.25, "leading_edge_xyz": [0.95, 4.25, 1.85], "chord": 1.85, "incidence_deg": 0.0, "twist_deg": 0.0, "dihedral_deg": 0.0}
      ],
      "section_normalized": "same as P01",
      "area_m2": 15.72
    },
    {
      "id": "P03_tip_panels_LR",
      "type": "pivoting outer panels of upper deck (roll control), same section",
      "stations": [
        {"y": "±4.25", "leading_edge_xyz": [0.95, "±4.25", 1.85], "chord": 1.85, "incidence_deg": "0 ± 8 differential", "twist_deg": 0.0, "dihedral_deg": 0.0},
        {"y": "±5.75", "leading_edge_xyz": [0.95, "±5.75", 1.85], "chord": 1.85, "incidence_deg": "same as root (rigid panel)", "twist_deg": 0.0, "dihedral_deg": 0.0, "note": "aft-outboard corner rounded r=0.80"}
      ],
      "section_normalized": "same as P01",
      "area_m2": "2 x 2.64 = 5.28 (total upper deck 21.00)"
    },
    {
      "id": "P11_horizontal_tail_LR",
      "type": "two all-moving flat-plate halves on common torque tube",
      "stations": [
        {"y": "±0.45", "leading_edge_xyz": [5.40, "±0.45", 0.775], "chord": 1.00, "incidence_deg": -4.0, "twist_deg": 0.0, "dihedral_deg": 0.0},
        {"y": "±2.75", "leading_edge_xyz": [5.40, "±2.75", 0.775], "chord": 1.00, "incidence_deg": -4.0, "twist_deg": 0.0, "dihedral_deg": 0.0}
      ],
      "section_normalized": {"x_c": [0.0, 0.5, 1.0], "upper_z_c": [0.0, 0.0, 0.0], "lower_z_c": [0.0, 0.0, 0.0], "note": "flat fabric-covered frame, thickness 0.05 assumed"},
      "area_m2": 4.60
    },
    {
      "id": "P12_fin",
      "type": "fixed vertical flat plate on frame top",
      "stations": [
        {"z": 1.20, "leading_edge_xyz": [5.40, 0.0, 1.20], "chord": 1.20, "incidence_deg": 0.0},
        {"z": 1.80, "leading_edge_xyz": [5.40, 0.0, 1.80], "chord": 1.20, "incidence_deg": 0.0}
      ],
      "section_normalized": "flat plate, thickness UNKNOWN",
      "area_m2": 0.72
    },
    {
      "id": "P13_rudder",
      "type": "vertical flat plate, hinge along z",
      "stations": [
        {"z": 0.80, "leading_edge_xyz": [6.60, 0.0, 0.80], "chord": 0.90},
        {"z": 1.80, "leading_edge_xyz": [6.60, 0.0, 1.80], "chord": 0.90}
      ],
      "section_normalized": "flat plate, thickness UNKNOWN",
      "area_m2": 0.90
    }
  ],
  "controls": [
    {
      "surface": "P11 horizontal tail (both halves together)",
      "hinge_axis": {"point": [5.65, 0.0, 0.775], "direction": [0, 1, 0]},
      "deflection_sign": "positive = trailing edge down (nose-down moment)",
      "limits_deg": [-12, 12],
      "rigging_offset_deg": -4.0,
      "mixing": "none",
      "linkage": "hand lever pivot (0.60, 0.30, 0.90), fore-aft; push-pull wires along frame top z 1.15 and bottom z 0.25 to horn on torque tube at x 5.65 (horn tips z 0.475 / 1.075); lever forward = TE down",
      "motion_envelope": "halves sweep x 5.40–6.40, z 0.72–0.93, |y| 0.45–2.75; clears frame (|y|<=0.40), fin (z>=1.20), rudder (x>=6.60)"
    },
    {
      "surface": "P13 rudder",
      "hinge_axis": {"point": [6.60, 0.0, 0.80], "direction": [0, 0, 1]},
      "deflection_sign": "positive = trailing edge to operator's left (nose right)",
      "limits_deg": [-20, 20],
      "mixing": "none",
      "linkage": "foot-bar pivot (0.60, 0, 0.30); wires along frame sides y ±0.38 z 0.70 to horn (6.80, ±0.20, 1.30)",
      "motion_envelope": "x 6.60–7.45, |y|<=0.31 at x 7.45, z 0.80–1.80; tail halves TE at x 6.40 not reached"
    },
    {
      "surface": "P03 tip panels (differential)",
      "hinge_axis": {"point": [1.505, 0.0, 1.95], "direction": [0, 1, 0], "note": "0.30 chord aft of LE"},
      "deflection_sign": "positive = left panel TE down, right panel TE up (roll right)",
      "limits_deg": [-8, 8],
      "mixing": "cross-connected: equal and opposite",
      "linkage": "same hand lever, lateral motion; wire up front post at (1.15, 0.90) to rocker on upper front spar (1.15, 0, 1.99); spanwise wires to horns (1.80, ±4.40, 2.10)",
      "motion_envelope": "TE excursion ±0.18 m at x 2.80; does not reach screw disc plane x 3.00"
    }
  ],
  "mass_items": [
    {"id": "P01", "name": "Lower deck (fixed)", "mass_kg": 21, "centroid_xyz": [1.78, 0.0, 0.06], "bounding": {"x": [0.95, 2.80], "y": [-5.75, 5.75], "z": [0.00, 0.14]}, "overlap": "none", "inertia": "UNKNOWN", "source": "V0 mass, V1 split, A2 position"},
    {"id": "P02", "name": "Upper deck fixed portion", "mass_kg": 15, "centroid_xyz": [1.78, 0.0, 1.91], "bounding": {"x": [0.95, 2.80], "y": [-4.25, 4.25], "z": [1.85, 1.99]}, "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "P03L", "name": "Left tip panel", "mass_kg": 3, "centroid_xyz": [1.78, -5.00, 1.91], "bounding": {"x": [0.95, 2.80], "y": [-5.75, -4.25], "z": [1.85, 1.99]}, "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "P03R", "name": "Right tip panel", "mass_kg": 3, "centroid_xyz": [1.78, 5.00, 1.91], "bounding": {"x": [0.95, 2.80], "y": [4.25, 5.75], "z": [1.85, 1.99]}, "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "P04", "name": "Posts and wires (6 post pairs at x 1.15, 2.55; y ±0.90, ±2.60, ±4.25)", "mass_kg": 13, "centroid_xyz": [1.85, 0.0, 1.00], "bounding": {"x": [1.15, 2.55], "y": [-4.25, 4.25], "z": [0.14, 1.85]}, "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "P05", "name": "Operator with clothing", "mass_kg": 75, "centroid_xyz": [0.50, 0.0, 0.75], "bounding": {"x": [0.15, 0.85], "y": [-0.30, 0.30], "z": [0.30, 1.40]}, "overlap": "inside P10 envelope; seat included in P10", "inertia": "UNKNOWN", "note": "seat travel ±0.15 in x"},
    {"id": "P06", "name": "Engine + cooling", "mass_kg": 85, "centroid_xyz": [1.30, 0.0, 0.72], "bounding": {"x": [0.95, 1.75], "y": [-0.35, 0.35], "z": [0.45, 1.15]}, "overlap": "inside P10 envelope", "inertia": "UNKNOWN"},
    {"id": "P07", "name": "Fuel tank + 20 min fuel", "mass_kg": 20, "centroid_xyz": [1.55, 0.0, 0.90], "bounding": {"x": [1.40, 1.75], "y": [-0.30, 0.30], "z": [0.95, 1.15]}, "overlap": "above engine, inside P10 envelope", "inertia": "UNKNOWN"},
    {"id": "P08L", "name": "Left screw", "mass_kg": 2.5, "centroid_xyz": [3.00, -1.60, 0.80], "bounding": {"x": [2.95, 3.05], "y": [-2.75, -0.45], "z": [-0.35, 1.95]}, "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "P08R", "name": "Right screw", "mass_kg": 2.5, "centroid_xyz": [3.00, 1.60, 0.80], "bounding": {"x": [2.95, 3.05], "y": [0.45, 2.75], "z": [-0.35, 1.95]}, "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "P09", "name": "Shafts and bevel boxes", "mass_kg": 10, "centroid_xyz": [2.27, 0.0, 0.80], "bounding": {"x": [1.75, 3.00], "y": [-1.60, 1.60], "z": [0.78, 0.82]}, "overlap": "continuous transverse shaft spans y; centroid inside", "inertia": "UNKNOWN"},
    {"id": "P10", "name": "Body frame lattice incl. seat and mounts", "mass_kg": 18, "centroid_xyz": [2.40, 0.0, 0.70], "bounding": {"x": [0.00, 6.60], "y": [-0.40, 0.40], "z": [0.20, 1.20]}, "overlap": "envelope contains P05–P07, P15 (separately massed)", "inertia": "UNKNOWN"},
    {"id": "P11L", "name": "Left tail half", "mass_kg": 4, "centroid_xyz": [5.90, -1.60, 0.775], "bounding": {"x": [5.40, 6.40], "y": [-2.75, -0.45], "z": [0.75, 0.80]}, "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "P11R", "name": "Right tail half", "mass_kg": 4, "centroid_xyz": [5.90, 1.60, 0.775], "bounding": {"x": [5.40, 6.40], "y": [0.45, 2.75], "z": [0.75, 0.80]}, "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "P12", "name": "Fixed fin", "mass_kg": 2, "centroid_xyz": [6.00, 0.0, 1.50], "bounding": {"x": [5.40, 6.60], "y": [-0.02, 0.02], "z": [1.20, 1.80]}, "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "P13", "name": "Rudder", "mass_kg": 2, "centroid_xyz": [6.95, 0.0, 1.30], "bounding": {"x": [6.60, 7.50], "y": [-0.02, 0.02], "z": [0.80, 1.80]}, "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "P14", "name": "Skids, 3 wheels, rear post, struts", "mass_kg": 12, "centroid_xyz": [1.50, 0.0, -0.50], "bounding": {"x": [-0.30, 3.35], "y": [-1.23, 1.23], "z": [-0.75, 0.20]}, "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "P15", "name": "Controls (lever, foot-bar, wires, horns)", "mass_kg": 2, "centroid_xyz": [2.50, 0.0, 0.70], "bounding": {"x": [0.60, 6.80], "y": [-0.40, 0.40], "z": [0.25, 2.10]}, "overlap": "routes inside P10 envelope; wires to tips", "inertia": "UNKNOWN"},
    {"id": "P16", "name": "Tail torque tube and bearings", "mass_kg": 1, "centroid_xyz": [5.65, 0.0, 0.775], "bounding": {"x": [5.63, 5.67], "y": [-0.50, 0.50], "z": [0.755, 0.795]}, "overlap": "passes through P10 envelope", "inertia": "UNKNOWN"}
  ],
  "mass_summary": {
    "total_mass_kg": 295,
    "sum_m_x": 460.46, "sum_m_y": 0.0, "sum_m_z": 222.395,
    "cg_xyz": [1.561, 0.0, 0.754],
    "cg_percent_chord_from_LE_0.95": 33.0,
    "cg_range_with_seat_travel_percent": [31.0, 35.1],
    "status": "every mass an unweighed assumption [V0/A1/A2]; symmetry assumed"
  },
  "propulsion": {
    "engine": {"type": "internal-combustion, 4-cyl assumed, water-cooled", "mass_kg": 85, "location": "P06", "crankshaft": "along x at z 0.80, output x 1.75", "power_requirement_W_shaft": 10700, "power_available": "UNKNOWN", "torque_curve": "UNKNOWN", "source": "packet gives no engine data; Chanute 1894 lists motor power/weight as unsolved; belief that ~11 kW/85 kg is near-feasible is modern recall [MR] and is not adopted as evidence"},
    "drive": "central bevel box (1.85,0,0.80); transverse shaft x 1.85 z 0.80 to outboard boxes (1.85, ±1.60, 0.80); longitudinal shafts to hubs (3.00, ±1.60, 0.80); one bevel pair reversed; conflict with truss bracing at y ±0.90, ±1.60 still unresolved (v1 B-4)",
    "propellers": {"count": 2, "hub_xyz": [[3.00, -1.60, 0.80], [3.00, 1.60, 0.80]], "diameter_m": 2.30, "disc_plane_x": 3.00, "blade_count": "UNKNOWN", "chord_pitch": "UNKNOWN", "rotation": "opposite hand", "clearances_m": {"disc_to_disc": 0.90, "to_body_side": 0.05, "to_ground": 0.40, "to_deck_TE": 0.20, "to_skid_end": 0.25}},
    "thrust_estimate": {"value_N": 412, "V_m_s": 13.0, "assumed_efficiency": 0.50, "propulsive_power_W": 5356, "method": "thrust = estimated drag; efficiency assumption only; no propeller model"}
  },
  "structural_members": {
    "material_evidence": "Packet contains no allowable stresses. Values below are assumptions [A2] possibly from modern handbooks [MR]; all UNVERIFIED.",
    "materials": {"ash": {"use": "longerons, spars", "allowable_bending_MPa": "UNKNOWN (assumed working 20)"}, "spruce": {"use": "posts", "allowable_compression_MPa": "UNKNOWN (assumed working 10)"}, "steel_wire_2mm": {"use": "bracing", "breaking_load_N": "UNKNOWN (assumed 2500)"}, "steel_tube_30x1.5mm": {"use": "tail torque tube", "allowable": "UNKNOWN"}},
    "nodes": {
      "F1": [0.00, -0.40, 0.20], "F2": [0.00, 0.40, 0.20], "F3": [0.00, -0.40, 1.20], "F4": [0.00, 0.40, 1.20],
      "F5": [1.15, -0.40, 0.20], "F6": [1.15, 0.40, 0.20], "F7": [1.15, -0.40, 1.20], "F8": [1.15, 0.40, 1.20],
      "F9": [2.55, -0.40, 0.20], "F10": [2.55, 0.40, 0.20], "F11": [2.55, -0.40, 1.20], "F12": [2.55, 0.40, 1.20],
      "F13": [3.20, -0.40, 0.20], "F14": [3.20, 0.40, 0.20], "F15": [3.20, -0.40, 1.20], "F16": [3.20, 0.40, 1.20],
      "F17": [4.90, -0.40, 0.40], "F18": [4.90, 0.40, 0.40], "F19": [4.90, -0.40, 1.20], "F20": [4.90, 0.40, 1.20],
      "F21": [6.60, -0.40, 0.60], "F22": [6.60, 0.40, 0.60], "F23": [6.60, -0.40, 1.20], "F24": [6.60, 0.40, 1.20],
      "T1": [5.65, -0.40, 0.775], "T2": [5.65, 0.40, 0.775],
      "S1": [1.15, -5.75, 0.00], "S2": [1.15, 5.75, 0.00], "S3": [2.55, -5.75, 0.00], "S4": [2.55, 5.75, 0.00],
      "S5": [1.15, -5.75, 1.85], "S6": [1.15, 5.75, 1.85], "S7": [2.55, -5.75, 1.85], "S8": [2.55, 5.75, 1.85]
    },
    "connectivity": [
      {"member": "lower longerons", "nodes": ["F1-F5-F9-F13-F17-F21", "F2-F6-F10-F14-F18-F22"], "section": "ash 40x40 mm"},
      {"member": "upper longerons", "nodes": ["F3-F7-F11-F15-F19-F23", "F4-F8-F12-F16-F20-F24"], "section": "ash 40x40 mm"},
      {"member": "verticals and cross members at each station", "nodes": "F1-F3, F2-F4, F1-F2, F3-F4 etc.", "section": "spruce 30x30 mm"},
      {"member": "diagonal wire bracing in every bay, all four faces", "section": "steel wire 2 mm, double"},
      {"member": "lower deck spars", "nodes": ["S1-S2 through F5/F6", "S3-S4 through F9/F10"], "section": "ash 60x30 mm laminated"},
      {"member": "upper deck spars", "nodes": ["S5-S6", "S7-S8"], "section": "ash 60x30 mm"},
      {"member": "interplane posts", "nodes": "at x 1.15 & 2.55, y ±0.90, ±2.60, ±4.25, z 0.14–1.85", "section": "spruce 35 mm round"},
      {"member": "tail torque tube", "nodes": ["T1-T2 extended to y ±0.50 with halves attached"], "section": "steel tube 30x1.5 mm"},
      {"member": "fin post/root", "nodes": "F19/F20 to F23/F24 top", "section": "spruce 25x25 mm"}
    ],
    "joints": "wire-wrapped and glued wooden joints with steel fittings at post feet and torque-tube bearings; strengths UNKNOWN"
  },
  "claimed_flight_state": {
    "status": "ESTIMATE by simplified method [A2/MR]; not a measurement, not independent validation",
    "rho_kg_m3": 1.225,
    "V_m_s": 13.0,
    "q_Pa": 103.5,
    "alpha_deg_body": 4.9,
    "controls_deg": {"tail_deflection": -2.3, "rudder": 0.0, "tip_panels": 0.0},
    "individual_surface_forces_N": {"wings_P01_P02_P03_lift": 3061, "wings_drag": 399, "tail_P11_lift": -203, "tail_drag": 12, "fin_rudder": 0},
    "thrust_N": {"along_body_x": 412, "vertical_component": 36},
    "drag_N": 411,
    "weight_N": 2894,
    "moment_terms_Nm_about_CG": {"wing_camber_Cm_ac": -1263, "wing_lift_offset_cg_minus_ac": 453, "thrust_line_above_cg_0.046m": -19, "tail_lift_x_arm_4.089": 830, "sum": 1},
    "residuals": {"vertical_N": 0, "horizontal_N": 1, "pitch_Nm": 1, "note": "closed by construction to rounding; real residual unknown"},
    "method": "wing CL_alpha 3.8/rad (biplane factor 0.8 on lifting-line AR 6.2), arc zero-lift -5.7 deg, Cm_ac = -pi*h/c = -0.157, ac at 0.25c; tail CL_alpha 4.38/rad, eta 0.9, downwash 2CL/(pi AR); CD0 0.06 assumed; efficiency 0.5"
  },
  "stability": {
    "reference_point": "CG (1.561, 0, 0.754)",
    "reference_chord_m": 1.85,
    "reference_area_m2": 42.0,
    "estimated_neutral_point_percent_chord": 40.1,
    "static_margin_chord": 0.071,
    "fixed_control_derivatives_per_rad": {"CL_alpha": 4.06, "Cm_alpha": -0.29, "Cm_delta_tail": -0.95, "Cm_q": -4.2, "Cn_beta": "UNKNOWN (fin 0.72 m2 small; side area of frame/posts unmodelled)", "Cl_beta": "~0 (zero dihedral); UNKNOWN", "Cl_delta_tips": "UNKNOWN"},
    "method": "linear thin-surface estimates, downwash factor 0.6, tail efficiency 0.9; biplane ac location and slipstream over tail not modelled",
    "damping_inertia_limitations": "No moments of inertia exist; no dynamic modes computed. Screws lie directly upstream of tail halves so tail power varies with throttle. Positive static margin is a restoring tendency only, not evidence of dynamic stability, gust tolerance or safety; pilot-stabilizable flight is a separate untested question (cf. Lilienthal 1893 difficulty)."
  },
  "launch_and_landing": {
    "ground_geometry": {"wheels": [[0.40, -1.20, -0.75], [0.40, 1.20, -0.75], [3.20, 0.0, -0.75]], "wheelbase_m": 2.80, "front_track_m": 2.40, "static_loads_kg": {"rear": 122, "front_each": 86.5}},
    "clearances_m": {"skid_bottom": 0.05, "disc_bottom": 0.40, "lower_deck": 0.75, "tail_TE": 1.50, "rudder_bottom": 1.55},
    "rotation_limit_nose_up_deg": 19.8,
    "rotation_limit_nose_down_deg": "UNKNOWN (skid upturn ambiguous)",
    "launch": "level firm ground, rolling start into wind; estimated lift-off 13–14 m/s; acceleration and roll distance UNKNOWN (thrust at low speed unmodelled)",
    "landing": "power reduced, glide to ground on wheels/skids; spring travel, skid flexure UNKNOWN"
  },
  "remaining_unknowns": [
    "Engine available power/torque curve and true mass",
    "Propeller blade geometry, thrust and efficiency at 13 m/s",
    "Actual arc section ordinates of v0 vs assumed 1/20 camber; lift and moment of the section",
    "Biplane ac location and interference; downwash at tail; slipstream effect on tail",
    "All component masses and moments of inertia",
    "Material allowables; wire preload; structural deflection under load",
    "Skid upturn geometry; spring stiffness",
    "Transverse drive shaft vs truss bracing (v1 B-4)",
    "Lateral-directional derivatives and roll effectiveness of tip panels",
    "Hinge moments and pilot force on all controls"
  ],
  "proposed_tests": [
    "Weigh each assembly separately; measure CG by suspension and inertias by bifilar pendulum",
    "Bench-brake the engine (Prony brake) for torque vs speed; run 20 min at required output",
    "Static thrust of screws on a stand with the actual drive; measure power absorbed",
    "Whirling-arm or towed-plate measurement of lift, drag and moment of the arc section and of a flat tail plate",
    "Tow the complete machine unpowered with ballast at pilot mass to observe balance and control response before any powered attempt",
    "Load-test frame, spars and tail torque tube to 3 x estimated flight loads",
    "Measure control hinge moments with the machine tethered in wind"
  ],
  "suspected_modern_recall": [
    "Lift-slope, downwash, neutral-point and Cm_q formulae",
    "Thin-airfoil circular-arc Cm_ac = -pi*h/c and zero-lift angle",
    "CD0 ~0.06 and screw efficiency 0.5",
    "Belief that ~11 kW engines under 85 kg existed by ~1903",
    "Preference for split tail halves on a torque tube and 25% hinge location"
  ]
}
```