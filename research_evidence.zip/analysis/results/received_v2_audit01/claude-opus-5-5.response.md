# Version 2: Revised Seated-Operator Tail-Balanced Pusher Biplane (Researcher-Assisted Revision)

**Status.** V1 above is the immutable parent. I have no memory of earlier requests. No experiment, test or flight has been performed, and none is claimed.

Values are tagged as follows:
- **[V1]** inherited from the parent.
- **[E]** taken from the evaluator's modern simplified computation (conditional, not historical).
- **[A2]** a new assumption made in this revision.
- **[D2]** my own arithmetic from the tags above. These are estimates, not validation.
- **UNKNOWN** cannot be determined from what exists.

## 1. Reading the attached evidence

**What the evaluator record supports, conditionally**

- **Longitudinal slope.** An attached-flow, inviscid vortex-lattice model of the V1 geometry, with the elevator frozen at −1.89° in the evaluator's own sign convention, gives:
  - CLα ≈ 0.0654 per degree and Cmα ≈ −0.0033 to −0.0034 per degree, both about the V1 CG (0.632, 0, 0.467).
  - These values hold on two meshes (8×40 and 12×80) and two step sizes. Mesh sensitivity is about 2% in Cmα.
- **Neutral point.** Implied at x ≈ 0.722–0.724 m, a margin of about 5.0–5.1% of the 1.8 m reference chord.
- **Restoring tendency at fixed speed and thrust.**
  - At α = 3.75° the pitch residual is +9.85 N·m (nose-up); at 4.25° it is −10.15 N·m.
  - This is a restoring tendency in that model only.
- **Direct retrim.** It converged at 16.86 m/s, thrust 476 N and elevator −1.91°. Two features matter:
  - The high thrust line produces about −206 N·m of nose-down moment.
  - The tailplane carries about −121 N of download to balance it.
- **Power.** Useful power is 8.01 kW, so shaft power at the assumed efficiency 0.60 is 13.35 kW. That exceeds an engine figure of 13 kW that is itself unverified.
- **Sign convention.** I read −1.9° as trailing edge up (consistent with the download), but the mapping is UNKNOWN until confirmed.

**What the record omits**

- Viscous section behaviour and stall.
- Body, strut and wire loads.
- Propwash and slipstream over the tail.
- Ground effect, structural flexibility and gusts.
- Any dynamic modes: short-period, phugoid and all lateral-directional motion.
- Control forces and hinge moments.
- Pilot workload.

A negative Cmα does **not** establish dynamic stability, controllability or safety. It is also distinct from whether a pilot could stabilise the machine. The 13 kW figure, the 0.60 efficiency and the drag case are assumptions, not period measurements. The packet contains no engine data at all.

**Actual area versus reference area**

- The actual projected planform is 19.8 m² per wing, 39.6 m² in total. This includes the 1.8 m² of balancing flaps and the lower-wing region behind the nacelle.
- 38.0 m² is only V0's normalisation constant, which subtracts a bookkeeping 1.6 m².
- Dimensional forces are unaffected by the choice of reference area.
- I cannot tell whether the evaluator's mesh included the 1.6 m² nacelle-shadowed region. If it did, its lift there may be optimistic. This is UNKNOWN.

## 2. Changes in V2, each with its reason

1. **Longer skid runners.** The flat runs now span x −1.50 to 1.60, with the upturn tip at (−1.90, z −0.55).
   - Reason: V1's own blocker said the nacelle nose hit the ground first, at 38.2°.
   - Nose-down first contact is now the runner tip, at atan(0.35/0.40) = 41.2°. The nacelle is guarded.
   - Mass rises by 2 kg.
2. **Booms, inner struts and dihedral joint moved outboard,** from y ±1.40 to ±1.60.
   - Reason: the propeller tip clearance to the upper boom spar was only 0.184 m.
   - It is now 0.383 m to the upper spar and 0.529 m to the lower spar, rigid and static.
   - Tip dihedral rise becomes 3.90 × tan 1° = 0.0681 m.
   - Boom mass is kept at 20 kg. The length change is under 1% and ignored.
3. **Rudder bottom raised** from z 0.64 to 0.68.
   - Reason: the gap to the torque tube was only 0.02 m. It is now 0.06 m.
   - Rudder area becomes 0.66 m²; total vertical area becomes 1.78 m².
4. **Section ordinates stated explicitly [A2].**
   - The V0 table is not in this request.
   - I list a camber line that matches every V0 point recoverable from V1 (max 0.068c; 0.0561c and 0.0378c upper, 0.0239c and 0.015c lower at 0.167c and 0.75c).
   - Intermediate points are new assumptions and may differ from the evaluator's input.
5. **Selected flight state moved to 15.0 m/s** at higher lift coefficient, to address power.
   - This is a proposal based on my own crude scaling. See Section 3.
6. **New tables.** Structure, materials and loaded clearances are tabulated, with allowables marked UNKNOWN.

**New mass ledger:** 360 kg. CG at (0.615, 0, 0.461), recomputed from the same leaf list as V1 with the G1 and T4 rows changed.

## 3. My estimates (not independent validation)

**Drag decomposition, inferred from the evaluator case**

- The evaluator's panel-surface induced drag is about 145 N of the 475 N total. I infer about 330 N of parasite drag, a CD0 of roughly 0.050 on 38 m².
- Scaling rules assumed: parasite drag ∝ V², induced drag ∝ W²/V², and constant span efficiency.

**Resulting state at 15 m/s and W = 3530 N**

| Quantity | Estimate |
|---|---|
| Parasite drag | ≈ 261 N |
| Induced drag | ≈ 185 N |
| Total drag | ≈ 446 N |
| Useful power | 6.70 kW |
| Shaft power at η = 0.60 | 11.2 kW |
| Lift coefficient CL (on 38 m²) | ≈ 0.665 |
| Angle of attack α (linear extrapolation) | ≈ 6.1° |

**Trim**

- Thrust moment ≈ −197 N·m. This requires an aerodynamic Cm of about +0.021.
- The higher α and the forward CG shift reduce the aerodynamic pitching moment, so more trailing-edge-up elevator is needed.
- My hand estimate of elevator effectiveness is |Cmδ| ≈ 0.011 per degree, uncertain by ±50%.
- Required elevator ≈ 3.4° trailing edge up, plausibly 2.3–7°. Travel limit is +20°.

**What this does not settle**

- Whether the sections remain attached at CL 0.67 is UNKNOWN. A stall margin cannot be claimed.
- Propeller efficiency at the new speed and thrust is UNKNOWN.
- The power "margin" of about 1.8 kW exists only relative to a 13 kW figure with no period evidence behind it.

**Static margin about the V2 CG:** about 6.1% of the reference chord, taking the V1 neutral point. The V2 geometry changes have not been re-run through any model.

## 4. Lateral-directional and dynamic questions: not established

- Dihedral is only 1°.
- My fin volume estimate is about 0.019, which may be small.
- The balancing flaps can produce adverse yaw.
- The high pusher thrust line couples power changes to pitch.

No roll, yaw or dynamic stability is claimed. Pilot-stabilised flight would require separate evidence that the operator's control inputs are fast and large enough, with tolerable forces.

```json
{
  "schema_version": "aircraft-revision-2.0",
  "parent_model": {
    "id": "V1_seated_operator_tail_balanced_biplane",
    "immutable": true,
    "parent_mass_kg": 358,
    "parent_cg_m": [0.632, 0.0, 0.467],
    "note": "V1 facts preserved unchanged; V2 changes listed in change_log. No memory of prior requests."
  },
  "coordinate_convention": {
    "origin": "lower-wing leading edge on centreline, chord horizontal",
    "x": "positive aft",
    "y": "positive starboard",
    "z": "positive up",
    "ground_plane_level_rest_z_m": -0.90,
    "angles": "alpha positive nose-up; elevator and flap deflection positive trailing-edge-up (V1 convention); rudder positive trailing-edge to port (nose-right command)",
    "evaluator_sign_mapping": "Evaluator elevator -1.89 deg assumed to equal +1.89 deg TE-up in this convention; UNKNOWN until confirmed"
  },
  "units": {"length": "m", "mass": "kg", "force": "N", "moment": "N m", "power": "W", "angle": "deg", "density": "kg/m^3", "g_m_s2": 9.80665},
  "change_log": [
    {"id": "C1", "item": "G1 skid runners", "from": "flat x -0.90..1.60, tip (-1.20,-0.60), 11 kg", "to": "flat x -1.50..1.60, tip (-1.90,-0.55), 13 kg", "reason": "V1 blocker: nacelle nose contacted ground first at 38.2 deg; now runner tip first at 41.2 deg"},
    {"id": "C2", "item": "booms, inner struts, dihedral joint", "from": "y +/-1.40", "to": "y +/-1.60", "reason": "prop tip to upper boom spar clearance 0.184 -> 0.383 m (rigid, static)"},
    {"id": "C3", "item": "dihedral tip rise", "from": 0.0716, "to": 0.0681, "reason": "consequence of C2"},
    {"id": "C4", "item": "rudder bottom z", "from": 0.64, "to": 0.68, "reason": "torque-tube gap 0.02 -> 0.06 m; rudder area 0.68 -> 0.66 m2"},
    {"id": "C5", "item": "section ordinates", "from": "V0 table (not present in this request)", "to": "explicit A2 table matching all recoverable V0 points", "reason": "completeness; may differ from evaluator input"},
    {"id": "C6", "item": "area bookkeeping", "from": "Sref 38.0 treated ambiguously", "to": "actual 39.6 m2 projected, Sref 38.0 normalisation only", "reason": "evaluator request"},
    {"id": "C7", "item": "selected flight state", "from": "16.86 m/s (evaluator retrim)", "to": "15.0 m/s proposed (own estimate)", "reason": "estimated shaft power 13.35 kW -> 11.2 kW at eta 0.60; stall margin UNKNOWN"},
    {"id": "C8", "item": "mass and CG", "from": "358 kg, (0.632,0,0.467)", "to": "360 kg, (0.615,0,0.461)", "reason": "C1 and C4 in same ledger"}
  ],
  "lifting_surfaces": [
    {
      "id": "LW", "name": "lower wing",
      "stations": [
        {"y": 0.0, "le_xyz": [0.0, 0.0, 0.0], "chord": 1.8, "incidence_deg": 0.0, "twist_deg": 0.0},
        {"y": 1.60, "le_xyz": [0.0, 1.60, 0.0], "chord": 1.8, "incidence_deg": 0.0, "twist_deg": 0.0},
        {"y": 5.50, "le_xyz": [0.0, 5.50, 0.0681], "chord": 1.8, "incidence_deg": 0.0, "twist_deg": 0.0}
      ],
      "mirrored_about_y0": true,
      "dihedral_deg": {"abs_y_0_to_1.60": 0.0, "abs_y_1.60_to_5.50": 1.0},
      "section": "S1",
      "actual_projected_area_m2": 19.8,
      "note": "Region abs_y<=0.444 behind nacelle retains covering; its lift contribution UNKNOWN (V0 1.6 m2 bookkeeping deduction)"
    },
    {
      "id": "UW", "name": "upper wing including balancing flaps",
      "stations": [
        {"y": 0.0, "le_xyz": [0.0, 0.0, 1.80], "chord": 1.8, "incidence_deg": 0.0, "twist_deg": 0.0},
        {"y": 1.60, "le_xyz": [0.0, 1.60, 1.80], "chord": 1.8, "incidence_deg": 0.0, "twist_deg": 0.0},
        {"y": 3.50, "le_xyz": [0.0, 3.50, 1.8332], "chord": 1.8, "incidence_deg": 0.0, "twist_deg": 0.0},
        {"y": 5.50, "le_xyz": [0.0, 5.50, 1.8681], "chord": 1.8, "incidence_deg": 0.0, "twist_deg": 0.0}
      ],
      "mirrored_about_y0": true,
      "dihedral_deg": {"abs_y_0_to_1.60": 0.0, "abs_y_1.60_to_5.50": 1.0},
      "section": "S1",
      "actual_projected_area_m2": 19.8,
      "flap_area_included_m2": 1.8
    },
    {
      "id": "HT", "name": "tailplane plus split elevator",
      "stations": [
        {"y": 0.0, "le_xyz": [4.50, 0.0, 0.60], "chord": 1.10, "incidence_deg": 0.0, "twist_deg": 0.0, "note": "elevator cut out abs_y<=0.25"},
        {"y": 0.25, "le_xyz": [4.50, 0.25, 0.60], "chord": 1.60, "incidence_deg": 0.0, "twist_deg": 0.0},
        {"y": 2.20, "le_xyz": [4.50, 2.20, 0.60], "chord": 1.60, "incidence_deg": 0.0, "twist_deg": 0.0}
      ],
      "mirrored_about_y0": true,
      "dihedral_deg": 0.0,
      "section": "FLAT",
      "actual_projected_area_m2": 6.79,
      "breakdown_m2": {"tailplane": 4.84, "elevator": 1.95}
    },
    {
      "id": "VT", "name": "fin plus rudder",
      "stations": [
        {"z": 0.60, "le_xyz": [4.80, 0.0, 0.60], "chord": 0.80, "note": "fin only below rudder bottom z 0.68"},
        {"z": 0.68, "le_xyz": [4.80, 0.0, 0.68], "chord": 1.30},
        {"z": 2.00, "le_xyz": [4.80, 0.0, 2.00], "chord": 1.30}
      ],
      "section": "FLAT",
      "actual_projected_area_m2": 1.78,
      "breakdown_m2": {"fin": 1.12, "rudder": 0.66}
    }
  ],
  "section_definitions": {
    "S1": {
      "source": "A2; matches V0 points recoverable from V1 (0.068c max; upper 0.0561c at 0.167c, 0.0378c at 0.75c; lower 0.0239c at 0.167c, 0.015c at 0.75c); intermediate points assumed",
      "x_over_c": [0.0, 0.05, 0.167, 0.30, 0.45, 0.60, 0.75, 0.90, 1.0],
      "upper_z_over_c": [0.0, 0.030, 0.0561, 0.066, 0.068, 0.058, 0.0378, 0.016, 0.0],
      "lower_z_over_c": [0.0, 0.008, 0.0239, 0.030, 0.030, 0.024, 0.015, 0.006, 0.0],
      "thickness_note": "thin cambered double-surface section; spar depth limited to ~0.036c-0.042c between surfaces"
    },
    "FLAT": {"source": "A2", "description": "thin flat braced fabric surface, thickness ~0.03 m at frame"}
  },
  "controls": [
    {"id": "ELEV", "surface": "T2 split elevator joined by torque tube", "hinge_axis": [[5.60, -2.20, 0.60], [5.60, 2.20, 0.60]], "chord_m": 0.50, "sign": "+ = TE up = nose-up", "limits_deg": [-15, 20], "mixing": "none", "linkage": "column fore/aft +/-0.15 m at grip; cables via pulleys (0.15,+/-0.30,-0.25), lower-wing rear spar to (1.35,+/-1.60,0.05), lower boom spars to horns at (5.60,+/-1.60,0.75/0.45)", "motion_envelope": "TE z 0.771 (full up) to 0.471 (full down) at x~6.07; min ground clearance 1.371 at level rest"},
    {"id": "FLAPS", "surface": "W3 balancing flaps upper wing outboard", "hinge_axis_starboard": [[1.35, 3.50, 1.884], [1.35, 5.50, 1.919]], "hinge_axis_port": [[1.35, -3.50, 1.884], [1.35, -5.50, 1.919]], "chord_m": 0.45, "sign": "+ = TE up; opposed", "limits_deg": [-15, 15], "mixing": "mechanically opposed via balance cable along upper rear spar", "linkage": "wheel on column, cables down column, out to (1.35,+/-1.60,0.07), up rear struts, outboard to horns (1.40,+/-4.50,1.894+/-0.12)", "motion_envelope": "TE z change +/-0.116", "adverse_yaw": "possible; UNKNOWN magnitude"},
    {"id": "RUDDER", "surface": "T4", "hinge_axis": [[5.60, 0.0, 0.68], [5.60, 0.0, 2.00]], "chord_m": 0.50, "sign": "+ = TE to port, nose right", "limits_deg": [-25, 25], "mixing": "none", "linkage": "foot bar pivot (-1.45,0,-0.25), cables along elevator route to (5.40,+/-1.60,0.60) then inboard to horns (5.60,+/-0.15,0.72)", "motion_envelope": "TE y +/-0.211; bottom 0.06 above torque tube top"},
    {"hinge_moments_and_stick_forces": "UNKNOWN", "cable_stretch_and_friction": "UNKNOWN"}
  ],
  "mass_items": [
    {"id": "O1", "name": "operator seated", "mass": 70, "centroid": [-0.90, 0, 0.30], "bbox": [[-1.5, -0.4], [-0.25, 0.25], [-0.2, 1.0]], "overlap": "sits on N2; no double count", "inertia": "UNKNOWN"},
    {"id": "N1", "name": "nacelle frame and covering", "mass": 10, "centroid": [-0.70, 0, 0.00], "bbox": [[-1.6, 0.2], [-0.35, 0.35], [-0.35, 0.40]], "overlap": "envelope contains O1,N2,K1 volumes; masses separate", "inertia": "UNKNOWN"},
    {"id": "N2", "name": "seat", "mass": 2, "centroid": [-0.75, 0, -0.15], "bbox": [[-0.95, -0.55], [-0.22, 0.22], [-0.25, -0.05]], "overlap": "inside N1 envelope", "inertia": "UNKNOWN"},
    {"id": "K1", "name": "cockpit controls", "mass": 3, "centroid": [-1.20, 0, 0.00], "bbox": [[-1.55, -0.95], [-0.30, 0.30], [-0.30, 0.45]], "overlap": "inside N1 envelope", "inertia": "UNKNOWN"},
    {"id": "K2", "name": "cables pulleys horns", "mass": 3, "centroid": [2.50, 0, 0.50], "bbox": "distributed along routes", "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "E1", "name": "engine and chain drive", "mass": 75, "centroid": [0.25, 0, 0.28], "bbox": [[0.0, 0.55], [-0.30, 0.30], [0.05, 0.55]], "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "E2", "name": "radiators 2x10", "mass": 20, "centroid": [0.30, 0, 0.45], "bbox": [[0.20, 0.40], [-0.35, 0.35], [0.30, 0.60]], "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "E3", "name": "fuel tank and fuel", "mass": 15, "centroid": [0.50, 0, 0.60], "bbox": [[0.40, 0.60], [-0.15, 0.15], [0.52, 0.68]], "overlap": "none; fuel fraction UNKNOWN", "inertia": "UNKNOWN"},
    {"id": "S1", "name": "shaft bearings brackets", "mass": 8, "centroid": [1.256, 0, 0.90], "bbox": [[0.30, 2.00], [-0.25, 0.25], [0.12, 1.83]], "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "P1", "name": "hub and two blades", "mass": 12, "centroid": [2.10, 0, 0.90], "bbox": [[2.00, 2.20], [-1.20, 1.20], [-0.30, 2.10]], "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "W1", "name": "lower wing", "mass": 34, "centroid": [0.75, 0, 0.107], "bbox": [[0.0, 1.8], [-5.5, 5.5], [0.0, 0.191]], "overlap": "none; centroid z kept from V1 (dihedral change <0.001 m effect)", "inertia": "UNKNOWN"},
    {"id": "W2", "name": "upper wing fixed", "mass": 30, "centroid": [0.64, 0, 1.911], "bbox": [[0.0, 1.8], [-5.5, 5.5], [1.80, 1.991]], "overlap": "excludes W3", "inertia": "UNKNOWN"},
    {"id": "W3", "name": "balancing flaps 2x2", "mass": 4, "centroid": [1.575, 0, 1.874], "bbox": [[1.35, 1.80], [-5.5, 5.5], [1.82, 1.99]], "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "W4", "name": "interplane struts 12", "mass": 8, "centroid": [0.825, 0, 0.984], "bbox": "x 0.30,1.35; y +/-1.60,+/-3.40,+/-5.30", "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "W5", "name": "wire bracing", "mass": 4, "centroid": [0.83, 0, 0.96], "bbox": "wing cellule", "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "B1", "name": "tail booms 4 spars", "mass": 20, "centroid": [3.48, 0, 0.61], "bbox": [[1.35, 5.60], [-1.60, 1.60], [0.05, 1.20]], "overlap": "none; length change <1% ignored", "inertia": "UNKNOWN"},
    {"id": "T1", "name": "tailplane", "mass": 7, "centroid": [5.05, 0, 0.60], "bbox": [[4.50, 5.60], [-2.20, 2.20], [0.585, 0.615]], "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "T2", "name": "elevator", "mass": 3, "centroid": [5.85, 0, 0.60], "bbox": [[5.60, 6.10], [-2.20, 2.20], [0.47, 0.77]], "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "T3", "name": "fin", "mass": 3, "centroid": [5.20, 0, 1.30], "bbox": [[4.80, 5.60], [0, 0], [0.60, 2.00]], "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "T4", "name": "rudder", "mass": 2, "centroid": [5.85, 0, 1.34], "bbox": [[5.60, 6.10], [-0.211, 0.211], [0.68, 2.00]], "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "G1", "name": "skid runners 2x6.5", "mass": 13, "centroid": [-0.21, 0, -0.82], "bbox": [[-1.90, 1.60], [-0.95, 0.95], [-0.90, -0.55]], "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "G2", "name": "wheels and axles", "mass": 8, "centroid": [0.45, 0, -0.75], "bbox": [[0.30, 0.60], [-1.05, 1.05], [-0.90, -0.60]], "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "G3", "name": "gear posts and struts", "mass": 4.5, "centroid": [0.35, 0, -0.45], "bbox": [[-0.60, 1.35], [-0.90, 0.90], [-0.80, 0.10]], "overlap": "none", "inertia": "UNKNOWN"},
    {"id": "G4", "name": "tail skid and braces", "mass": 1.5, "centroid": [5.50, 0, 0.30], "bbox": [[4.50, 5.50], [-1.60, 1.60], [0.00, 0.60]], "overlap": "none", "inertia": "UNKNOWN"}
  ],
  "mass_summary": {
    "total_mass_kg": 360.0,
    "sum_x_moment_kg_m": 221.315,
    "sum_z_moment_kg_m": 165.933,
    "cg_m": [0.6148, 0.0, 0.4609],
    "weight_N": 3530.4,
    "method": "V1 sums minus old G1 (11 kg; 2.2, -9.35) plus new G1 (13 kg; -2.73, -10.66) plus T4 z change (+0.04)",
    "all_masses": "assumptions, none weighed",
    "whole_aircraft_inertia": "UNKNOWN"
  },
  "propulsion": {
    "engine": {"type": "UNKNOWN (V0 implies liquid-cooled internal combustion via radiators)", "mass_kg_incl_chain": 75, "power_curve": [{"rpm": "UNKNOWN", "shaft_power_W": 13000, "source": "unverified target assumption; no engine evidence in the 1898 packet"}], "torque_curve": "UNKNOWN"},
    "drive": {"type": "chain", "engine_sprocket_xyz": [0.25, 0, 0.35], "shaft_sprocket_xyz": [0.35, 0, 0.90], "ratio": "UNKNOWN", "losses": "UNKNOWN"},
    "propeller": {"arrangement": "single pusher", "axis": [[2.10, 0, 0.90], "along -x thrust"], "radius_m": 1.20, "blades": 2, "disc_plane_x": 2.10, "swept_envelope_x": [2.02, 2.18], "planform_pitch_section": "UNKNOWN", "mass_kg": 12, "rpm": "UNKNOWN"},
    "thrust_estimate": {"required_N_at_V2_state": 448.0, "efficiency_assumed": 0.60, "shaft_power_required_W": 11163, "minimum_efficiency_at_13kW": 0.515, "momentum_theory_ideal_efficiency_bound": 0.93, "method": "D2 estimate; propeller not designed or measured"}
  },
  "structural_members": {
    "nodes": {
      "LF0": [0.30, 0, 0.101], "LF1": [0.30, 1.60, 0.101], "LF2": [0.30, 3.40, 0.132], "LF3": [0.30, 5.30, 0.164],
      "LR0": [1.35, 0, 0.068], "LR1": [1.35, 1.60, 0.068], "LR2": [1.35, 3.40, 0.099], "LR3": [1.35, 5.30, 0.131],
      "UF0": [0.30, 0, 1.843], "UF1": [0.30, 1.60, 1.843], "UF2": [0.30, 3.40, 1.874], "UF3": [0.30, 5.30, 1.906],
      "UR0": [1.35, 0, 1.827], "UR1": [1.35, 1.60, 1.827], "UR2": [1.35, 3.40, 1.858], "UR3": [1.35, 5.30, 1.890],
      "BL0": [1.35, 1.60, 0.05], "BU0": [1.35, 1.60, 1.20], "BJ": [4.50, 1.60, 0.60], "BE": [5.60, 1.60, 0.60],
      "note": "starboard shown; port mirrored (y -> -y)"
    },
    "members": [
      {"id": "spars_lower", "connect": ["LF0-LF1-LF2-LF3", "LR0-LR1-LR2-LR3"], "section": "spruce box ~0.06 x 0.04 m (A2)", "material_allowable": "UNKNOWN; no period test data in packet"},
      {"id": "spars_upper", "connect": ["UF0-UF1-UF2-UF3", "UR0-UR1-UR2-UR3"], "section": "spruce box ~0.06 x 0.04 m (A2)", "material_allowable": "UNKNOWN"},
      {"id": "struts", "connect": ["LF1-UF1", "LF2-UF2", "LF3-UF3", "LR1-UR1", "LR2-UR2", "LR3-UR3"], "section": "spruce ~0.05 x 0.025 m (A2)", "material_allowable": "UNKNOWN"},
      {"id": "wires", "connect": "diagonals in each bay and drag/anti-drag wires (pattern A2)", "section": "steel wire ~2.5 mm (A2)", "material_allowable": "UNKNOWN"},
      {"id": "booms", "connect": ["BL0-BJ", "BU0-BJ", "BJ-BE"], "section": "tube OD 0.05 (A2)", "material_allowable": "UNKNOWN; cross-bracing at x>=3.0 layout UNKNOWN"}
    ],
    "joints": "strut sockets and wire lugs, forms UNKNOWN; dihedral joint at y +/-1.60 on both wings",
    "load_estimate_D2": "1 g lift per wing ~1700-1920 N; ultimate factor, bending distribution and deflections not computed",
    "structural_adequacy": "UNKNOWN"
  },
  "claimed_flight_state": {
    "status": "proposed estimate only, not solved in any aerodynamic model, not flight",
    "rho": 1.225, "V": 15.0, "alpha_deg": 6.1, "beta_deg": 0.0,
    "controls_deg": {"elevator_TE_up": 3.4, "elevator_uncertainty_range": [2.3, 7.0], "flaps": 0.0, "rudder": 0.0},
    "individual_surface_forces_N": {"lower_wing_lift": 1712, "upper_wing_lift": 1921, "tail_lift": -150, "vertical_tail_side": 0, "method": "wing split in evaluator ratio 1.1224; tail load rough estimate"},
    "thrust_N": 448.0, "thrust_horizontal_N": 446.5, "thrust_vertical_N": 47.7,
    "drag_N": {"total": 446.5, "induced": 185.3, "parasite": 261.2, "parasite_source": "inferred from evaluator illustrative case (~330 N at 16.86 m/s), scaled V^2"},
    "lift_aero_N": 3482.7, "CL_on_Sref38": 0.665,
    "moment_terms_Nm_about_cg": {"thrust": -196.7, "aerodynamic_required": 196.7},
    "residuals": {"Fx_N": 0.0, "Fz_N": 0.0, "My_Nm": 0.0, "note": "zero by construction of linear extrapolation, not by solution"},
    "method": "linear extrapolation from evaluator V1 derivatives; hand estimate Cm_delta ~0.011/deg (+/-50%); ignores viscous stall, propwash, body loads, V2 geometry changes"
  },
  "stability": {
    "reference_point_m": [0.6148, 0, 0.4609], "Sref_m2": 38.0, "Cref_m": 1.8, "Bref_m": 11.0,
    "fixed_control_derivatives": {"CL_alpha_per_deg": 0.0654, "Cm_alpha_per_deg_estimate": -0.0040, "neutral_point_x_m": 0.724, "static_margin_frac_Cref": 0.061},
    "method": "evaluator VLM on V1 geometry and CG, shifted by D2 to V2 CG; V2 not re-run",
    "evaluator_restoring_probe": "at fixed V,T: +9.85 N m at 3.75 deg, -10.15 N m at 4.25 deg (V1)",
    "damping_inertia_limitations": "pitch damping, inertia and all dynamic modes UNKNOWN; positive margin does not establish dynamic stability",
    "lateral_directional": "not established; dihedral 1 deg; fin volume ~0.019 (D2); flap adverse yaw UNKNOWN",
    "pilot_stabilisability": "separate question; UNKNOWN",
    "thrust_pitch_coupling": "power change of dT gives about -0.439*dT N m about the CG"
  },
  "launch_and_landing": {
    "takeoff": "ground roll on wheels over level ground; rotation of ~6 deg needed for proposed CL; liftoff speed UNKNOWN (stall UNKNOWN)",
    "rotation_stop": "tail skid at x 5.50, contact at 13.0 deg nose-up about runner aft end",
    "loaded_clearances_rigid_m": {"prop_tip_ground_level": 0.60, "prop_tip_ground_6deg": 0.544, "prop_tip_ground_13deg": 0.472, "prop_tip_upper_boom_spar": 0.383, "prop_tip_lower_boom_spar": 0.529, "prop_envelope_to_wing_TE_axial": 0.22, "rudder_to_torque_tube": 0.06, "wingtip_roll_contact_deg": 11.9, "nose_down_first_contact": "runner tip at 41.2 deg, nacelle guarded"},
    "deformation": "gear, turf, wing, boom and blade deflection UNKNOWN; clearances are static and rigid",
    "landing": "on skids at low sink; no wingtip skids; nose-over risk reduced, not eliminated"
  },
  "remaining_unknowns": [
    "engine existence, mass and power in 1898",
    "propeller design and efficiency",
    "section lift, drag and stall",
    "parasite drag",
    "control effectiveness and hinge moments",
    "evaluator elevator sign mapping",
    "whether evaluator mesh included the nacelle-shadowed 1.6 m2",
    "material allowables and joint strength",
    "inertias and dynamic modes",
    "lateral-directional behaviour",
    "gust response",
    "ground and flexibility deflections",
    "fuel fraction and operator position variation"
  ],
  "proposed_tests": [
    "weigh every component and suspend the assembly to measure CG (not performed)",
    "engine brake test for power versus rpm and mass (not performed)",
    "static and towed propeller thrust tests on a stand (not performed)",
    "whirling-arm or tow tests of the S1 section and cellule for lift/drag and stall (not performed)",
    "sandbag proof loading of the wing cellule and booms (not performed)",
    "ballasted unmanned glides of the complete cellule to observe pitch and roll behaviour (not performed)",
    "towed, tethered low-height runs with control-deflection checks before any powered attempt (not performed)"
  ],
  "suspected_modern_recall": [
    "vortex-lattice and static-margin concepts",
    "tail download trim of a high thrust line",
    "pusher chain-drive biplane layout resembling early twentieth-century machines",
    "aileron-like balancing flaps (not in packet)",
    "trussed biplane cellule resembling post-1896 gliders (not in packet)",
    "fin-volume and adverse-yaw reasoning",
    "momentum-theory propeller bound"
  ]
}
```