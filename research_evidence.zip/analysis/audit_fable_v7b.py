#!/usr/bin/env python3
"""Check provenance and explicit arithmetic of the compact Fable disposition."""
import hashlib
import json
import math
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
CASE=ROOT/'analysis/results/fable_v7b_attempt01/responses/claude-fable-5-1'
PROMPTS=ROOT/'analysis/prompts_fable_v7b_frozen'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    manifest=json.loads((PROMPTS/'manifest.json').read_text())
    request=json.loads((CASE/'request.json').read_text())
    carrier=json.loads((CASE/'response.json').read_text())
    outcome=json.loads((CASE/'outcome.json').read_text())
    response=json.loads(carrier['response'])
    v3raw=ROOT/'analysis/v3b_propulsion_inputs.json'
    stations=next(x['stations'] for x in json.loads(v3raw.read_text())['records'] if x['model']=='claude-fable-5-1')
    v7=ROOT/'analysis/results/fable_v7_attempt01/responses/claude-fable-5-1/response.json'
    checks={
      'prompt_hash':sha(PROMPTS/'prompt.txt')==manifest['prompt_sha256']==request['prompt_sha256'],
      'instructions_hash':sha(PROMPTS/'instructions.txt')==manifest['instructions_sha256']==request['instructions_sha256'],
      'manifest_hash':sha(PROMPTS/'manifest.json')==request['manifest_sha256'],
      'v3b_parent_hash':sha(v3raw)==manifest['parent_v3b_sha256']==request['parent_v3b_sha256'],
      'v7_parent_hash':sha(v7)==manifest['parent_response_sha256']==request['parent_response_sha256']==response['parent_v7_attempt_sha256'],
      'v6_parent_hash':response['parent_v6_sha256']=='e0376f6ee668c13aaa1cc5ba6f0f1ff30308c4318bf56101cf94f6fc5c1b2e67',
      'carrier_complete':carrier['status']=='completed' and carrier['stop_reason']=='end_turn' and outcome['status']=='completed',
      'model_returned':carrier['model_returned']=='claude-fable-5-1'==outcome['model_returned'],
      'response_hash':sha(CASE/'response.json')==outcome['response_sha256'],
      'stage_and_status':response['stage']=='v7b_fable_compact_disposition' and response['status']=='UNVALIDATED',
      'archived_stations':response['archived_stations']==stations,
      'tip_te_ratio':math.isclose(response['tip_te_ratio']['ratio'],.0015/.04,rel_tol=0,abs_tol=1e-12) and response['tip_te_ratio']['adopted'] is False,
      'root_relative_speed':math.isclose(response['root_status']['V_rel_m_s'],math.hypot(13,2*math.pi*600/60*.12),abs_tol=.001),
      'root_unbracketed':response['root_status']['accepted_alpha_rows_deg']==[0,2] and response['root_status']['brackets_operating_point'] is False and response['root_status']['aerodynamic_contribution']=='UNKNOWN',
      'frame_not_validated':response['propeller_B_frame']['validated'] is False,
    }
    result={'stage':'v7b_fable_compact_disposition','job_id':'64967771',
            'checks':checks,'all_checks_pass':all(checks.values()),
            'engineering_validation':False,'propeller_performance_calculated':False,
            'qualification':'Complete model correction, not an independently validated propeller design'}
    out=ROOT/'analysis/results/fable_v7b_audit_64967771.json'
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    return 0 if result['all_checks_pass'] else 2

if __name__=='__main__':
    raise SystemExit(main())
