"""Audit explicit transcription without repairing model-authored defects."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def audit(data):
    parts = data['parts']
    ids = [p['id'] for p in parts]
    if len(set(ids)) != len(ids):
        raise ValueError('Duplicate part IDs')
    if any(p['m'] <= 0 for p in parts):
        raise ValueError('Non-positive mass')
    mass = sum(p['m'] for p in parts)
    moments = [sum(p['m'] * p['cg'][i] for p in parts) for i in range(3)]
    cg = [m / mass for m in moments]
    outside = []
    for part in parts:
        if part['bbox'] is not None:
            for i, (lo, hi) in enumerate(part['bbox']):
                if not lo <= part['cg'][i] <= hi:
                    outside.append({'part':part['id'],'axis':'xyz'[i], 'cg':part['cg'][i], 'bounds':[lo,hi]})
    refs = data['aerodynamic_references']
    # x-aft -> body x-forward; vertical lift at x_body has pitch moment x_body*L.
    wing_arm = cg[0] - refs['wing'][0]
    tail_arm = cg[0] - refs['horizontal_tail'][0]
    thrust_height = cg[2] - .8  # z-down coordinate of forward force line.
    return {'mass_kg':mass,'mass_moments_kg_m':moments,'cg_source_axes_m':cg,
            'out_of_bounds_centroids':outside,
            'pitch_moment_coefficients_m':{'wing_upward_lift':wing_arm,'tail_upward_lift':tail_arm,'forward_thrust':thrust_height},
            'geometry_status':'inconsistent as specified; not repaired',
            'flight_status':'undetermined: free aerodynamic moments, forces, control and thrust capability missing'}


def main():
    src=ROOT/'analysis/fable_v1_extracted.json'
    raw=src.read_bytes()
    result=audit(json.loads(raw))
    result['extraction_sha256']=hashlib.sha256(raw).hexdigest()
    (ROOT/'analysis/results/fable_extraction_audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
