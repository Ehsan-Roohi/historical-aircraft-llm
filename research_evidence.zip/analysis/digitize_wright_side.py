"""Recover side-view landmarks and cross-view checks; never fit unknown geometry."""
import hashlib
import itertools
import json
import math
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def product_bounds(a,b):
    values=[x*y for x in a for y in b]
    return [min(values),max(values)]


def angle_bounds(dx,dz,e):
    if dx<=2*e or e<0:
        raise ValueError('Ambiguous forward chord or invalid allowance')
    values=[math.degrees(math.atan2(z,x)) for x,z in itertools.product((dx-2*e,dx+2*e),(dz-2*e,dz+2*e))]
    return [min(values),max(values)]


def reconstruct(data):
    cal=data['calibration']; e=data['reading_allowance_px']
    a,b=cal['chord_endpoints_uv_px']
    length=math.hypot(b[0]-a[0],b[1]-a[1])
    error=2*math.sqrt(2)*e
    if e<0 or cal['chord_m']<=0 or length<=error:
        raise ValueError('Invalid calibration')
    scale=cal['chord_m']/length
    scales=[cal['chord_m']/(length+error),cal['chord_m']/(length-error)]
    u0,v0=cal['origin_uv_px']
    landmarks={}
    for name,(u,v) in data['landmarks_uv_px'].items():
        dx,dz=u-u0,v0-v
        landmarks[name]={'x_aft_m':dx*scale,'z_up_m':dz*scale,
                         'reading_only_x_bounds_m':product_bounds([dx-2*e,dx+2*e],scales),
                         'reading_only_z_bounds_m':product_bounds([dz-2*e,dz+2*e],scales)}
    # The chosen origin has identically zero relative coordinates, even as its pixels vary.
    origin=landmarks['lower_main_selected_LE_origin']
    origin['reading_only_x_bounds_m']=[0.,0.]
    origin['reading_only_z_bounds_m']=[0.,0.]
    pts=data['landmarks_uv_px']
    gap=pts['lower_main_selected_LE_origin'][1]-pts['upper_main_selected_LE'][1]
    cg=pts['lower_canard_selected_LE'][1]-pts['upper_canard_selected_LE'][1]
    cc=pts['upper_canard_selected_TE'][0]-pts['upper_canard_selected_LE'][0]
    return {'scale_m_per_pixel':scale,'reading_only_scale_bounds':scales,'landmarks':landmarks,
            'selected_main_chord_angle_deg':math.degrees(math.atan2(b[1]-a[1],b[0]-a[0])),
            'reading_only_main_angle_bounds_deg':angle_bounds(b[0]-a[0],b[1]-a[1],e),
            'selected_LE_vertical_separation_m':gap*scale,
            'reading_only_LE_vertical_separation_bounds_m':product_bounds([gap-2*e,gap+2*e],scales),
            'selected_canard_LE_vertical_separation_m':cg*scale,
            'reading_only_canard_LE_separation_bounds_m':product_bounds([cg-2*e,cg+2*e],scales),
            'selected_upper_canard_horizontal_chord_m':cc*scale,
            'reading_only_upper_canard_chord_bounds_m':product_bounds([cc-2*e,cc+2*e],scales)}


def main():
    source=ROOT/'analysis/references/wright_side_landmarks_v1.json'
    raw=source.read_bytes(); data=json.loads(raw)
    if hashlib.sha256((ROOT/data['source_file']).read_bytes()).hexdigest()!=data['source_sha256']:
        raise ValueError('Side image hash mismatch')
    result=reconstruct(data)
    top_path=ROOT/'analysis/references/wright_planform_pixels_v1.json'
    top_raw=top_path.read_bytes(); top=json.loads(top_raw)
    if hashlib.sha256((ROOT/top['source_file']).read_bytes()).hexdigest()!=top['source_sha256']:
        raise ValueError('Top image hash mismatch')
    cal=top['calibration']; span=cal['span_endpoints_u_px'][1]-cal['span_endpoints_u_px'][0]
    scale=cal['span_m']/span; e=top['reading_allowance_px']
    scales=[cal['span_m']/(span+2*e),cal['span_m']/(span-2*e)]
    values=[p[1] for p in top['outlines_uv_px']['canard_projection']]
    le=cal['origin_uv_px'][1]-max(values); te=cal['origin_uv_px'][1]-min(values)
    result['cross_view_canard_projection']={
        'top_LE_x_m':le*scale,'top_TE_x_m':te*scale,
        'top_LE_reading_only_bounds_m':product_bounds([le-2*e,le+2*e],scales),
        'top_TE_reading_only_bounds_m':product_bounds([te-2*e,te+2*e],scales),
        'boundary':'Different view calibrations and approximate main-wing origins. Overlap would not prove correspondence, common incidence or physical geometry.'}
    result.update(source_sha256=data['source_sha256'],input_sha256=hashlib.sha256(raw).hexdigest(),
                  top_input_sha256=hashlib.sha256(top_raw).hexdigest(),
                  annotations_for_context_not_fit=data['annotations_for_context_not_fit'],
                  scope=data['scope'], unresolved=data['unresolved'])
    out=ROOT/'analysis/results/wright_side_landmarks_v1.json'
    out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__': main()
