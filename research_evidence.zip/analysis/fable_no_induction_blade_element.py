#!/usr/bin/env python3
"""Frozen no-induction, per-blade Fable load accounting; not BEM validation.

Uses V8-R only at r=.12 m and archived V5 sections elsewhere. The propeller
count is two and V3b/V5 propose two blades per propeller (V2 unknown). Nothing
here is a prediction of installed thrust or an operating-point match.
"""
import hashlib
import json
import math
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MANIFEST=ROOT/'analysis/results/v5_radial_section_inputs01/manifest.json'
V3B=ROOT/'analysis/v3b_propulsion_inputs.json'
OLD=ROOT/'analysis/results/radial_sections_v5_attempt01'
NEW=ROOT/'analysis/results/fable_v8r_root_attempt01/records.json'
V5_RESPONSE=ROOT/'received_v5_64962376/responses/claude-fable-5-1/response.json'
V5_RESPONSE_SHA='f42e6c956bd4f323480400c8136218662970edd47a9f03f411f84f1a98e829c3'
AUDIT=ROOT/'analysis/results/fable_v8r_root_audit01.json'
OUT=ROOT/'analysis/results/fable_no_induction_blade_element01.json'
RHO=1.225
V=13.0
RPM=600.0
PROPELLERS=2

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def bracket(rows, alpha):
    """Interpolate only between stored, screened rows of one contour density."""
    good=sorted((r for r in rows if r['status']=='NUMERICAL_SCREEN'),key=lambda r:r['alpha_deg'])
    if not good:
        raise ValueError('No screened polar data')
    for low,high in zip(good,good[1:]):
        if low['alpha_deg']<=alpha<=high['alpha_deg']:
            factor=(alpha-low['alpha_deg'])/(high['alpha_deg']-low['alpha_deg'])
            return ({field:low['reader']['coefficients'][field]*(1-factor)+high['reader']['coefficients'][field]*factor
                     for field in ('CL','CD','CM')},[low['alpha_deg'],high['alpha_deg']])
    raise ValueError('Operating angle not bracketed by screened rows')

def element_load(radius,chord,angle_deg,cl,cd):
    """Return per-blade thrust and shaft-torque densities in N/m and N m/m."""
    omega=2*math.pi*RPM/60
    phi=math.atan2(V,omega*radius)
    alpha=angle_deg-math.degrees(phi)
    speed=math.hypot(V,omega*radius)
    q=.5*RHO*speed*speed
    lift_per_m=q*chord*cl
    drag_per_m=q*chord*cd
    thrust_per_m=lift_per_m*math.cos(phi)-drag_per_m*math.sin(phi)
    torque_per_m=radius*(lift_per_m*math.sin(phi)+drag_per_m*math.cos(phi))
    return {'phi_deg':math.degrees(phi),'alpha_deg':alpha,'speed_m_s':speed,
            'lift_per_m_N_m':lift_per_m,'drag_per_m_N_m':drag_per_m,
            'thrust_per_m_N_m':thrust_per_m,'torque_per_m_Nm_m':torque_per_m}

def trapezoid(stations,key):
    return sum((b['radius_m']-a['radius_m'])*(a[key]+b[key])/2
               for a,b in zip(stations,stations[1:]))

def ideal_disk_power(total_thrust, radius=1.15):
    """Ideal axial momentum screen for two equal, noninteracting propeller disks."""
    if total_thrust<0 or radius<=0:
        raise ValueError('Invalid disk input')
    each=total_thrust/PROPELLERS
    area=math.pi*radius*radius
    vi=(math.sqrt(V*V+2*each/(RHO*area))-V)/2
    return total_thrust*(V+vi),vi

def main():
    if sha(V5_RESPONSE)!=V5_RESPONSE_SHA or '2 x 2-blade' not in json.loads(json.loads(V5_RESPONSE.read_text())['response'])['model']:
        raise ValueError('V5 model-proposed blade count provenance mismatch')
    manifest=json.loads(MANIFEST.read_text())
    v3b=json.loads(V3B.read_text())
    model=next(r for r in v3b['records'] if r['model']=='claude-fable-5-1')
    if model['count']!=PROPELLERS or model['rpm']!=RPM or model['V']!=V:
        raise ValueError('Fable baseline point changed')
    check=json.loads(AUDIT.read_text())
    if not check['two_or_more_grids_each_side'] or check['numerical_screen_count']!=15:
        raise ValueError('V8-R root screen incomplete')
    root_rows=json.loads(NEW.read_text())
    stations=[s for s in manifest['stations'] if s['family']=='fable']
    if len(stations)!=len(model['stations']):
        raise ValueError('Station count changed')
    outputs={}
    for density in (80,120):
        loads=[]
        for station,(radius,chord,beta) in zip(stations,model['stations']):
            if any(abs(a-b)>1e-9 for a,b in ((radius,station['radius_m']),(chord,station['chord_m']),(beta,station['beta_deg']))):
                raise ValueError('Archived station mismatch')
            if radius==.12:
                rows=[r for r in root_rows if r['geometry_file']==f'fable_v8r_r012_n{density}.dat']
                source='V8-R unadopted root'
            else:
                rows=[r for r in json.loads((OLD/station['stem']/'records.json').read_text())
                      if r['geometry_file']==f"{station['stem']}_n{density}.dat"]
                source='archived V5 station'
            alpha=station['geometric_incidence_no_induction_deg']
            coeff,angle_pair=bracket(rows,alpha)
            load=element_load(radius,chord,beta,coeff['CL'],coeff['CD'])
            if abs(load['alpha_deg']-alpha)>1e-9:
                raise ValueError('Incidence disagreement')
            loads.append({'stem':station['stem'],'radius_m':radius,'chord_m':chord,
                          'beta_deg':beta,'source':source,'bracket_deg':angle_pair,
                          'CL':coeff['CL'],'CD':coeff['CD'],**load})
        thrust=trapezoid(loads,'thrust_per_m_N_m')
        torque=trapezoid(loads,'torque_per_m_Nm_m')
        power=torque*(2*math.pi*RPM/60)
        illustrations={}
        for blades in (1,2,3):
            total_T=PROPELLERS*blades*thrust
            total_P=PROPELLERS*blades*power
            ideal_P,vi=ideal_disk_power(total_T)
            illustrations[str(blades)]={'blade_count_role':'V3b/V5 model proposal' if blades==2 else 'sensitivity alternative',
                                        'T_N':total_T,'Q_all_props_Nm':PROPELLERS*blades*torque,
                                        'P_shaft_all_props_W':total_P,
                                        'P_ideal_disk_W':ideal_P,'ideal_disk_vi_m_s':vi,
                                        'below_ideal_disk_power':total_P<ideal_P,
                                        'TV_over_Pshaft':total_T*V/total_P if total_P>0 else None}
        outputs[str(density)]={'stations':loads,'per_blade_thrust_N':thrust,
                               'per_blade_torque_Nm':torque,'per_blade_shaft_power_W':power,
                               'required_blades_per_prop_for_model_T_412_N':model['T']/(PROPELLERS*thrust) if thrust>0 else None,
                               'illustrative_blade_counts_per_prop':illustrations}
    result={'stage':'conditional_no_induction_blade_element_accounting',
            'input_hashes':{'v3b':sha(V3B),'v5_model_response':sha(V5_RESPONSE),'v5_manifest':sha(MANIFEST),
                            'v8r_root_records':sha(NEW),'v8r_audit':sha(AUDIT)},
            'model_target_T_N':model['T'],'model_engine_target_W_unverified':model['target'],
            'propeller_count':PROPELLERS,'v2_blades_per_propeller':'UNKNOWN','v3b_v5_model_proposed_blades_per_propeller':2,
            'V_m_s':V,'rpm':RPM,'rho_kg_m3':RHO,'quadrature':'trapezoid on nine archived station radii',
            'profile_method':'linear interpolation between screened 2D section coefficients at fixed no-induction incidence',
            'densities':outputs,
            'limitations':['No axial or tangential induction, root/tip loss, wake, installation, interference, or flexibility',
                           '2D numerical rows not experimentally validated; transition and roughness uncertainty',
                           'No polar data between stations; trapezoidal radial integration is a discretization assumption',
                           'Two-blade row is the V3b/V5 proposal; one/three are sensitivity alternatives; V2 blade count remains unknown',
                           'Ideal-disk comparison assumes two noninteracting axial disks and cannot validate the blade-element loads',
                           'No engine torque/RPM map or installed thrust curve; no aircraft flight inference'],
            'aerodynamic_validation':False,'installed_propeller_performance':False,
            'flight_validation':False}
    OUT.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'per_blade':{k:{n:v[n] for n in ('per_blade_thrust_N','per_blade_torque_Nm','per_blade_shaft_power_W','required_blades_per_prop_for_model_T_412_N')}
                                    for k,v in outputs.items()}}))

if __name__=='__main__':
    main()
