#!/usr/bin/env python3
"""Freeze a narrow panel-resolution diagnostic at Fable's unbracketed root."""
import hashlib
import json
import math
from pathlib import Path

from prepare_v5_radial_sections import contour

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'analysis/results/fable_root_resolution_inputs01'
PARENT = ROOT/'analysis/results/v5_radial_section_inputs01'
DENSITIES = (80, 100, 110, 120, 140)
ANGLES = (3, 4, 5, 6, 7)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parent_path=PARENT/'manifest.json'
    parent=json.loads(parent_path.read_text())
    station=next(s for s in parent['stations'] if s['stem']=='fable_r012')
    if station['radius_m']!=.12 or station['chord_m']!=.1 or station['beta_deg']!=64.8:
        raise ValueError('Unexpected archived Fable root')
    original={s['file']:s['sha256'] for s in parent['sections']}
    if any(sha(PARENT/f'fable_r012_n{n}.dat')!=original[f'fable_r012_n{n}.dat'] for n in (80,120)):
        raise ValueError('Original section checksum changed')
    if OUT.exists():
        raise FileExistsError(OUT)
    OUT.mkdir(parents=True)
    sections=[]
    for density in DENSITIES:
        name=f'fable_r012_n{density}.dat'
        content=contour('fable',station['thickness_parameter'],density,name)
        path=OUT/name
        # The frozen Windows V5 generator used write_text(), which emitted CRLF.
        # Preserve byte-for-byte identity at the two archived densities.
        path.write_bytes(content.replace('\n','\r\n').encode())
        if density in (80,120) and sha(path)!=original[name]:
            raise ValueError('Regenerated parent contour differs: '+name)
        sections.append({'file':name,'density':density,'points':2*density+1,'sha256':sha(path)})
    manifest={'stage':'fable_root_panel_resolution_screen',
              'parent_manifest_sha256':sha(parent_path),
              'parent_v3b_sha256':parent['parent_v3b_sha256'],
              'parent_v5_fable_sha256':parent['response_sha256']['claude-fable-5-1'],
              'station':station,'densities':list(DENSITIES),'angles_deg':list(ANGLES),
              'sections':sections,'numerical_screen_only':True,
              'interpretation':'No induction, no installed propeller thrust or shaft-power conclusion'}
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'sections':len(sections),'cases':len(DENSITIES)*len(ANGLES),
                      'no_induction_incidence_deg':station['geometric_incidence_no_induction_deg'],
                      'reynolds_no_induction':station['reynolds_no_induction']}))

if __name__=='__main__':
    main()
