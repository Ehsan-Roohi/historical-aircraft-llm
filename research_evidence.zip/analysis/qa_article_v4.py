"""Render every manuscript page and record basic PDF integrity checks."""
from pathlib import Path
import json
import hashlib
import pypdfium2 as pdfium
from pypdf import PdfReader
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1]
path=ROOT/'output/overleaf/aircraft_scientific_revision_v4/main.pdf'
out=ROOT/'tmp/pdfs/article_v4';out.mkdir(parents=True,exist_ok=True)
doc=pdfium.PdfDocument(str(path));reader=PdfReader(path)
records=[]
for i,page in enumerate(doc):
    im=page.render(scale=1.7).to_pil().convert('RGB')
    im.save(out/f'page-{i+1:02d}.png')
    text=reader.pages[i].extract_text() or ''
    records.append({'page':i+1,'characters':len(text),'width':float(reader.pages[i].mediabox.width),'height':float(reader.pages[i].mediabox.height),'rotation':reader.pages[i].get('/Rotate',0)})
for start in range(0,len(doc),6):
    sheet=Image.new('RGB',(1200,1650),'#e5e5e5');d=ImageDraw.Draw(sheet)
    for i in range(start,min(start+6,len(doc))):
        im=Image.open(out/f'page-{i+1:02d}.png');im.thumbnail((590,500))
        x=(i-start)%2*600;y=(i-start)//2*550
        sheet.paste(im,(x,y+25));d.text((x+5,y+5),f'Page {i+1}',fill='black')
    sheet.save(out/f'contact-{start+1:02d}.png')
text='\n'.join(p.extract_text() or '' for p in reader.pages)
assert 'Ehsan Roohi' in text
assert '13.354' in text
assert '[34]' in text
assert '??' not in text
manifest={'pdf_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'pages':records,'all_pages_rendered':True,'visual_review_completed':False}
(out/'render_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps({'pages':len(doc),'sha256':manifest['pdf_sha256'],'output':str(out)},ensure_ascii=True))
