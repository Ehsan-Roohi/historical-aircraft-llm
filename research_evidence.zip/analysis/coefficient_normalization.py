"""Preserve dimensional loads across coefficient reference changes.

Reference-point shifts are intentionally NOT included. These factors are
sensitivity bookkeeping, not a resolution of the Wright source discrepancy.
"""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def convert(cl,cd,cm,q_old,s_old,c_old,q_new,s_new,c_new):
    if min(q_old,s_old,c_old,q_new,s_new,c_new)<=0:
        raise ValueError('Reference scales must be positive')
    force_scale=q_old*s_old/(q_new*s_new)
    moment_scale=force_scale*c_old/c_new
    return {'CL':cl*force_scale,'CD':cd*force_scale,'Cm':cm*moment_scale}


def main():
    scenarios=[]
    for s,c in [(510,6.5),(518,6.2),(510,6.2)]:
        factors=convert(1,1,1,1,518,6.5,1,s,c)
        scenarios.append({'from':{'S_ft2':518,'c_ft':6.5},'to':{'S_ft2':s,'c_ft':c},
                          'multipliers':factors,'changes_percent':{k:100*(v-1) for k,v in factors.items()}})
    result={'scope':'Hypothetical re-normalization of identical dimensional loads at unchanged q and moment point; NOT a selected Wright correction',
            'source_definitions':'paper/baselines/WRIGHT_REFERENCE_v1.md; paper/uiuc_reference_audit_v1.md; paper/wright_measured_reference_v1.md',
            'scenarios':scenarios}
    (ROOT/'analysis/results/coefficient_normalization_v1.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
