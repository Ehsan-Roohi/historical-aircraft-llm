"""Export reviewed candidate sections and full baseline context; no polar claims."""
import hashlib
import json
import math
from pathlib import Path
from validate_propeller_sections import validate_section

ROOT = Path(__file__).resolve().parents[1]


def coordinates(family, t, intervals=80):
    xs = [(1-math.cos(math.pi*i/intervals))/2 for i in range(intervals+1)]
    if family == 'astra':
        knots = [(0,0),(.1,.045),(.3,.06),(.6,.035),(1,0)]
        xs = sorted(set(xs+[x for x,y in knots]))
        def top(x):
            for (a,u),(b,v) in zip(knots,knots[1:]):
                if a <= x <= b:
                    return u+(v-u)*(x-a)/(b-a)
        upper = [[x,top(x)] for x in xs]
        lower = [[x,-top(x)] for x in xs]
    elif family == 'fable':
        upper = [[x,4*(.06+t/2)*x*(1-x)] for x in xs]
        lower = [[x,4*(.06-t/2)*x*(1-x)] for x in xs]
    elif family == 'opus':
        upper = [[x,10*t*(.2969*math.sqrt(x)-.126*x-.3516*x*x+.2843*x**3-.1036*x**4)] for x in xs]
        lower = [[x,0] for x in xs]
        # Closed analytic endpoints; remove floating-point cancellation only.
        upper[0][1] = upper[-1][1] = 0.0
    else:
        raise ValueError('Unknown reviewed family')
    return upper, lower


def main():
    out = ROOT/'analysis/results/v4_section_inputs01'
    out.mkdir(exist_ok=False)
    sections = []
    families = [('astra',[.12]),('fable',[.30,.20,.15,.12,.11,.10,.09,.08]),
                ('opus',[.30,.18,.13,.10,.09,.08,.07,.06])]
    for family, ts in families:
        for t in ts:
            for n in (80,120):
                upper, lower = coordinates(family,t,n)
                check = validate_section(upper,lower)
                name = f'{family}_t{round(t*100):02d}_n{n}'
                # TE-upper -> LE -> TE-lower, LE appears only once.
                points = upper[::-1]+lower[1:]
                path = out/(name+'.dat')
                path.write_text(name+'\n'+''.join(f'{x:.12f} {y:.12f}\n' for x,y in points),encoding='ascii')
                sections.append(dict(file=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                                     family=family,thickness_parameter=t,points=len(points),
                                     geometry_check=check,status='CANDIDATE_INPUT_NOT_POLAR'))
    context=[]
    for p in sorted((ROOT/'analysis/results/received_v2_audit01').glob('*.design.json')):
        d=json.loads(p.read_bytes())
        context.append(dict(model=p.name.removesuffix('.design.json'),baseline_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
                            coordinate_convention=d['coordinate_convention'],propulsion=d['propulsion']))
    (out/'baseline_context.json').write_text(json.dumps(context,indent=2),encoding='utf-8')
    (out/'manifest.json').write_text(json.dumps(dict(sections=sections,
        source='Reviewed V4 formulas transcribed by evaluator; raw responses on Unity job 64958422.',
        geometry_changes='No smoothing or leading-edge rounding; Opus endpoint cancellation removed only.',
        note='Two INPUT samplings, not proof of XFOIL panel convergence. PANE changes require exported geometry review.',
        solver_status='NOT_RUN'),indent=2),encoding='utf-8')
    print(f'Exported {len(sections)} geometry files and 3 complete V2 propulsion/coordinate contexts.')


if __name__ == '__main__':
    main()
