#!/usr/bin/env python3
"""Coupled axial annular blade-element/momentum screen, not propeller validation.

Assumptions deliberately exposed: equal noninteracting propellers, axial inflow,
no tangential induction, no Prandtl losses or installation effects, frozen-Re
two-dimensional polars, trapezoidal radial integration. Two blades per
propeller is the Fable V3b/V5 proposal; one and three are sensitivities.
Never use this as a flight clearance.
"""
import hashlib
import json
import math
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
V3B=ROOT/'analysis/v3b_propulsion_inputs.json'
MANIFEST=ROOT/'analysis/results/v5_radial_section_inputs01/manifest.json'
OLD=ROOT/'analysis/results/radial_sections_v5_attempt01'
ROOT_ROWS=ROOT/'analysis/results/fable_v8r_induction_attempt01/records.json'
ROOT_MANIFEST=ROOT/'analysis/results/fable_v8r_induction_inputs01/manifest.json'
ROOT_ARCHIVE=ROOT/'analysis/results/fable_v8r_induction_results_64968989.tar.gz'
ROOT_ARCHIVE_SHA='a4b03405ea77b75f0f62cb7527ca7c508d253a9bc33bccabd9487dcdf07c082f'
V5_RESPONSE=ROOT/'received_v5_64962376/responses/claude-fable-5-1/response.json'
V5_RESPONSE_SHA='f42e6c956bd4f323480400c8136218662970edd47a9f03f411f84f1a98e829c3'
OUT=ROOT/'analysis/results/fable_axial_induction_screen01.json'
RHO=1.225
V=13.0
RPM=600.0
PROPELLERS=2
OMEGA=2*math.pi*RPM/60

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def interpolate(rows,alpha):
    good=sorted((r for r in rows if r['status']=='NUMERICAL_SCREEN'),key=lambda r:r['alpha_deg'])
    for row in good:
        if abs(row['alpha_deg']-alpha)<1e-10:
            c=row['reader']['coefficients']
            return c['CL'],c['CD'],[alpha,alpha]
    for low,high in zip(good,good[1:]):
        a,b=low['alpha_deg'],high['alpha_deg']
        if a<alpha<b:
            f=(alpha-a)/(b-a)
            cl=low['reader']['coefficients']['CL']*(1-f)+high['reader']['coefficients']['CL']*f
            cd=low['reader']['coefficients']['CD']*(1-f)+high['reader']['coefficients']['CD']*f
            return cl,cd,[a,b]
    raise ValueError(f'No screened alpha bracket at {alpha:.5f} deg')

def momentum_thrust_density(r,vi):
    return 4*math.pi*RHO*r*(V+vi)*vi

def loads(station,rows,vi,blades,omega=OMEGA):
    radius=station['radius_m']
    chord=station['chord_m']
    phi=math.atan2(V+vi,omega*radius)
    alpha=station['beta_deg']-math.degrees(phi)
    cl,cd,bracket=interpolate(rows,alpha)
    speed=math.hypot(V+vi,omega*radius)
    lift=.5*RHO*speed*speed*chord*cl
    drag=.5*RHO*speed*speed*chord*cd
    dTdr=blades*(lift*math.cos(phi)-drag*math.sin(phi))
    dQdr=blades*radius*(lift*math.sin(phi)+drag*math.cos(phi))
    return {'radius_m':radius,'vi_m_s':vi,'phi_deg':math.degrees(phi),'alpha_deg':alpha,
            'Re_frozen':station['reynolds_no_induction'],'Re_actual_at_induced_speed':RHO*speed*chord/1.81e-5,
            'CL':cl,'CD':cd,'polar_bracket_deg':bracket,'dTdr_N_m':dTdr,
            'dQdr_Nm_m':dQdr,'momentum_dTdr_N_m':momentum_thrust_density(radius,vi),
            'dPdr_shaft_W_m':omega*dQdr,'dPdr_axial_ideal_W_m':dTdr*(V+vi)}

def solve_station(station,rows,blades,omega=OMEGA):
    def residual(vi):
        result=loads(station,rows,vi,blades,omega)
        return result['dTdr_N_m']-result['momentum_dTdr_N_m'],result
    lo=0.0
    flo,_=residual(lo)
    if flo<=0:
        raise ValueError('No positive-thrust induction root at vi=0')
    hi=.25
    for _ in range(64):
        fhi,_=residual(hi)
        if fhi<=0:
            break
        hi*=1.5
        if hi>20:
            raise ValueError('No induction-root sign change below 20 m/s')
    else:
        raise ValueError('No bracket after 64 iterations')
    for _ in range(80):
        mid=(lo+hi)/2
        fm,_=residual(mid)
        if fm>0:
            lo=mid
        else:
            hi=mid
    _,result=residual((lo+hi)/2)
    result['residual_N_m']=result['dTdr_N_m']-result['momentum_dTdr_N_m']
    return result

def integrate(rows,key):
    return sum((b['radius_m']-a['radius_m'])*(a[key]+b[key])/2 for a,b in zip(rows,rows[1:]))

def main():
    if sha(ROOT_ARCHIVE)!=ROOT_ARCHIVE_SHA:
        raise ValueError('Downloaded lower-angle archive hash mismatch')
    if sha(V5_RESPONSE)!=V5_RESPONSE_SHA or '2 x 2-blade' not in json.loads(json.loads(V5_RESPONSE.read_text())['response'])['model']:
        raise ValueError('V5 model-proposed blade count provenance mismatch')
    v3b=json.loads(V3B.read_text())
    model=next(r for r in v3b['records'] if r['model']=='claude-fable-5-1')
    if (model['V'],model['rpm'],model['count'])!=(V,RPM,PROPELLERS):
        raise ValueError('V3b baseline changed')
    manifest=json.loads(MANIFEST.read_text())
    root_manifest=json.loads(ROOT_MANIFEST.read_text())
    if root_manifest['stage']!='fable_v8r_root_induction_coverage':
        raise ValueError('Unexpected root screen')
    root_records=json.loads(ROOT_ROWS.read_text())
    if len(root_records)!=27 or sum(r['status']=='NUMERICAL_SCREEN' for r in root_records)!=24:
        raise ValueError('Unexpected V8-R lower-angle screen count')
    stations=[s for s in manifest['stations'] if s['family']=='fable']
    results={}
    for density in (80,120):
        section_rows=[]
        for station in stations:
            if station['radius_m']==.12:
                rows=[r for r in root_records if r['geometry_file']==f'fable_v8r_r012_n{density}.dat']
                source='V8-R unadopted root'
            else:
                rows=[r for r in json.loads((OLD/station['stem']/'records.json').read_text())
                      if r['geometry_file']==f"{station['stem']}_n{density}.dat"]
                source='archived V5 station'
            section_rows.append((station,rows,source))
        for blades in (1,2,3):
            key=f'n{density}_b{blades}'
            try:
                solved=[]
                for station,rows,source in section_rows:
                    record=solve_station(station,rows,blades)
                    record['stem']=station['stem']
                    record['polar_source']=source
                    solved.append(record)
                per_prop_T=integrate(solved,'dTdr_N_m')
                per_prop_Q=integrate(solved,'dQdr_Nm_m')
                per_prop_P=OMEGA*per_prop_Q
                ideal_P=integrate(solved,'dPdr_axial_ideal_W_m')
                total_T=PROPELLERS*per_prop_T
                total_P=PROPELLERS*per_prop_P
                results[key]={'status':'CONDITIONAL_NUMERICAL_SCREEN','blades_per_prop_assumed':blades,
                              'blade_count_role':'V3b/V5 model proposal' if blades==2 else 'sensitivity alternative',
                              'contour_density':density,'stations':solved,
                              'T_all_propellers_N':total_T,'Q_all_propellers_Nm':PROPELLERS*per_prop_Q,
                              'P_shaft_all_propellers_W':total_P,
                              'P_axial_ideal_annular_all_W':PROPELLERS*ideal_P,
                              'power_above_axial_ideal_W':total_P-PROPELLERS*ideal_P,
                              'TV_over_Pshaft':total_T*V/total_P if total_P>0 else None,
                              'model_target_T_N':model['T'],
                              'conditional_T_minus_model_target_N':total_T-model['T'],
                              'model_engine_target_W_unverified':model['target'],
                              'conditional_engine_power_if_drive_095_W':total_P/model['drive'],
                              'max_polar_bracket_width_deg':max(b['polar_bracket_deg'][1]-b['polar_bracket_deg'][0] for b in solved),
                              'max_frozen_Re_fractional_change':max(abs(b['Re_actual_at_induced_speed']/b['Re_frozen']-1) for b in solved)}
            except ValueError as error:
                results[key]={'status':'UNRESOLVED','blades_per_prop_assumed':blades,
                              'blade_count_role':'V3b/V5 model proposal' if blades==2 else 'sensitivity alternative',
                              'contour_density':density,'reason':str(error)}
    out={'stage':'axial_annular_blade_element_momentum_research_screen',
         'input_hashes':{'v3b':sha(V3B),'v5_model_response':sha(V5_RESPONSE),'v5_manifest':sha(MANIFEST),
                         'v8r_lower_angle_records':sha(ROOT_ROWS),'v8r_lower_angle_manifest':sha(ROOT_MANIFEST),
                         'v8r_lower_angle_archive':ROOT_ARCHIVE_SHA},
         'assumptions':['Fable V3b axial V=13 m/s and 600 propeller rpm',
                        'Two identical noninteracting propellers; two blades each proposed by Fable V3b/V5, one/three sensitivity alternatives',
                        'Local axial induction balances blade-element dT/dr and annular momentum dT/dr',
                        'No tangential induction, tip/root loss, blockage, installation or airframe interaction',
                        '2D numerical CL/CD interpolated at frozen no-induction Reynolds number',
                        'No polar interpolation along r; trapezoid of nine station loads only'],
         'results':results,'v2_blades_per_propeller':'UNKNOWN','v3b_v5_model_proposed_blades_per_propeller':2,'engine_map_available':False,
         'aerodynamic_validation':False,'installed_propeller_validation':False,
         'aircraft_flight_conclusion':False}
    OUT.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:{field:v.get(field) for field in ('status','reason','T_all_propellers_N','P_shaft_all_propellers_W','power_above_axial_ideal_W')}
                      for k,v in results.items()}))

if __name__=='__main__':
    main()
