"""Reproducible calibration of manually read pixels; no raw-data claim."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def calibrate(pixel,axis):
    p0,p1=axis['pixel']
    v0,v1=axis['value']
    return v0+(pixel-p0)*(v1-v0)/(p1-p0)


def slope(x,y):
    mx=sum(x)/len(x)
    my=sum(y)/len(y)
    return sum((a-mx)*(b-my) for a,b in zip(x,y))/sum((a-mx)**2 for a in x)


def main():
    src=ROOT/'analysis/references/wright_page10_digitization.json'
    raw=src.read_bytes()
    data=json.loads(raw)
    if hashlib.sha256((ROOT/data['source_pdf']).read_bytes()).hexdigest()!=data['source_sha256']:
        raise ValueError('Source PDF hash mismatch')
    axes=data['axes']
    records=[]
    for point in data['points']:
        records.append({name:calibrate(point[key],axes[name]) for name,key in [('CL','CL_y'),('CD','CD_x'),('Cm','Cm_x'),('alpha_deg','alpha_x')]})
    errors={name:data['pixel_error_allowance']*abs((axis['value'][1]-axis['value'][0])/(axis['pixel'][1]-axis['pixel'][0])) for name,axis in axes.items()}
    cl=[r['CL'] for r in records]
    cm=[r['Cm'] for r in records]
    alpha=[r['alpha_deg'] for r in records]
    dcl=cl[-1]-cl[0]
    dcm=cm[-1]-cm[0]
    interval=[(dcm-2*errors['Cm'])/(dcl+2*errors['CL']),(dcm+2*errors['Cm'])/(dcl-2*errors['CL'])]
    result={'input_sha256':hashlib.sha256(raw).hexdigest(),'series':data['series'],'records':records,
            'illustrative_reading_allowance':errors,
            'linear_fit_descriptors_NOT_local_derivatives':{'dCL_dalpha_per_deg':slope(alpha,cl),'dCm_dalpha_per_deg':slope(alpha,cm),'dCm_dCL':slope(cl,cm)},
            'endpoint_dCm_dCL_reading_only_bounds':interval,
            'interpretation':'Positive Cm-vs-CL trend supports pitch instability at the plotted reference. Full-range fitted slope is not a local stability derivative; graph-reading bounds exclude experimental, geometry and aeroelastic uncertainties.'}
    (ROOT/'analysis/results/wright_props_off_digitized_v1.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
