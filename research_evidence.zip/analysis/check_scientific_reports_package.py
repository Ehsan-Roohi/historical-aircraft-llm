"""Static source/data checks for the journal ZIP; not a TeX compile or validation."""

from pathlib import Path
from collections import Counter
import json
import re

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / "output/overleaf/scientific_reports_aircraft_2026_09_28"
main = (PACKAGE / "main.tex").read_text(encoding="utf-8")
supp = (PACKAGE / "supplementary.tex").read_text(encoding="utf-8")
refs = (PACKAGE / "references_scientific_reports.tex").read_text(encoding="utf-8")

assert main.count(r"\begin{figure}") == 6
assert main.count(r"\begin{table}") == 2
assert supp.count(r"\begin{figure}") == 6
assert supp.count(r"\begin{table}") == 7
for label, source in (("main", main), ("supplement", supp)):
    declared = re.findall(r"\\label\{([^}]+)\}", source)
    assert all(count == 1 for count in Counter(declared).values()), label
    for graphic in re.findall(r"\\includegraphics\[[^]]*\]\{([^}]+)\}", source):
        filename = graphic.replace(r"\figdir", "figures")
        assert (PACKAGE / filename).is_file(), (label, filename)

cited = {item.strip() for group in re.findall(r"\\cite\{([^}]+)\}", main) for item in group.split(",")}
defined = set(re.findall(r"\\bibitem\{([^}]+)\}", refs))
assert not cited - defined, sorted(cited - defined)
assert "Supplementary Supplementary" not in main
assert "configuration_comparison_v2.png" not in main
assert "Ehsan Roohi" in main
assert "Opus V1 is the strongest evaluated initial proposal" in main
assert "Astra is the most promising" in main

abstract = re.search(r"\\begin\{abstract\}(.*?)\\end\{abstract\}", main, re.S).group(1)
word_count = len(re.findall(r"\b[\w-]+\b", abstract))
assert word_count <= 200, word_count

v2 = json.loads((PACKAGE / "audit_data/v2_longitudinal_retrim.json").read_text(encoding="utf-8"))
by_model = {(row["model"], tuple(row["mesh"])): row for row in v2}
astra = by_model[("gpt-6-astra", (14, 72))]
opus = by_model[("claude-opus-5-5", (12, 50))]
assert round(astra["slope"]["effective_margin_percent"], 2) == 19.47
assert round(opus["slope"]["effective_margin_percent"], 2) == 7.76
assert abs(astra["balance"]["Rz_N"]) < 0.1 and abs(opus["balance"]["Rz_N"]) < 0.1

figure = PACKAGE / "figures/configuration_comparison_v3.png"
with Image.open(figure) as pic:
    assert pic.size == (2400, 1580)
    assert pic.info.get("dpi", (0, 0))[0] > 290

print(json.dumps({"main_figures": 6, "main_tables": 2, "supplement_figures": 6,
                  "supplement_tables": 7, "abstract_words": word_count,
                  "cited_references": len(cited), "static_check": "passed"}))
