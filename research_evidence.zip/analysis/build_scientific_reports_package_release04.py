"""Package the revised main article, supplement, figures and audit data.

This script copies the already reviewed article/SI source. It does not compile
TeX or claim journal acceptance.
"""
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT / "output/overleaf/scientific_reports_aircraft_2026_09_28_release03"
OUT = ROOT / "output/overleaf/scientific_reports_aircraft_2026_09_28_release04"
ZIP = ROOT / "output/delivery/scientific_reports_aircraft_overleaf_release04.zip"


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    shutil.copy2(ROOT / "paper/article_scientific_reports.tex", OUT / "main.tex")
    shutil.copy2(ROOT / "paper/supplementary_scientific_reports.tex", OUT / "supplementary.tex")
    shutil.copy2(OLD / "references_scientific_reports.tex", OUT / "references_scientific_reports.tex")
    shutil.copytree(OLD / "figures", OUT / "figures")
    shutil.copytree(OLD / "audit_data", OUT / "audit_data")
    shutil.copy2(ROOT / "analysis/results/v2_rate_derivative_screen02/summary.json",
                 OUT / "audit_data/v2_rate_derivatives_fine.json")
    shutil.copy2(ROOT / "analysis/results/v2_rate_derivative_mesh01/summary.json",
                 OUT / "audit_data/v2_rate_derivatives_coarse.json")
    shutil.copy2(ROOT / "output/figures_v2/v2_force_moment_comparison.png",
                 OUT / "figures/v2_force_moment_comparison.png")
    shutil.copy2(ROOT / "paper/DATA_AVAILABILITY.md", OUT / "DATA_AVAILABILITY.md")
    (OUT / "README.md").write_text(
        "# Aircraft LLM paper: revised Scientific Reports review package\n\n"
        "Compile `main.tex` with pdfLaTeX. To obtain the separate supplement, "
        "compile `supplementary.tex` as root. The main file has seven figures "
        "and two tables; the supplement has six figures and eight tables.\n\n"
        "Figure 7 separates independent conditional Astra/Opus V2 loads "
        "from Fable's unverified model claim. Table 2 is explicitly V1. "
        "The new derivative audit reports two-mesh quasi-steady pitch-rate "
        "screens for Astra and Opus. Angle-of-attack-rate derivatives remain "
        "unavailable without a downwash-delay/unsteady model.\n\n"
        "`audit_data/` contains compact numerical source records; the full "
        "prompt/response/code archive is at "
        "https://github.com/Ehsan-Roohi/historical-aircraft-llm/tree/aircraft-sr-2026-09-28-r2 .\n\n"
        "The author should compile and visually proof both TeX roots, check "
        "all citations and declarations, and apply the selected journal's "
        "current submission template before submission. No flightworthiness "
        "or journal acceptance is claimed.\n", encoding="utf-8")
    ZIP.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ZIP, "x", zipfile.ZIP_DEFLATED, compresslevel=8) as z:
        for p in sorted(OUT.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(OUT).as_posix())
    with zipfile.ZipFile(ZIP) as z:
        assert z.testzip() is None
    print(f"package={OUT.name} zip_bytes={ZIP.stat().st_size}")


if __name__ == "__main__":
    main()
