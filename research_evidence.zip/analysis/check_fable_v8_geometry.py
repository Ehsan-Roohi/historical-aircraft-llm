#!/usr/bin/env python3
"""Independent geometric audit of the model-proposed, unadopted Fable V8-R root."""
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESPONSE = ROOT / 'analysis/results/fable_v8_attempt01/responses/claude-fable-5-1/response.json'
PARENT = ROOT / 'analysis/results/v5_radial_section_inputs01/manifest.json'
OUT = ROOT / 'analysis/results/fable_v8_geometry_audit01.json'
EXPECTED_RESPONSE_SHA = '30775cc367af07747c27b440be5e50b336482fef71e6eca21c35526cc23b905a'


def thickness_shape(x, coefficient):
    return .2969 * math.sqrt(x) - .1260*x - .3516*x*x + .2843*x**3 + coefficient*x**4


def point(x, m, t, coefficient, normal_fraction):
    camber = 4*m*x*(1-x)
    half = 5*t*thickness_shape(x, coefficient)
    angle = math.atan(4*m*(1-2*x))
    # Interpolate the declared normal-projection construction to archived
    # vertical stacking, keeping a common dimensionless x parameter.
    xu = x - normal_fraction*half*math.sin(angle)
    xl = x + normal_fraction*half*math.sin(angle)
    yu = camber + half*((1-normal_fraction) + normal_fraction*math.cos(angle))
    yl = camber - half*((1-normal_fraction) + normal_fraction*math.cos(angle))
    return (xu,yu),(xl,yl),2*half


def main():
    actual = hashlib.sha256(RESPONSE.read_bytes()).hexdigest()
    if actual != EXPECTED_RESPONSE_SHA:
        raise ValueError('V8 response hash mismatch')
    carrier = json.loads(RESPONSE.read_text(encoding='utf-8'))
    model = json.loads(carrier['response'])
    if model['candidate_name'] != 'V8-R' or model['status'] != 'UNVALIDATED':
        raise ValueError('Unexpected V8 candidate')
    parent = json.loads(PARENT.read_text(encoding='utf-8'))
    station = next(s for s in parent['stations'] if s['stem'] == 'fable_r025')
    if station['thickness_parameter'] != .20:
        raise ValueError('Archived r=.25 thickness changed')
    n = 4000
    xs = [(1-math.cos(math.pi*i/n))/2 for i in range(n+1)]
    upper=[]
    lower=[]
    depths=[]
    for x in xs:
        u,l,d=point(x,.04,.18,-.1036,1)
        upper.append(u)
        lower.append(l)
        depths.append(d)
    xvalues=[p[0] for p in upper]
    x_min=min(xvalues)
    x_at_min=xs[xvalues.index(x_min)]
    upper_x_monotone=all(a<=b+1e-14 for a,b in zip(xvalues,xvalues[1:]))
    max_depth=max(depths)
    x_max_depth=xs[depths.index(max_depth)]
    archived_path=ROOT/'analysis/results/v5_radial_section_inputs01/fable_r025_n80.dat'
    archived=[tuple(map(float,line.split())) for line in archived_path.read_text().splitlines()[1:]]
    x80=[(1-math.cos(math.pi*i/80))/2 for i in range(81)]
    proposed80=[point(x,.06,.20,-.1015,0)[0] for x in reversed(x80)]
    proposed80.extend(point(x,.06,.20,-.1015,0)[1] for x in x80[1:])
    if len(archived)!=len(proposed80):
        raise ValueError('Unexpected archived r=.25 contour size')
    endpoint_diff=max(abs(a-b) for p,q in zip(archived,proposed80) for a,b in zip(p,q))
    report={
        'candidate':'V8-R', 'response_sha256':actual,
        'parent_r025_thickness_parameter':station['thickness_parameter'],
        'samples_per_surface':n+1,
        'root_upper_min_x_over_c':x_min,
        'root_upper_min_x_parameter':x_at_min,
        'root_upper_x_monotone_in_parameter':upper_x_monotone,
        'root_max_normal_depth_m':max_depth*.10,
        'root_max_depth_location_parameter':x_max_depth,
        'root_le_depth_m':depths[0]*.10,
        'root_te_depth_m':depths[-1]*.10,
        'r025_endpoint_max_coordinate_error_over_c':endpoint_diff,
        'model_minimum_thickness_018_m_claim_supported':False,
        'model_full_rectangle_attachment_claim_supported':False,
        'interpretation':'18 mm is an approximate maximum normal section depth, not minimum thickness or a full-chord attachment envelope; geometry unadopted',
    }
    OUT.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
