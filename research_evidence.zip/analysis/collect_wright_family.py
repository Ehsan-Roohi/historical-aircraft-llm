"""Audit retained reconstruction outputs without rerunning or repairing solver inputs."""
import argparse
import json
from pathlib import Path
from wright_reconstruction_family import ROOT, EXE, sha, parse, geometry, check_printed


def collect(folder):
    run = json.loads((folder/'summary.json').read_bytes())
    model = json.loads((folder/'definition.json').read_bytes())
    if sha(folder/'definition.json') != run['definition_sha256'] or sha(EXE) != run['solver_sha256']:
        raise ValueError('Definition/solver hash mismatch')
    for path,digest in model['source_hashes'].items():
        if sha(ROOT/path) != digest: raise ValueError('Source changed '+path)
    rows, incomplete = [], []
    for r in run['records']:
        case = folder/r['case']
        for name,digest in r['file_hashes'].items():
            if sha(case/name) != digest: raise ValueError('File changed '+name)
        if r.get('returncode') != 0:
            incomplete.append({'case':r['case'],'status':r['status']})
            continue
        expected_geometry = geometry(model,r['canard_section'],r['canard_incidence_deg'],r['nc'],r['ns_density_target'])
        if (case/'wing.avl').read_text() != expected_geometry: raise ValueError('Geometry differs from declared family')
        expected_commands = f"load wing.avl\noper\na a {r['alpha_deg']}\nx\nft\nforces.txt\n\nquit\n"
        if (case/'commands.txt').read_text() != expected_commands: raise ValueError('Commands differ')
        text = (case/'forces.txt').read_text()
        ref = model['reference']
        for k,v in {'Alpha':r['alpha_deg'],'Beta':0,'Mach':0,'Sref':ref['S_m2'],'Cref':ref['c_m'],'Bref':ref['b_m'],
                    'Xref':ref['x_aft_m'],'Yref':0,'Zref':ref['z_up_m']}.items():
            check_printed(text,k,v)
        reads = sum(len(s['stations_xle_chord_y_m']) for s in model['surfaces']
                    if s['name'].startswith('main') or r['canard_section']=='eiffel10_raw')
        stdout = (case/'stdout.txt').read_text(encoding='utf-8')
        if stdout.count('Reading airfoil from file: section.dat') != reads: raise ValueError('Read count mismatch')
        source_hashes = {k.replace('\\','/'):v for k,v in model['source_hashes'].items()}
        if sha(case/'section.dat') != source_hashes['analysis/references/eiffel10_uiuc.dat']:
            raise ValueError('Local section differs')
        rows.append({'case':r['case'],'canard_section':r['canard_section'],'canard_incidence_deg':r['canard_incidence_deg'],
                     'alpha_deg':r['alpha_deg'],'original_runner_status':r['status'],
                     'coefficients':{k:parse(text,k) for k in ['CLtot','CDind','Cmtot','CYtot','Cltot']}})
    if 'plan_sha256' in run:
        if sha(folder/'plan.json') != run['plan_sha256']: raise ValueError('Plan changed')
        plan = json.loads((folder/'plan.json').read_bytes())
        expected = {(s,i,a) for s in plan['sections'] for i in plan['canard_incidences_deg'] for a in plan['alpha_deg']}
        if any(r['nc']!=plan['nc'] or r['ns_density_target']!=plan['ns_density_target'] for r in run['records']):
            raise ValueError('Mesh differs from plan')
    else:
        expected = {(s,i,a) for s in ['flat','eiffel10_raw'] for i in sorted({r['canard_incidence_deg'] for r in run['records']}) for a in [0,4]}
    actual = {(r['canard_section'],r['canard_incidence_deg'],r['alpha_deg']) for r in run['records']}
    if len(run['records'])!=len(expected) or actual!=expected: raise ValueError('Missing/duplicate factorial record')
    return {'scope':model['scope'],'folder':str(folder.relative_to(ROOT)),
            'summary_sha256':sha(folder/'summary.json'),'verified_count':len(rows),'records':rows,
            'expected_count':len(expected),'incomplete_cases':incomplete,'all_cases_verified':not incomplete,
            'reference_check':'Expected values within half a last printed decimal unit; input geometry checked independently',
            'not_established':['Matched empirical validation','grid convergence','trim','total drag','flight capability']}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--folder',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args = p.parse_args()
    result = collect(args.folder.resolve())
    args.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__ == '__main__': main()
