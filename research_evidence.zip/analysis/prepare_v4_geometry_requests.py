"""Freeze geometry-closure requests; no network calls or claimed model responses."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    source = ROOT/'analysis/v3b_propulsion_inputs.json'
    out = ROOT/'analysis/prompts_v4_propulsion_geometry'
    out.mkdir(exist_ok=False)
    records = []
    corrections = {
        'gpt-6-astra': 'The V3c candidate twist at successive radii was [59.501661,40.031114,30.048789,22.928800,19.728747,16.876523,14.940381]. Use that candidate, explicitly NOT accepted V2 geometry. The existing symmetric section has x/c=[0,.1,.3,.6,1], upper y/c=[0,.045,.06,.035,0], lower=-upper. Preserve this exact piecewise-linear section for the first evaluation; do not smooth without logging a separate proposal.',
        'claude-fable-5-1': 'Your roughly 6%-cambered circular-arc-like flat-bottom section was not mathematically defined. Supply one explicit candidate consistent with radial thickness ratios [.30,.20,.15,.12,.11,.10,.09,.08,.08], or clearly log any incompatible thickness/camber change. This is a NEW geometry clarification, not recovered original data. Prop mass 12 kg replaces 5 kg: aircraft 302 kg before unquantified drive changes; old 412 N is not a validated retrim requirement.',
        'claude-opus-5-5': 'Your roughly 4%-cambered flat-bottom section and radial thickness ratios [.30,.18,.13,.10,.09,.08,.07,.06] are not fully specified. Define a reproducible candidate, flagging changes. Your beta was relative to lower face: give its exact conversion to LE-to-TE chord reference for the new geometry. Flight speed 15 m/s; axial speed 14.908064845 m/s. Forward is -x. Keep the V3b chain drive; do not silently replace it with a gearbox.'
    }
    for row in json.loads(source.read_bytes())['records']:
        model = row['model']
        prompt = '''V4-G: geometry closure for independent propulsion analysis.
This is a researcher-assisted iteration after an initial 1898-12-31 packet, NOT a
blind historical-knowledge test. Previous V2/V3 records remain immutable.
Your job is a reproducible blade definition, NOT an efficiency or flight claim.
Keep the supplied radii, chord, diameter, count and RPM; keep twist except for the
explicit Astra V3c candidate and any documented pitch-reference conversion.
Do not propose a new engine power rating to eliminate a shortfall.

Return one JSON object, no prose outside it, with these keys:
model, stage='v4_geometry_candidate', parent_stage, sections, stations,
rotation_convention, interpolation, changes, unresolved, status='UNVALIDATED'.
sections: list of unique IDs with EITHER upper/lower [x/c,y/c] arrays covering
x/c=0 through 1 strictly increasingly, OR complete analytic upper(x),lower(x)
expressions and all numeric parameters/domain. Specify LE, TE and chord line.
Normalized thickness must be nonnegative everywhere; no self intersections.
If arrays are used specify piecewise-linear interpolation; enough points to
represent your intended section, without claiming their aerodynamic accuracy.
stations: each r_m,chord_m,beta_chord_deg,section_id,thickness_ratio,camber_ratio.
Define beta relative to rotation plane and the LE-to-TE chord, not an undefined face.
State radial interpolation and whether section coordinates scale with local chord.
rotation_convention: define view direction in native coordinates, blade motion,
handedness of each propeller and thrust direction consistently.
changes: exact old/new values plus whether clarification or actual redesign.
Do not invent polars, CFD, BEM outputs, engine curves, material allowables, or tests.
Do not return guessed efficiency as a success criterion. The evaluator will
calculate thrust and torque from geometry and supply actual residuals afterward.
If a requested definition cannot be completed, return that explicit missing item;
do not replace missing physics with a verbal assurance.
'''+corrections[model]+'\nFrozen V3b numeric subset:\n'+json.dumps(row)
        path = out/f'{model}.prompt.txt'
        path.write_text(prompt, encoding='utf-8')
        records.append(dict(model_requested=model, prompt_file=path.name,
                            prompt_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                            sent=False, response=None))
    (out/'manifest.json').write_text(json.dumps(dict(stage='v4_geometry_candidate',
        source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(), records=records), indent=2), encoding='utf-8')
    print('Prepared 3 unsent requests:', out.relative_to(ROOT).as_posix())


if __name__ == '__main__':
    main()
