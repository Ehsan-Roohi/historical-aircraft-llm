"""One focused propulsion-definition request per original model."""
import json,hashlib
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
ROOT=Path(__file__).resolve().parents[1]
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    out=ROOT/'analysis/prompts_v3b_propulsion';out.mkdir(exist_ok=False)
    audit=json.loads((ROOT/'analysis/results/v2_subsystems01/summary.json').read_bytes())
    records=[]
    for r in audit['records']:
        model=r['model'];path=ROOT/f'analysis/results/received_v2_audit01/{model}.design.json';raw=path.read_bytes();d=json.loads(raw)
        prompt='''Focused V3b PROPULSION definition only. Do not redesign the whole aircraft.
Immutable baseline V2; V3a geometry proposals have NOT been accepted or merged.
Researcher-assisted historical aircraft design, cutoff 1898-12-31. Modern evaluation
is permitted but is not period evidence. Never invent a measured engine curve,
material allowable, aerodynamic polar, CFD run, thrust measurement or successful flight.
Return under 1200 words, exactly ONE valid JSON block, little or no prose.
Propose a fully numeric preliminary propeller/drive operating point that can be
independently evaluated. Keep baseline diameter, count, hub position and engine
power target; if impossible state infeasibility rather than increase power silently.
For Fable, retain V2 hubs (not V3a shifted hubs) and distinguish the model-claimed
412 N at 13 m/s from an independently trimmed requirement. Astra drag is incomplete;
Opus CD0=.05 is only assumed. Add a separate +25% thrust-demand stress case, not a
claim of quantified drag uncertainty. No independent feasibility claim is requested.

JSON schema (use these exact keys and numeric SI values):
stage, model, baseline, propeller: {count, blades_per_propeller, diameter_m,
hub_radius_m, stations:[{r_m,chord_m,beta_deg,thickness_ratio}], section_definition,
rotation_and_handedness, mass_kg_total, mass_status},
drive:{engine_rpm, propeller_rpm, speed_ratio_engine_over_prop,
mechanical_efficiency, topology, shaft_dimensions, mass_change_kg, assumptions},
operating_point:{V_m_s, thrust_required_N_total, engine_power_target_W,
assumed_propeller_efficiency, useful_power_W, prop_shaft_power_W_total,
engine_power_required_W, prop_torque_Nm_each, engine_torque_Nm,
advance_ratio, tip_helical_mach, speed_of_sound_m_s},
stress_case_25pct_extra_thrust, evidence_gaps, acceptance_tests, changes_from_V2.
Provide 6-10 strictly increasing radial stations from hub radius through diameter/2,
positive chord, beta relative to rotation plane in degrees. State airfoil assumption
explicitly; no claimed polar if unavailable. Equal loading for twin props.
State target engine power as UNVERIFIED, not available power. Torques from power/RPM,
not an invented engine curve. Transmission ratio must agree with both RPMs.
If a blade-element analysis has not actually been run, say so. Don't claim a chosen
efficiency follows from the new blade geometry. Preserve missing evidence as UNKNOWN.
Scope is a testable conditional design, not permission for construction or flight.
'''
        prompt+='\nCURRENT PROPULSION\n'+json.dumps(d['propulsion'],separators=(',',':'))+'\nEVALUATOR RECORD\n'+json.dumps(dict(model=model,propulsion=r['propulsion'],trim=r.get('trim'),limitations=audit['assumptions']),separators=(',',':'))
        p=out/f'{model}.prompt.txt';p.write_text(prompt,encoding='utf-8')
        records.append(dict(model_requested=model,prompt_file=p.name,prompt_sha256=sha(p.read_bytes()),parent_sha256=sha(raw),maximum_output_tokens=32000,sent=False,response=None))
    (out/'instructions.txt').write_text('Return compact complete numeric propulsion proposal JSON. Preserve evidence gaps. Do not fabricate tests or observed capability.',encoding='utf-8')
    (out/'manifest.json').write_text(json.dumps(dict(stage='v3b_propulsion',records=records),indent=2),encoding='utf-8')
    runner=(ROOT/'unity_jobs/run_design_revision_v3a.py').read_text(encoding='utf-8').replace('revision_v3a','revision_v3b')
    batch=(ROOT/'unity_jobs/run_design_revision_v3a.sbatch').read_text(encoding='utf-8').replace('revision_v3a','revision_v3b').replace('design-v3a','design-v3b')
    for name,text in [('run_design_revision_v3b.py',runner),('run_design_revision_v3b.sbatch',batch)]:
        (ROOT/'unity_jobs'/name).write_text(text,encoding='utf-8')
    dest=ROOT/'output/delivery/design_revision_v3b_attempt01.zip'
    with ZipFile(dest,'x',ZIP_DEFLATED) as z:
        for p in sorted(out.iterdir()):z.write(p,'prompts/'+p.name)
        z.writestr('run_design_revision_v3b.py',runner);z.writestr('run_design_revision_v3b.sbatch',batch)
    print(sha(dest.read_bytes()))
if __name__=='__main__':main()
