"""Unvalidated neutral-control lifting-surface pilot. No flight verdict.

Geometry simplifications and omissions documented in paper/avl_aircraft_pilot_v1.md.
Each mesh process <=90 sec for three angles; preserve each run directory and input hash.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import subprocess
from audit_mass_tables import summarize
from avl_reference_gate import parse

ROOT=Path(__file__).resolve().parents[1]
EXE=ROOT/'analysis/tools/avl/avl352.exe'


def surface(name,sections,nc,ns,foil=True,component=1):
    lines=['SURFACE',name,f'{nc} 1 {ns} 1','COMPONENT',str(component),'YDUPLICATE','0']
    for x,y,z,c in sections:
        lines+=['SECTION',f'{x:.8f} {y:.8f} {z:.8f} {c:.8f} 0']
        if foil:
            lines+=['AFILE','section.dat']
    return lines


def geometry(name,nc,ns):
    data=json.loads((ROOT/f'analysis/{name}_v1_extracted.json').read_text(encoding='utf-8'))
    cg=summarize(data)['cg_original_axes_m']
    if name=='astra':
        cg[0]=-cg[0]
        refs=(40,2,12)
        lines=surface('forward',[(-1.6,0,1.2,2),(-1.6,6,1.2,2)],nc,ns,component=1)
        lines+=surface('rear',[(1.9,0,1.75,1.6),(1.9,5,1.75,1.6)],nc,ns,component=2)
    elif name=='fable':
        refs=(42.55-4*.8**2*(1-math.pi/4),1.85,11.5)
        ys=[0,4.25,4.95]+[4.95+.8*math.sin(i*math.pi/16) for i in range(1,9)]
        shape=[(1,y,0,1.85 if y<=4.95 else 1.05+math.sqrt(max(0,.8**2-(y-4.95)**2))) for y in ys]
        lines=surface('lower',shape,nc,ns,component=1)
        lines+=surface('upper',[(x,y,1.85,c) for x,y,z,c in shape],nc,ns,component=2)
        lines+=surface('tail',[(5.4,0,.775,1),(5.4,1.7,.775,1)],nc,ns//2,foil=False,component=3)
    else:
        refs=(38,1.8,11)
        shape=[(0,y,max(0,y-1.4)*math.tan(math.radians(1)),1.8) for y in [0,1.4,3.5,5.5]]
        lines=surface('lower',shape,nc,ns,component=1)
        lines+=surface('upper',[(x,y,z+1.8,c) for x,y,z,c in shape],nc,ns,component=2)
        # Continuous tailplane; center notch retained via distinct inner/outer patches.
        lines+=surface('tail_inner',[(4.5,0,.6,1.1),(4.5,.25,.6,1.1)],nc,4,foil=False,component=3)
        lines+=surface('tail_outer',[(4.5,.25,.6,1.6),(4.5,2.2,.6,1.6)],nc,ns//2,foil=False,component=3)
    return '\n'.join([name+' neutral diagnostic','0','0 0 0',' '.join(map(str,refs)),' '.join(map(str,cg)),'0']+lines)+'\n'


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--models',nargs='+',choices=['astra','fable','opus'],default=['astra','fable','opus'])
    args=parser.parse_args()
    out=args.output.resolve()
    out.mkdir(parents=True,exist_ok=False)
    foilpath=ROOT/'analysis/airfoil_ordinates_v0.json'
    foils=json.loads(foilpath.read_text(encoding='utf-8'))
    records=[]
    for name in args.models:
        foil=foils[name]
        pts=list(zip(foil['x'],foil['upper']))[::-1]+list(zip(foil['x'],foil['lower']))[1:]
        section=name+' V0 table\n'+'\n'.join(f'{x} {z}' for x,z in pts)+'\n'
        for nc,ns in [(8,40),(12,80)]:
            geom=geometry(name,nc,ns)
            mesh=out/f'{name}_c{nc}_s{ns}_batch'
            mesh.mkdir()
            (mesh/'aircraft.avl').write_text(geom,encoding='ascii')
            (mesh/'section.dat').write_text(section,encoding='ascii')
            command='load aircraft.avl\noper\n'+''.join(f'a a {a}\nx\nft\nforces_a{a}.txt\n' for a in [0,4,8])+'\nquit\n'
            (mesh/'commands.txt').write_text(command,encoding='ascii')
            try:
                p=subprocess.run([str(EXE)],input=command,cwd=mesh,capture_output=True,text=True,timeout=90,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            except subprocess.TimeoutExpired as e:
                (mesh/'timeout.txt').write_text(str(e),encoding='utf-8')
                for stream in ['stdout','stderr']:
                    value=getattr(e,stream) or b''
                    if isinstance(value,bytes): value=value.decode(errors='replace')
                    (mesh/f'{stream}.txt').write_text(value,encoding='utf-8')
                raise
            (mesh/'stdout.txt').write_text(p.stdout,encoding='utf-8')
            (mesh/'stderr.txt').write_text(p.stderr,encoding='utf-8')
            if p.returncode!=0:
                raise RuntimeError(f'Failed mesh {mesh.name}')
            for alpha in [0,4,8]:
                case=out/f'{name}_c{nc}_s{ns}_a{alpha}'
                case.mkdir()
                (case/'aircraft.avl').write_text(geom,encoding='ascii')
                (case/'section.dat').write_text(section,encoding='ascii')
                raw=(mesh/f'forces_a{alpha}.txt').read_bytes()
                (case/'forces.txt').write_bytes(raw)
                text=(case/'forces.txt').read_text()
                row={'model':name,'nc':nc,'ns':ns,'alpha_deg':alpha,'geometry_sha256':hashlib.sha256((mesh/'aircraft.avl').read_bytes()).hexdigest(),'batch_directory':mesh.name}
                row.update({k:parse(text,k) for k in ['CLtot','CDind','Cmtot','Cltot','CYtot']})
                records.append(row)
                (out/'partial_records.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
                print(row,flush=True)
    result={'scope':'Unvalidated attached-flow lifting surfaces only, neutral controls, no propulsion, not trimmed','solver_sha256':hashlib.sha256(EXE.read_bytes()).hexdigest(),'ordinates_sha256':hashlib.sha256(foilpath.read_bytes()).hexdigest(),'records':records}
    (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':
    main()
