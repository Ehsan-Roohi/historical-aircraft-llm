"""Read-only inspection of user-supplied PDFs; previews and extracted text only."""
from pathlib import Path
import json
import re
import unicodedata
import pypdfium2 as pdfium
from PIL import Image, ImageDraw
from pypdf import PdfReader

OUT = Path(__file__).resolve().parents[1] / 'tmp/pdfs/design_notes'
OUT.mkdir(parents=True, exist_ok=True)
for stem in ['Aircraft_Design1', 'Aircraft_Design2']:
    path = Path('C:/Users/roohie/Downloads') / (stem + '.pdf')
    reader = PdfReader(path)
    texts = []
    for i, page in enumerate(reader.pages):
        text = page.extract_text() or ''
        text = re.sub(r'/u([0-9A-Fa-f]{4})', lambda m: chr(int(m[1], 16)), text)
        texts.append({'page': i+1, 'text': unicodedata.normalize('NFKC', text)})
    (OUT / (stem + '.json')).write_text(json.dumps(texts, ensure_ascii=False, indent=2), encoding='utf-8')
    doc = pdfium.PdfDocument(str(path))
    for start in range(0, len(doc), 12):
        sheet = Image.new('RGB', (1200, 1720), 'white')
        draw = ImageDraw.Draw(sheet)
        for j in range(start, min(start+12, len(doc))):
            im = doc[j].render(scale=0.6).to_pil().convert('RGB')
            im.thumbnail((390, 400))
            col, row = (j-start)%3, (j-start)//3
            sheet.paste(im, (col*400, row*430+25))
            draw.text((col*400+10, row*430+5), f'{stem} PDF page {j+1}', fill='black')
        sheet.save(OUT / f'{stem}_contact_{start+1:03d}.png')
    print(stem, len(doc), 'pages')
