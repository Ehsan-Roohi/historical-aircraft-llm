"""Check review-PDF text coverage, text bounds, embedded fonts and source hashes.

Visual approval is recorded separately in paper/pdf_review_qa_v1.md.
This script does not establish scientific validity or journal compliance.
"""
from pathlib import Path
import html
import json
import re
import pdfplumber
from pypdf import PdfReader
from build_review_pdf import ROOT, SOURCE, OUT, digest, inline


def normalized(text):
    return re.sub(r"\s+", "", text)


def main():
    path = OUT / "aircraft_manuscript_review_v1.pdf"
    manifest = json.loads((OUT / "aircraft_manuscript_review_v1_manifest.json").read_text(encoding="utf-8"))
    assert digest(path) == manifest["pdf_sha256"]
    assert digest(SOURCE) == manifest["source_sha256"]
    reader = PdfReader(path)
    extracted_pages = []
    for page in reader.pages:
        text = page.extract_text() or ""
        # The page callback paints the footer first in the content stream.
        text = re.sub(r"^Private working draft - no flight validation or superiority claim\n\d+\n", "", text)
        extracted_pages.append(text)
    whole = normalized("\n".join(extracted_pages))
    failures, checked, in_math = [], 0, False
    for number, raw in enumerate(SOURCE.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if line == r"\[":
            in_math = True
            continue
        if line == r"\]":
            in_math = False
            continue
        if in_math or not line or line.startswith("!["):
            continue
        if line.startswith("|"):
            chunks = [c.strip() for c in line.strip("|").split("|")]
            if all(re.fullmatch(r":?-+:?", c) for c in chunks):
                continue
        else:
            chunks = [line.lstrip("# ")]
        for chunk in chunks:
            expected = normalized(html.unescape(re.sub(r"<[^>]*>", "", inline(chunk))))
            checked += 1
            if expected not in whole:
                failures.append({"line": number, "text": chunk})
    assert not failures, failures
    bounds_failures = []
    with pdfplumber.open(path) as document:
        for number, page in enumerate(document.pages, 1):
            for char in page.chars:
                if char["x0"] < 35 or char["x1"] > page.width - 35 or char["top"] < 20 or char["bottom"] > page.height - 15:
                    bounds_failures.append({"page": number, "text": char["text"], "box": [char["x0"], char["top"], char["x1"], char["bottom"]]})
    assert not bounds_failures, bounds_failures
    embedded = set()
    for page in reader.pages:
        for ref in page["/Resources"]["/Font"].values():
            font = ref.get_object()
            name = str(font.get("/BaseFont", ""))
            if "TimesNewRoman" in name:
                descriptor = font["/FontDescriptor"].get_object()
                assert "/FontFile2" in descriptor, name
                embedded.add(name)
    assert len(embedded) >= 3, embedded
    for asset in manifest["figure_assets"]:
        assert digest(ROOT / asset["path"]) == asset["sha256"]
        assert asset["effective_dpi"] > 290
    result = {
        "scope": "Private-review PDF content and layout checks; not scientific validation",
        "pdf_sha256": digest(path), "source_sha256": digest(SOURCE),
        "pages": len(reader.pages), "source_text_chunks_verified": checked,
        "source_text_missing": failures, "text_bounds_failures": bounds_failures,
        "embedded_body_fonts": sorted(embedded),
        "figures_verified": len(manifest["figure_assets"]),
        "equations": "Six guarded renderings; visually review against TeX source",
        "visual_review_record": "paper/pdf_review_qa_v1.md",
    }
    (OUT / "aircraft_manuscript_review_v1_audit.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
