"""Stage the rewritten manuscript locally; ZIP sealing follows PDF QA."""
from pathlib import Path
import shutil
import re
import json
ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'output/overleaf/aircraft_scientific_revision_v4'
DEST.mkdir(parents=True,exist_ok=True)
(DEST/'figures').mkdir(exist_ok=True)
shutil.copy2(ROOT/'paper/article_v4.tex', DEST/'main.tex')
shutil.copy2(ROOT/'paper/references_v2.tex', DEST/'references_v2.tex')
for name in ['wright_response_v1.png','fixed_control_response_v1.png']:
    shutil.copy2(ROOT/'output/figures'/name,DEST/'figures'/name)
shutil.copy2(ROOT/'output/figures_v2/configuration_comparison_v2.png',DEST/'figures/configuration_comparison_v2.png')
for model in ['astra','fable','opus']:
    for view in ['oblique','three_view']:
        name=f'{model}_{view}_v0.png'
        shutil.copy2(ROOT/'output/aircraft_atlas_v0'/name,DEST/'figures'/name)
for name in ['literature_review_v2.md','flight_mechanics_revision_v2.md','revision_experiment_v2.md','design_notes_scope_v2.md','retrim_v2.md']:
    shutil.copy2(ROOT/'paper'/name, DEST/name)
source=(DEST/'main.tex').read_text(encoding='utf-8')
refs=(DEST/'references_v2.tex').read_text(encoding='utf-8')
cited=set(k for group in re.findall(r'\\cite\{([^}]+)\}',source) for k in group.split(','))
defined=set(re.findall(r'\\bibitem\{([^}]+)\}',refs))
assert cited==defined=={f'ref{i}' for i in range(1,35)},(cited^defined)
for asset in re.findall(r'\\includegraphics\[[^]]+\]\{([^}]+)\}',source):
    assert (DEST/asset.replace(r'\figdir','figures')).is_file(),asset
assert 'Ehsan Roohi' in source and '1898' in source
print(json.dumps({'staged':str(DEST),'references':len(defined),'compiled':False},ensure_ascii=True))
