"""Describe two-grid and finite-difference changes; no validation verdict."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    coarse = json.loads((ROOT/'analysis/results/avl_control_probe01/summary.json').read_text())['records']
    fine = [r for r in json.loads((ROOT/'analysis/results/avl_control_probe02/summary.json').read_text())['records'] if r['model']=='astra']
    fine += json.loads((ROOT/'analysis/results/avl_control_probe03/summary.json').read_text())['records']
    assert len(coarse) == len(fine) == 3, 'Require all three completed models'
    rows = []
    for c, f in zip(coarse, fine):
        assert c['model'] == f['model']
        assert all(v == 0 for v in f['zero_minus_prior'].values()), 'Neutral mismatch'
        row = {'model':f['model'], 'mesh_change_percent':{}, 'half_step_change_percent':{}}
        for key in ['CLtot','CDind','Cmtot']:
            a, b = c['central_derivative_per_deg'][key], f['central_derivative_per_deg'][key]
            h = f['half_step_derivative_per_deg'][key]
            row['mesh_change_percent'][key] = 100*(b/a-1)
            row['half_step_change_percent'][key] = 100*(h/b-1)
        rows.append(row)
    output = {'scope':'Relative derivative changes; not physical uncertainty bounds', 'rows':rows}
    (ROOT/'analysis/results/control_probe_comparison_v1.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(output,indent=2))


if __name__ == '__main__':
    main()
