"""Plot reconstructed coordinates, without modifying or republishing source raster."""
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
data=json.loads((ROOT/'analysis/results/wright_planform_trace_v1.json').read_bytes())
image=Image.new('RGB',(1200,720),'white')
draw=ImageDraw.Draw(image)
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',18)
title=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',24)
def position(x,y): return (600+75*y,360-75*x)
draw.text((50,25),'Researcher trace of a Wright plan-view reproduction',fill='black',font=title)
draw.text((50,63),'Not a matched tunnel geometry or a validated aircraft model',fill='#aa3333',font=font)
for y in range(-7,8):
    draw.line([position(-3,y),position(3,y)],fill='#dddddd')
    draw.text((position(-3,y)[0]-9,596),str(y),fill='black',font=font)
for x in range(-3,4):
    draw.line([position(x,-7),position(x,7)],fill='#dddddd')
    draw.text((38,position(x,-7)[1]-10),str(x),fill='black',font=font)
draw.text((65,105),'Aft (m)',fill='black',font=font)
for (name,row),color in zip(data['outlines'].items(),['#1858a8','#b75015']):
    points=[position(*p) for p in row['coordinates_x_aft_y_image_right_m']]
    draw.line(points+points[:1],fill=color,width=3)
    for u,v in points: draw.ellipse((u-3,v-3,u+3,v+3),fill=color)
draw.text((280,635),'Lateral image-right (m; not certified aircraft starboard)',fill='black',font=font)
draw.text((120,680),'Span-calibrated trace; no fitting to stated wing area. Approximate main-wing LE origin.',fill='black',font=font)
image.save(ROOT/'output/wright_planform_trace_v1.png')
