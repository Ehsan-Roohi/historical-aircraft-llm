"""Necessary ideal-disk screen, never a geometry-derived feasibility certificate."""
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def screen(thrust, axial_speed, diameter, count, engine_target, drive, rho=1.225):
    values = (thrust, axial_speed, diameter, count, engine_target, drive, rho)
    if not all(math.isfinite(x) for x in values):
        raise ValueError('Nonfinite input')
    if min(thrust, diameter, count, engine_target, rho) <= 0 or axial_speed < 0:
        raise ValueError('Positive loads/geometry required; axial speed must be nonnegative')
    if int(count) != count or not 0 < drive <= 1:
        raise ValueError('Invalid count or transmission efficiency')
    area = count * math.pi * diameter**2 / 4
    induced = (math.sqrt(axial_speed**2 + 2*thrust/(rho*area))-axial_speed)/2
    minimum = thrust*(axial_speed+induced)
    shaft_target = engine_target*drive
    return dict(ideal_shaft_minimum_W=minimum,
                conditional_engine_minimum_W=minimum/drive,
                ideal_prop_efficiency_ceiling=axial_speed/(axial_speed+induced),
                required_prop_efficiency=thrust*axial_speed/shaft_target,
                conditional_shaft_loss_budget_W=shaft_target-minimum,
                verdict=('IDEAL_BOUND_EXCEEDED' if minimum > shaft_target
                         else 'NOT_RULED_OUT_NOT_VALIDATED'))


def main():
    source = ROOT/'analysis/v3b_propulsion_inputs.json'
    rows = []
    for row in json.loads(source.read_bytes())['records']:
        va = row['V']*math.cos(math.radians(row['alpha']))
        rows.append(dict(model=row['model'], axial_speed_m_s=va,
                         cases=[dict(demand_multiplier=f, **screen(
                             row['T']*f, va, row['D'], row['count'],
                             row['target'], row['drive'])) for f in (1, 1.25)]))
    result = dict(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                  limitations=['Unverified engine targets, assumed drive efficiency.',
                               'Uniform isolated axial disks, equal twin loading; no installation losses.',
                               'Demand points are conditional, not a common validated mission.',
                               '25% is a stress scenario, not a measured uncertainty interval.',
                               'Passing this necessary bound is not sufficient for a viable propeller.'],
                  records=rows)
    out = ROOT/'analysis/results/propulsion_path_reset01'
    out.mkdir(exist_ok=True)
    with (out/'ideal_screen.json').open('x', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
