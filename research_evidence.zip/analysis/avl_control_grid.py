"""Coarse normal-tilt grid for conditional trim, not usable-control certification."""
import json
import hashlib
import subprocess
from avl_control_probe import controlled_geometry
from avl_aircraft_pilot import ROOT, EXE
from avl_reference_gate import parse

DELTAS={'astra':[-4,0,4],'fable':[-12,0,12],'opus':[-10,0,10]}


def main():
    out=ROOT/'analysis/results/avl_control_grid01'
    out.mkdir(exist_ok=False)
    rows=[]
    for model,deltas in DELTAS.items():
        case=out/model
        case.mkdir()
        (case/'aircraft.avl').write_text(controlled_geometry(model),encoding='ascii')
        source=ROOT/f'analysis/results/avl_control_probe01/{model}/section.dat'
        (case/'section.dat').write_bytes(source.read_bytes())
        command='load aircraft.avl\noper\n'
        for alpha in [0,4,8]:
            for delta in deltas:
                command+=f'a a {alpha}\nd1 d1 {delta}\nx\nft\na{alpha}_d{delta}.txt\n'
        command+='\nquit\n'
        (case/'commands.txt').write_text(command,encoding='ascii')
        try:
            p=subprocess.run([str(EXE)],input=command,cwd=case,capture_output=True,text=True,timeout=180,
                             creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        except subprocess.TimeoutExpired as e:
            (case/'timeout.txt').write_text(str(e),encoding='utf-8')
            for key in ['stdout','stderr']:
                value=getattr(e,key) or b''
                if isinstance(value,bytes): value=value.decode(errors='replace')
                (case/f'{key}.txt').write_text(value,encoding='utf-8')
            raise
        (case/'stdout.txt').write_text(p.stdout,encoding='utf-8')
        (case/'stderr.txt').write_text(p.stderr,encoding='utf-8')
        if p.returncode: raise RuntimeError(model)
        for alpha in [0,4,8]:
            values={}
            hashes={}
            for delta in deltas:
                path=case/f'a{alpha}_d{delta}.txt'
                values[str(delta)]={key:parse(path.read_text(),key) for key in ['CLtot','CDind','Cmtot']}
                hashes[path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
            row={'model':model,'alpha_deg':alpha,'deltas_deg':deltas,'values':values,'force_sha256':hashes,
                 'geometry_sha256':hashlib.sha256((case/'aircraft.avl').read_bytes()).hexdigest(),
                 'mechanical_status':'known_tail_fin_interference' if model=='fable' else 'not_verified'}
            rows.append(row)
            print(json.dumps(row),flush=True)
        (out/'summary.json').write_text(json.dumps({'scope':'Unvalidated coarse normal-tilt grid; large-control separation and finite rotation not represented','rows':rows},indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':
    main()
