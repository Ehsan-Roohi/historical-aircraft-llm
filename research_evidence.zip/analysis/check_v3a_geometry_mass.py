"""Independent checks of V3a proposals read from verified remote responses.

No changes applied to parent geometry. Proposal values are explicitly transcribed;
full remote response hashes are retained in the submission receipt.
"""
import json, math, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def cg(rows,mkey,ckey):
    mass=sum(r[mkey] for r in rows)
    return mass,[sum(r[mkey]*r[ckey][i] for r in rows)/mass for i in range(3)]

def tail_sweep(thickness=0):
    # x aft, z up; positive TE-down. Rotate (u,v) by x=u cos+t sin,
    # z=-u sin+t cos around (5.65,.775). Include angle stationary points.
    points=[]
    lo,hi=map(math.radians,[-16,8])
    for u in [-.25,.75]:
        for v in [-thickness/2,thickness/2]:
            angles=[lo,hi]
            for base in [math.atan2(v,u),math.atan2(-u,v)]:
                angles += [base+k*math.pi for k in range(-2,3) if lo<=base+k*math.pi<=hi]
            points += [(5.65+u*math.cos(a)+v*math.sin(a),.775-u*math.sin(a)+v*math.cos(a)) for a in angles]
    return dict(x=[min(p[0] for p in points),max(p[0] for p in points)],z=[min(p[1] for p in points),max(p[1] for p in points)])

def point_segment_distance(p,a,b):
    d=[y-x for x,y in zip(a,b)]
    t=max(0,min(1,sum((x-y)*z for x,y,z in zip(p,a,d))/sum(z*z for z in d)))
    return math.dist(p,[x+t*y for x,y in zip(a,d)])

def main():
    paths={m:ROOT/f'analysis/results/received_v2_audit01/{m}.design.json' for m in ['gpt-6-astra','claude-fable-5-1','claude-opus-5-5']}
    a,f,o=[json.loads(paths[m].read_bytes()) for m in paths]
    # Reconcile Opus boom tube length and centroid from actual endpoint geometry.
    nodes=o['structural_members']['nodes']; edges=[('BL0','BJ'),('BU0','BJ'),('BJ','BE')]
    lengths=[math.dist(nodes[x],nodes[y]) for x,y in edges]
    area=math.pi/4*(.05**2-.048**2); mass=2*sum(lengths)*area*7850
    tc=[sum(l*(nodes[x][i]+nodes[y][i])/2 for l,(x,y) in zip(lengths,edges))/sum(lengths) for i in range(3)];tc[1]=0
    assembly=mass+3; ac=[(mass*tc[i]+3*[4,0,.6][i])/assembly for i in range(3)]
    newrows=json.loads(json.dumps(o['mass_items']))
    boom=next(r for r in newrows if r['id']=='B1');boom.update(mass=assembly,centroid=ac)
    sparlength=2*sum(math.dist(nodes[x],nodes[y]) for chain in [('LF0','LF1','LF2','LF3'),('LR0','LR1','LR2','LR3')] for x,y in zip(chain,chain[1:]))
    frows=json.loads(json.dumps(f['mass_items']))
    next(r for r in frows if r['id']=='P07')['centroid_xyz']=[1.575,0,1.1]
    # Shaft parallel to x, wire lies in fixed x plane: exact centreline closest
    # distance is the yz point-to-segment distance, not horizontal gap at fixed z.
    gaps=[point_segment_distance([1.75,.8],aa,bb)-.020-.001 for aa,bb in [([.9,.14],[2.6,1.85]),([.9,1.85],[2.6,.14])]]
    rad=math.hypot(1.2,.04*math.cos(.35))
    result=dict(proposal_provenance='V3a remote JSON excerpts; hashes in unity_jobs/design_revision_v3a_submission.json',
      source_sha256={m:hashlib.sha256(p.read_bytes()).hexdigest() for m,p in paths.items()},
      astra=dict(tip_corner_radius_m=rad,level_clearance_m=1.6-rad,status='Arithmetic agrees; full blade thickness and loaded-clearance checks not established'),
      fable=dict(tail_zero_thickness=tail_sweep(),tail_assumed_50mm_centered_thickness=tail_sweep(.05),
                 proposed_tail_x=[5.41,6.40],proposed_tail_z=[.568,.982],
                 tail_verdict='FAIL: misses x=5.40 at zero total incidence; upper z bound omits stated thickness; neutral convention also needs freezing.',
                 drive_exact_nominal_gaps_m=gaps,claimed_drive_gap_m=.173,
                 drive_verdict='Overestimated gap: horizontal separation is not minimum normal distance; remains positive in this isolated rigid wire/shaft scenario.',
                 mass_after_tank_move_only=cg(frows,'mass_kg','centroid_xyz'),
                 engine_tank_interface_gap_m=0,added_post_mass_kg=.3,
                 mass_verdict='295 kg preserved only by unproved allowance absorption; added posts and longer shaft require explicit mass reconciliation.'),
      opus=dict(boom_segment_lengths_m=lengths,tube_area_m2=area,tube_mass_kg=mass,tube_cg_xyz=tc,
                assembly_mass_kg=assembly,assembly_cg_xyz=ac,aircraft_after=cg(newrows,'mass','centroid'),
                reported_tube_cg_xyz=[3.236,0,.611],reported_assembly_cg_xyz=[3.345,0,.609],
                explicit_lower_spar_length_m=sparlength,claimed_spar_length_m=22,
                verdict='Tube mass and centroid agree within reported rounding. Spar nodes stop at y=5.3 whereas wing reaches 5.5; 22m assumes undocumented extensions.',
                qualification='Uniform straight tube density 7850 kg/m3 and 3 kg fittings at (4,0,.6) are assumptions, not material/strength validation.'))
    dest=ROOT/'analysis/results/v3a_geometry_mass_check01';dest.mkdir(parents=True,exist_ok=True)
    (dest/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
