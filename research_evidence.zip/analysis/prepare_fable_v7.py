#!/usr/bin/env python3
"""Freeze correction feedback to Fable with complete, hash-checked V6 evidence."""
import argparse
import hashlib
import json
from pathlib import Path

MODEL = 'claude-fable-5-1'
STAGE = 'v7_fable_planform_and_root_correction'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--project-root', type=Path, default=Path('.'))
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    root = args.project_root.resolve()
    out = args.output.resolve()
    audit = json.loads((root/'analysis/results/v6_propeller_response_audit_64966337.json').read_text(encoding='utf-8'))
    response_path = root/'design_revision_v6_attempt01/responses'/MODEL/'response.json'
    raw_response = response_path.read_bytes()
    if sha(raw_response) != audit['models'][MODEL]['carrier_sha256']:
        raise ValueError('V6 Fable response SHA mismatch')
    parent = json.loads(raw_response)
    if parent['status'] != 'completed' or parent['model_returned'] != MODEL:
        raise ValueError('Unexpected V6 Fable carrier')
    v3path = root/'analysis/v3b_propulsion_inputs.json'
    raw_v3 = v3path.read_bytes()
    v3 = next(r for r in json.loads(raw_v3)['records'] if r['model'] == MODEL)
    stations = v3['stations']
    expected = [[.12,.10,64.8],[.25,.16,45.5],[.40,.19,32.5],
                [.55,.20,24.8],[.70,.19,20.0],[.85,.17,16.7],
                [1.00,.14,14.3],[1.10,.10,13.0],[1.15,.04,12.5]]
    if stations != expected:
        raise ValueError('V3b baseline has changed')
    instructions = (
        'You are repairing one researcher-assisted historical aircraft propeller candidate. '
        'Do not overwrite the original design, V2, V3b, V4, V5, or V6. '
        'Return one strict JSON object with no markdown. An XFOIL row is a numerical '
        'diagnostic, not proof of thrust, torque, engine match, structural safety, or flight. '
        'Do not invent polar coefficients, engine curves, material strengths, measured data, '
        'or validation. Set status=UNVALIDATED.\n'
    )
    feedback = (
        'V7 correction after independent audit of your V6 response, Unity 64966337. '
        'Your V6 was NOT accepted as a trailing-edge-only redesign. The archived V3b '
        'chord/pitch table, preserved through V4 and V5, is exactly '
        '[[r_m,c_m,beta_deg]] = '+json.dumps(stations)+'. '
        'Your V6 table instead gave chords [0.14,0.18,0.20,0.20,0.19,0.17,0.14,0.11,0.08] m. '
        'Five stations changed: r=.12 +.04m, .25 +.02m, .40 +.01m, 1.10 +.01m, '
        '1.15 +.04m. The tip chord doubled. These are a separate planform redesign, '
        'not NO_CHANGE. Baseline c_tip=.04m makes a constant 1.5mm TE 3.75% of chord. '
        'At r=.12m, V=13m/s, 600rpm, V_rel=sqrt(13^2+(2*pi*10*.12)^2)=15.02827m/s, '
        'not 14.03. At baseline c=.10m and nu=1.46e-5m2/s, Re=102933, not 134500. '
        'For comparisons with the archived radial array 64965852, retain its recorded '
        'RHO=1.225kg/m3 and MU=1.81e-5Pa*s, and recompute Re transparently. '
        'Root accepted V5 angles at BOTH densities were only 0 and 2 degrees. They '
        'do not bound the no-induction 4.913-degree incidence; therefore your proposed '
        '0-to-2-degree CL/CD interval is NOT a defensible aerodynamic bound. '
        'Also, your propeller-B local chord vector crossed with its upper-surface '
        'vector equals -z, not the claimed right-handed +z. Fix frame parity or '
        'explicitly declare the mirrored local basis left-handed and show a numeric '
        'position/normal check.\n'
        'Choose a minimal justified response. You may return NO_CHANGE and an explicit '
        'test plan if the tip TE/hub cannot yet be chosen. If you propose a TE redesign, '
        'use the exact archived chords in the candidate and compute each station k, '
        'TE/c, Re and maximum thickness from its formula. Keep any alternative chord '
        'planform as a separately named candidate. Do not silently substitute it. '
        'If r=.12 is unbracketed, mark its aerodynamic contribution UNKNOWN rather '
        'than integrate 0/2-degree data as bounds. Separate the section numerical '
        'tests from strength, assembly and shaft-power tests.\n'
        'Return JSON keys model,stage,parent_response_sha256,disposition,baseline_preserved,'
        'geometry_revision,radial_station_table,root_polar_status,assembly_frame,'
        'test_plan,assumptions,unresolved,status. The stage must be '+STAGE+'. '
        'Parent V6 carrier SHA-256 is '+sha(raw_response)+'. V3b numeric table SHA-256 '
        'is '+sha(raw_v3)+'. Set status UNVALIDATED.\n'
        'YOUR COMPLETE V6 RESPONSE (for continuity, not evidence):\n'+parent['response']+'\n'
    )
    out.mkdir(parents=True,exist_ok=False)
    (out/'instructions.txt').write_bytes(instructions.encode('utf-8'))
    (out/'prompt.txt').write_bytes(feedback.encode('utf-8'))
    manifest = dict(stage=STAGE,model_requested=MODEL,parent_model_job='64966337',
                    parent_response_sha256=sha(raw_response),parent_v3b_sha256=sha(raw_v3),
                    instructions_sha256=sha(instructions.encode('utf-8')),
                    prompt_sha256=sha(feedback.encode('utf-8')),
                    maximum_output_tokens=16000,sent=False)
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(stage=STAGE,prompt_characters=len(feedback),
                          parent_response_sha256=sha(raw_response))))


if __name__ == '__main__':
    main()
