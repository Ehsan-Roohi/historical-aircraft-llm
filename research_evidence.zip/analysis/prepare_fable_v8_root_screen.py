#!/usr/bin/env python3
"""Freeze an unadopted V8-R root-section solver diagnostic."""
import hashlib
import json
import math
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'analysis/results/fable_v8r_root_inputs01'
RESPONSE=ROOT/'analysis/results/fable_v8_attempt01/responses/claude-fable-5-1/response.json'
PARENT=ROOT/'analysis/results/v5_radial_section_inputs01/manifest.json'
RESPONSE_SHA='30775cc367af07747c27b440be5e50b336482fef71e6eca21c35526cc23b905a'
DENSITIES=(80,120,160)
ANGLES=(3,4,5,6,7)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def ordinate(x):
    m=.04
    t=.18
    yc=4*m*x*(1-x)
    yt=5*t*(.2969*math.sqrt(x)-.1260*x-.3516*x*x+.2843*x**3-.1036*x**4)
    theta=math.atan(4*m*(1-2*x))
    return (x-yt*math.sin(theta),yc+yt*math.cos(theta)),(x+yt*math.sin(theta),yc-yt*math.cos(theta))

def contour(n,label):
    xs=[(1-math.cos(math.pi*i/n))/2 for i in range(n+1)]
    upper=[ordinate(x)[0] for x in reversed(xs)]
    lower=[ordinate(x)[1] for x in xs[1:]]
    return label+'\n'+''.join(f'{x:.12f} {y:.12f}\n' for x,y in upper+lower)

def main():
    if sha(RESPONSE)!=RESPONSE_SHA:
        raise ValueError('V8 response changed')
    model=json.loads(json.loads(RESPONSE.read_text(encoding='utf-8'))['response'])
    if model['candidate_name']!='V8-R' or model['status']!='UNVALIDATED':
        raise ValueError('Unexpected candidate')
    parent=json.loads(PARENT.read_text(encoding='utf-8'))
    original=next(s for s in parent['stations'] if s['stem']=='fable_r012')
    station={**original,'stem':'fable_v8r_r012','candidate_name':'V8-R',
             'thickness_parameter':.18,'camber_parameter':.04,
             'candidate_qualification':'UNADOPTED model section; normal projected ordinates'}
    if OUT.exists():
        raise FileExistsError(OUT)
    OUT.mkdir(parents=True)
    sections=[]
    for n in DENSITIES:
        name=f'fable_v8r_r012_n{n}.dat'
        path=OUT/name
        path.write_text(contour(n,name),encoding='utf-8',newline='\n')
        sections.append({'file':name,'density':n,'sha256':sha(path),'points':2*n+1})
    manifest={'stage':'fable_v8r_root_numerical_screen',
              'parent_model_response_sha256':RESPONSE_SHA,
              'parent_v5_manifest_sha256':sha(PARENT),
              'station':station,'densities':list(DENSITIES),'angles_deg':list(ANGLES),
              'sections':sections,'numerical_screen_only':True,
              'interpretation':'Unadopted V8-R 2D section diagnostic; no thrust, structure or flight evidence'}
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'cases':len(DENSITIES)*len(ANGLES),'root_incidence':station['geometric_incidence_no_induction_deg']}))

if __name__=='__main__':
    main()
