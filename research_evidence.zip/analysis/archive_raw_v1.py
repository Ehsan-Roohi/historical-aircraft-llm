"""Promote an editor-transfer candidate only when registered raw bytes match.

Candidate files are retained. Allowed transport repair is removal of one final
LF added by text-file authoring. No JSON reserialization or content repair.
"""
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def verified_bytes(candidate, expected_hash):
    variants = [("none", candidate)]
    if candidate.endswith(b"\n"):
        variants.append(("remove_one_terminal_LF", candidate[:-1]))
    for operation, value in variants:
        if hashlib.sha256(value).hexdigest() == expected_hash:
            json.loads(value)
            return operation, value
    raise ValueError("No permitted transfer variant matches the frozen raw hash")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", choices=["gpt-6-astra", "claude-fable-5-1", "claude-opus-5-5"])
    args = parser.parse_args()
    registry_path = ROOT / "paper/baselines/baseline_registry_v1.json"
    registry = json.loads(registry_path.read_text(encoding="utf-8"))
    entry = next(row for row in registry["models"] if row["model_requested"] == args.model)
    candidate_path = ROOT / "analysis/raw_v1" / (args.model + ".json")
    candidate = candidate_path.read_bytes()
    operation, content = verified_bytes(candidate, entry["response"]["sha256"])
    parsed = json.loads(content)
    if parsed["model_returned"] != entry["model_returned"] or parsed["status"] != "completed":
        raise ValueError("Model identity or completion status mismatch")
    if len(parsed["response"]) != entry["response"]["response_characters"]:
        raise ValueError("Response length mismatch")
    outdir = ROOT / "analysis/raw_v1/verified"
    outdir.mkdir(parents=True, exist_ok=True)
    output = outdir / candidate_path.name
    if output.exists():
        if output.read_bytes() != content:
            raise ValueError("Refuse to overwrite a different archived file")
    else:
        output.write_bytes(content)
    if hashlib.sha256(output.read_bytes()).hexdigest() != entry["response"]["sha256"]:
        raise ValueError("Post-write verification failed")
    report = {
        "model": args.model,
        "source_path": entry["response"]["path"],
        "registered_sha256": entry["response"]["sha256"],
        "candidate_path": candidate_path.relative_to(ROOT).as_posix(),
        "candidate_sha256": hashlib.sha256(candidate).hexdigest(),
        "transport": "OOD editor select-all/copy; text transcribed through apply_patch",
        "transport_normalization": operation,
        "verified_path": output.relative_to(ROOT).as_posix(),
        "verified_bytes": len(content),
        "response_characters": len(parsed["response"]),
        "response_id": parsed["response_id"],
        "source_registry_sha256": hashlib.sha256(registry_path.read_bytes()).hexdigest(),
        "claim": "Exact match to previously registered remote-file hash; not a new independent remote hash measurement"
    }
    (outdir / (args.model + ".transfer.json")).write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
