"""Select only completed alpha batches; reparse force logs and verify their hashes."""
import hashlib
import json
from avl_aircraft_pilot import ROOT
from avl_reference_gate import parse
from avl_fixed_control_slope import slopes


def check_condition(raw, alpha, control):
    # Force files print angles and commands to five decimals.
    for key,expected in [('Alpha',alpha),('pitch',control),('Beta',0),('Mach',0)]:
        if abs(parse(raw,key)-expected)>5.01e-6:
            raise ValueError('Unexpected reported condition: '+key)


def main():
    chosen=[('astra',8,'01'),('astra',12,'04'),('opus',8,'03'),('opus',12,'06')]
    records=[]
    for model,nc,attempt in chosen:
        base=ROOT/f'analysis/results/avl_fixed_control_slope{attempt}'
        source=base/'summary.json'
        summary=json.loads(source.read_text())
        row,=[r for r in summary['records'] if r['model']==model and r['nc']==nc]
        for name,key in [('trim_control_grid_v1.json','source_sha256'),('longitudinal_geometry_v1.json','moment_input_sha256')]:
            if hashlib.sha256((ROOT/'analysis/results'/name).read_bytes()).hexdigest()!=summary[key]:
                raise ValueError('Changed source: '+name)
        work=base/f"{model}_c{nc}_s{row['ns']}"
        if (work/'timeout.txt').exists(): raise ValueError('Timed-out batch cannot be selected')
        for name,key in [('aircraft.avl','geometry_sha256'),('section.dat','foil_sha256')]:
            if hashlib.sha256((work/name).read_bytes()).hexdigest()!=row[key]:
                raise ValueError('Changed case input: '+name)
        values={}
        for i,a in enumerate([3.5,3.75,4.0,4.25,4.5]):
            path=work/f'forces_{i}.txt'
            if hashlib.sha256(path.read_bytes()).hexdigest()!=row['force_sha256'][path.name]:
                raise ValueError('Force-file hash mismatch')
            raw=path.read_text()
            check_condition(raw,a,row['frozen_candidate']['control_deg'])
            values[str(a)]={k:parse(raw,k) for k in ['CLtot','CDind','Cmtot']}
        if values!=row['values']: raise ValueError('Summary does not match raw force files')
        for h,key in [(.5,'slope_per_degree_h0_5'),(.25,'slope_per_degree_h0_25')]:
            if slopes(values,h)!=row[key]: raise ValueError('Derivative mismatch')
        records.append({'selected_directory':str(work.relative_to(ROOT)),
                        'summary_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),**row})
    comparisons=[]
    for model in ['astra','opus']:
        coarse,fine=[r for r in records if r['model']==model]
        c,f=coarse['slope_per_degree_h0_25'],fine['slope_per_degree_h0_25']
        comparisons.append({'model':model,'fine_minus_coarse_slope_per_degree':{k:f[k]-c[k] for k in c},
                            'fine_Cm_alpha_step_change_per_degree':f['Cmtot']-fine['slope_per_degree_h0_5']['Cmtot']})
    output={'scope':'Unvalidated fixed-control local aerodynamic slope; no dynamic or flight verdict',
            'completed_selected_cases':20,'records':records,'comparisons':comparisons}
    (ROOT/'analysis/results/fixed_control_slope_selected_v1.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(comparisons,indent=2))


if __name__=='__main__': main()
