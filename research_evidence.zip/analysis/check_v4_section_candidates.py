"""Evaluator transcription of reviewed V4 formulas, NOT raw response archives.

Never executes model-provided expressions. Samples are for geometric inspection,
not approved XFOIL/polar inputs (panel adequacy and LE treatment remain open).
"""
import json
import math
from pathlib import Path
from validate_propeller_sections import validate_section

ROOT = Path(__file__).resolve().parents[1]


def main():
    out = ROOT/'analysis/results/v4_geometry_check01'
    out.mkdir(exist_ok=False)
    xs = [(1-math.cos(math.pi*i/200))/2 for i in range(201)]
    records = []
    upper = [[0,0],[.1,.045],[.3,.06],[.6,.035],[1,0]]
    records.append(dict(model='gpt-6-astra',section='symmetric_PL_t012',
                        **validate_section(upper, [[x,-y] for x,y in upper])))
    for model, thicknesses in [('claude-fable-5-1',[.30,.20,.15,.12,.11,.10,.09,.08]),
                              ('claude-opus-5-5',[.30,.18,.13,.10,.09,.08,.07,.06])]:
        for t in thicknesses:
            if 'fable' in model:
                upper = [[x,4*(.06+t/2)*x*(1-x)] for x in xs]
                lower = [[x,4*(.06-t/2)*x*(1-x)] for x in xs]
            else:
                upper = [[x,10*t*(.2969*math.sqrt(x)-.126*x-.3516*x*x+.2843*x**3-.1036*x**4)] for x in xs]
                lower = [[x,0] for x in xs]
            report = validate_section(upper, lower)
            report.update(model=model, thickness_parameter=t,
                          thickness_parameter_error=report['thickness_ratio']-t)
            records.append(report)
    # Exact maximum interpolation error for Fable's quadratic upper surface.
    x41 = [(1-math.cos(math.pi*i/40))/2 for i in range(41)]
    fable_root_error41 = .84*max((b-a)**2 for a,b in zip(x41,x41[1:]))/4
    result = dict(provenance='Manually reviewed formulas from Unity job 64958422; raw archives remain remote.',
                  records=records, fable_root_upper_41_point_max_linear_error_c=fable_root_error41,
                  fable_claim_less_than_1e4_c_at_41_points_supported=fable_root_error41 < 1e-4,
                  status='GEOMETRY_SCREEN_ONLY_NOT_AERODYNAMIC_ACCEPTANCE')
    with (out/'summary.json').open('x') as stream:
        json.dump(result, stream, indent=2)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
