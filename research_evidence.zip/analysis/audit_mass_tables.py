"""Recompute newly transcribed leaf rows, retaining source precision choices."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def summarize(data):
    rows=data['parts']
    if len({r['id'] for r in rows}) != len(rows):
        raise ValueError('Duplicate counted row')
    mass=sum(r['m'] for r in rows)
    sums=[sum(r['m']*r['cg'][i] for r in rows) for i in range(3)]
    return {'mass_kg':mass,'moments_kg_m':sums,'cg_original_axes_m':[v/mass for v in sums]}


def main():
    results={}
    registry=json.loads((ROOT/'paper/baselines/baseline_registry_v1.json').read_text(encoding='utf-8'))
    for name in ('astra','fable','opus'):
        path=ROOT/f'analysis/{name}_v1_extracted.json'
        raw=path.read_bytes()
        data=json.loads(raw)
        row=summarize(data)
        ledger=next(m['audited_nominal_mass_ledger'] for m in registry['models'] if m['baseline_id']==data['baseline_id'])
        row['difference_from_registered_moments_kg_m']=[row['moments_kg_m'][i]-ledger[f'sum_m{a}_kg_m'] for i,a in enumerate('xyz')]
        row['extracted_input_sha256']=hashlib.sha256(raw).hexdigest()
        if name=='opus':
            row['S1_extra_precision_delta_moment_x_kg_m']=8*(1.25625-1.256)
            row['interpretation']='Registered x moment uses detailed S1 precision, while this extraction retains displayed frozen row. Difference is precision, not a new design.'
        results[data['baseline_id']]=row
    (ROOT/'analysis/results/mass_table_audit_v1.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(results,indent=2))


if __name__=='__main__':
    main()
