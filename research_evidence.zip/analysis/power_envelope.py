"""Conditional power budget; never invents an available engine for Fable."""
import hashlib
import json
import math
from pathlib import Path
from audit_mass_tables import summarize

ROOT=Path(__file__).resolve().parents[1]
G=9.80665


def shaft_power_required(mass, speed, ld, prop_eta, drive_eta=1):
    if mass<=0 or speed<=0 or ld<=0 or not 0<prop_eta<=1 or not 0<drive_eta<=1:
        raise ValueError('Invalid physical input')
    return mass*G*speed/(ld*prop_eta*drive_eta)


def point(mass,speed,ld,eta,power,drive_eta=1):
    required=shaft_power_required(mass,speed,ld,eta,drive_eta)
    out={'speed_m_s':speed,'ld':ld,'propeller_efficiency':eta,'drivetrain_efficiency':drive_eta,
         'drag_N':mass*G/ld,'required_engine_shaft_power_W':required,
         'target_power_W':power,'conditional_shaft_margin_W':None,
         'conditional_climb_power_equivalent_m_s':None,'conditional_power_budget_nonnegative':None}
    if power is not None:
        out['conditional_shaft_margin_W']=power-required
        out['conditional_climb_power_equivalent_m_s']=(power*eta*drive_eta-mass*G*speed/ld)/(mass*G)
        out['conditional_power_budget_nonnegative']=power>=required
    return out


def run():
    path=ROOT/'analysis/power_scenarios_v1.json'
    raw=path.read_bytes()
    scenarios=json.loads(raw)
    output={'input_sha256':hashlib.sha256(raw).hexdigest(),'scope':scenarios['status'],'cases':[]}
    for case in scenarios['cases']:
        model_path=ROOT/f'analysis/{case["model"]}_v1_extracted.json'
        model_raw=model_path.read_bytes()
        mass=summarize(json.loads(model_raw))['mass_kg']
        p=case['target_engine_shaft_power_W']
        nominal=point(mass,case['speed_m_s'],case['lift_drag_ratio'],case['propeller_efficiency'],p)
        result={'id':case['id'],'mass_kg':mass,'mass_input_sha256':hashlib.sha256(model_raw).hexdigest(),'nominal':nominal}
        if 'constant_CL_alternate' in case:
            a=case['constant_CL_alternate']
            speed=math.sqrt(2*mass*G/(a['rho_kg_m3']*a['S_m2']*a['CL']))
            result['constant_CL_alternate']=point(mass,speed,case['lift_drag_ratio'],case['propeller_efficiency'],p)
        result['sensitivity']=[]
        grid=scenarios['sensitivity_grid']
        for ld in grid['lift_drag_ratios']:
            for eta in grid['propeller_efficiencies']:
                for drive in grid['drivetrain_efficiencies']:
                    result['sensitivity'].append(point(mass,case['speed_m_s'],ld,eta,p,drive))
        output['cases'].append(result)
    return output


def main():
    result=run()
    (ROOT/'analysis/results/power_envelope_v1.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({c['id']:{k:v for k,v in c.items() if k!='sensitivity'} for c in result['cases']},indent=2))


if __name__=='__main__':
    main()
