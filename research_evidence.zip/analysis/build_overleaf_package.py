"""Export this manuscript's explicit Markdown subset to a private LaTeX ZIP.

No network/upload/compiler invocation. Static checks are not compilation.
Original source, equations and figures remain unchanged.
"""
from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "paper/manuscript_draft_v1.md"
DEST = ROOT / "output/overleaf/aircraft_overleaf_v2"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def inline(source, cite=True, depth=0):
    saved = []
    def store(value):
        saved.append(value)
        return f"ZZTOKENDEPTH{depth}ITEM{len(saved)-1}ZZ"
    source = re.sub(r"\\\((.*?)\\\)", lambda m: store(r"\(" + m[1] + r"\)"), source)
    source = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", lambda m: store(r"\href{"+m[2].replace("%", r"\%")+"}{"+inline(m[1], False, depth+1)+"}") if m[2].startswith("https://") else m[1], source)
    source = re.sub(r"https://[^\s]+", lambda m: store(r"\url{"+m[0]+"}"), source)
    if cite:
        source = re.sub(r"\[([1-7])\]", lambda m: store(r"\cite{ref"+m[1]+"}"), source)
    source = re.sub(r"\*\*(.*?)\*\*", lambda m: store(r"\textbf{"+inline(m[1], cite, depth+1)+"}"), source)
    source = re.sub(r"\*([^*]+)\*", lambda m: store(r"\emph{"+inline(m[1], cite, depth+1)+"}"), source)
    source = source.replace("10⁻⁸", store(r"\(10^{-8}\)"))
    chars = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}", "°": r"\ensuremath{^{\circ}}", "±": r"\ensuremath{\pm}", "²": r"\ensuremath{^{2}}", "³": r"\ensuremath{^{3}}", "·": r"\ensuremath{\cdot}", "×": r"\ensuremath{\times}", "–": "--", "−": r"\ensuremath{-}", "≤": r"\ensuremath{\leq}"}
    source = "".join(chars.get(c, c) for c in source)
    for number in reversed(range(len(saved))):
        source = source.replace(f"ZZTOKENDEPTH{depth}ITEM{number}ZZ", saved[number])
    source.encode("ascii")
    return source


def export():
    if DEST.exists():
        raise FileExistsError(f"Preserve existing export: {DEST}")
    lines = SOURCE.read_text(encoding="utf-8").splitlines()
    output, refs, figures = [], [], []
    counts = {"tables": 0, "figures": 0, "equations": 0, "references": 0}
    i, reference_mode, table_caption = 0, False, None
    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            continue
        if line.startswith("# "):
            title = inline(line[2:])
            i += 1
        elif line.startswith("## ") or line.startswith("### "):
            heading = line.lstrip("# ")
            reference_mode = heading == "References"
            if reference_mode:
                output.append(r"\input{references.tex}")
            else:
                command = "subsection" if line.startswith("### ") else "section"
                output.append("\\"+command+"*{"+inline(heading)+"}")
            i += 1
        elif reference_mode:
            match = re.fullmatch(r"\[(\d+)\] (.+)", line)
            if not match:
                raise ValueError(f"Unrecognized reference: {line}")
            refs.append(r"\bibitem{ref"+match[1]+"} "+inline(match[2], False))
            counts["references"] += 1
            i += 1
        elif line == r"\[":
            block = [line]
            i += 1
            while i < len(lines) and lines[i].strip() != r"\]":
                block.append(lines[i])
                i += 1
            assert i < len(lines)
            block.append(r"\]")
            equation = "\n".join(block)
            assert re.search(r"\\tag\{"+str(counts["equations"]+1)+r"\}", equation)
            output.append(equation)
            counts["equations"] += 1
            i += 1
        elif line.startswith("**Table "):
            match = re.fullmatch(r"\*\*Table (\d+)\. (.+)\*\*", line)
            assert match
            table_caption = (int(match[1]), match[2])
            i += 1
        elif line.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                row = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-+:?", c) for c in row):
                    rows.append(row)
                i += 1
            n = len(rows[0])
            assert all(len(row) == n for row in rows)
            if table_caption:
                assert table_caption[0] == counts["tables"]
            block = [r"\begin{table}[H]", r"\centering\small"]
            if table_caption:
                block.append(r"\caption{"+inline(table_caption[1])+"}")
            ratios = {3: [0.23, 0.24, 0.53], 4: [0.23, 0.23, 0.23, 0.31], 5: [0.15, 0.16, 0.17, 0.22, 0.30], 6: [0.15, 0.13, 0.08, 0.08, 0.43, 0.13]}[n]
            if counts["tables"] == 0:
                ratios = [0.25, 0.59, 0.16]
            spec = "".join(r">{\hsize="+str(round(r*n, 5))+r"\hsize\raggedright\arraybackslash}X" for r in ratios)
            block += [r"\begin{tabularx}{\linewidth}{"+spec+"}", r"\toprule"]
            for row_number, row in enumerate(rows):
                cells = [inline(c) for c in row]
                if row_number == 0:
                    cells = [r"\textbf{"+c+"}" for c in cells]
                block.append(" & ".join(cells)+r" \\")
                if row_number == 0:
                    block.append(r"\midrule")
            block += [r"\bottomrule", r"\end{tabularx}", r"\end{table}"]
            output.append("\n".join(block))
            counts["tables"] += 1
            table_caption = None
        elif line.startswith("!["):
            match = re.fullmatch(r"!\[[^\]]*\]\(([^)]+)\)", line)
            path = (SOURCE.parent / match[1]).resolve()
            figures.append(path)
            i += 1
            while not lines[i].strip():
                i += 1
            caption = lines[i].strip()
            number = counts["figures"] + 1
            assert caption.startswith(f"**Figure {number}. ")
            # Preserve bold caption scope while allowing LaTeX to number it.
            caption = caption.replace(f"**Figure {number}. ", "**", 1)
            output.append("\n".join([r"\begin{figure}[H]", r"\centering", r"\includegraphics[width=\linewidth]{figures/"+path.name+"}", r"\caption{"+inline(caption)+"}", r"\end{figure}"]))
            counts["figures"] += 1
            i += 1
        else:
            parts = [line]
            i += 1
            while i < len(lines) and lines[i].strip():
                parts.append(lines[i].strip())
                i += 1
            output.append(inline(" ".join(parts)))
    assert counts == {"tables": 6, "figures": 2, "equations": 6, "references": 7}, counts
    preamble = r"""% Private review draft, not an official Journal of Aircraft template.
% Overleaf: main document = main.tex; compiler = pdfLaTeX.
\documentclass[11pt,a4paper]{article}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{lmodern}
\usepackage[margin=22mm]{geometry}
\usepackage{amsmath,amssymb}
\usepackage{graphicx,booktabs,tabularx,array,float}
\usepackage{microtype}
\usepackage{setspace}
\usepackage[hidelinks]{hyperref}
\usepackage{url}
\setlength{\emergencystretch}{3em}
\setlength{\tabcolsep}{4pt}
\renewcommand{\arraystretch}{1.2}
\setstretch{1.15}
\title{TITLE}
\author{} % Human author: add only the author's confirmed publication name.
\date{Private working draft -- 26 September 2026}
\begin{document}
\maketitle
\noindent\textit{Not submission-ready. Exact author name and affiliation await confirmation. Supporting local-record links are retained in article-source.md and the separate research archive.}

""".replace("TITLE", title)
    main = preamble + "\n\n".join(output) + "\n\n\\end{document}\n"
    bibliography = "\\begin{thebibliography}{9}\n"+"\n\n".join(refs)+"\n\\end{thebibliography}\n"
    # Basic static integrity; intentionally not a claim of successful compilation.
    for tex in [main, bibliography]:
        stack = []
        for m in re.finditer(r"\\(begin|end)\{([^}]+)\}", tex):
            if m[1] == "begin":
                stack.append(m[2])
            else:
                assert stack and stack.pop() == m[2]
        assert not stack
        assert "ZZTOKEN" not in tex
        tex.encode("ascii")
    assert set(re.findall(r"\\cite\{(ref\d+)\}", main)) == {f"ref{n}" for n in range(1, 8)}
    DEST.mkdir(parents=True)
    (DEST / "figures").mkdir()
    (DEST / "main.tex").write_text(main, encoding="ascii")
    (DEST / "references.tex").write_text(bibliography, encoding="ascii")
    shutil.copy2(SOURCE, DEST / "article-source.md")
    for path in figures:
        shutil.copy2(path, DEST / "figures" / path.name)
    readme = """# Aircraft manuscript: Overleaf source package

This ZIP is a LaTeX manuscript project, NOT the earlier aircraft_local_review_v1 research archive.

1. In Overleaf use New Project > Upload Project and select aircraft_overleaf_v2.zip.
2. Select main.tex as the main document and pdfLaTeX as compiler.
3. Recompile. No BibTeX, shell escape, external script, API key or absolute local path is required.

Compilation status: NOT COMPILED in the local environment. No TeX engine was found on PATH. Static checks passed; only an actual compile can establish successful PDF production and layout. Do not confuse the separately generated ReportLab review PDF with a LaTeX compilation result.

The full working manuscript is converted with six source equations, five numbered tables plus nomenclature, two figure PNGs and seven references in references.tex. article-source.md preserves the exact source. Local record links become visible text labels because their targets belong to the separate research archive. HTTPS bibliography links remain links. The figures are the existing high-resolution PNGs, not new scientific results.

This is a generic article review layout, not a certified AIAA/Journal of Aircraft submission template. The exact author name and affiliation remain pending; AI is not an author. Physical validation remains unresolved. No upload, publication, journal submission or external sharing was performed by the generator. Source documents and solver binaries are deliberately absent.

Official Overleaf instructions: https://docs.overleaf.com/managing-projects-and-files/uploading-a-project
Main-document setting: https://docs.overleaf.com/getting-started/recompiling-your-project/the-main-document
"""
    (DEST / "README.md").write_text(readme, encoding="utf-8")
    records = {str(p.relative_to(DEST)).replace("\\", "/"): sha(p.read_bytes()) for p in sorted(DEST.rglob("*")) if p.is_file()}
    manifest = {"source_sha256": sha(SOURCE.read_bytes()), "counts": counts, "compiled": False, "static_checks": "counts, environment nesting, citation keys, ASCII TeX, asset presence and archive byte identity", "files": records}
    (DEST / "MANIFEST.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")
    archive = DEST.parent / "aircraft_overleaf_v2.zip"
    with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted(DEST.rglob("*")):
            if path.is_file():
                bundle.write(path, str(path.relative_to(DEST)))
    with zipfile.ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert "main.tex" in bundle.namelist()
        assert len(bundle.namelist()) == len(set(bundle.namelist())) == len(records)+1
        for name, digest in records.items():
            assert sha(bundle.read(name)) == digest
    print(json.dumps({"archive": str(archive), "sha256": sha(archive.read_bytes()), "bytes": archive.stat().st_size, "counts": counts, "compiled": False}, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    export()
