"""Fixed-alpha, bounded-control conditional level trim; not a flight envelope.

Interpolate ONLY computed control samples. Added drag and its moment are
researcher scenarios, not measurements, estimates, or uncertainty bounds.
"""
import hashlib
import json
import math
from pathlib import Path
from audit_mass_tables import summarize

ROOT = Path(__file__).resolve().parents[1]
LABELS = [('minus',-1),('half_minus',-.5),('zero',0),('half_plus',.5),('plus',1)]


def interpolate(values, delta, labels=LABELS):
    if not labels[0][1] <= delta <= labels[-1][1]:
        raise ValueError('Control extrapolation forbidden')
    for (left,a),(right,b) in zip(labels,labels[1:]):
        if a <= delta <= b:
            t = (delta-a)/(b-a)
            return {k:values[left][k]*(1-t)+values[right][k]*t for k in ['CLtot','CDind','Cmtot']}
    raise ValueError('No bracketing control samples')


def solve(values, mass, area, chord, thrust_arm, added_cd, drag_arm, alpha_deg=4, rho=1.225, labels=LABELS):
    alpha = math.radians(alpha_deg)
    def moment_coefficient(delta):
        aero = interpolate(values,delta,labels)
        cd = aero['CDind']+added_cd
        return aero['Cmtot']+thrust_arm*cd/(chord*math.cos(alpha))+drag_arm*added_cd/chord
    roots = []
    for (_,lo),(_,hi) in zip(labels,labels[1:]):
        flo,fhi = moment_coefficient(lo),moment_coefficient(hi)
        if flo*fhi > 0:
            continue
        if flo == 0:
            delta = lo
        elif fhi == 0:
            delta = hi
        else:
            for _ in range(60):
                mid = (lo+hi)/2
                fm = moment_coefficient(mid)
                if flo*fm <= 0:
                    hi = mid
                else:
                    lo,flo = mid,fm
            delta = (lo+hi)/2
        if any(abs(delta-r['control_deg']) < 1e-8 for r in roots):
            continue
        aero = interpolate(values,delta,labels)
        cd = aero['CDind']+added_cd
        # Wind-axis level balance: T cos(alpha)=D; L+T sin(alpha)=W.
        denominator = aero['CLtot']+cd*math.tan(alpha)
        if denominator <= 0 or cd < 0:
            continue
        weight = mass*9.80665
        q = weight/(area*denominator)
        velocity = math.sqrt(2*q/rho)
        lift,drag = q*area*aero['CLtot'],q*area*cd
        thrust = drag/math.cos(alpha)
        moment = q*area*chord*aero['Cmtot']+thrust_arm*thrust+drag_arm*q*area*added_cd
        roots.append({'control_deg':delta,'speed_m_s':velocity,'thrust_N':thrust,
                      'CL':aero['CLtot'],'CD_total_scenario':cd,'Cm_aero':aero['Cmtot'],
                      'useful_propulsive_power_W':drag*velocity,
                      'residuals':{'horizontal_N':thrust*math.cos(alpha)-drag,
                                   'vertical_N':lift+thrust*math.sin(alpha)-weight,'pitch_Nm':moment}})
    return roots


def main():
    paths = [ROOT/'analysis/results/avl_control_probe02/summary.json',
             ROOT/'analysis/results/avl_control_probe03/summary.json',
             ROOT/'analysis/results/longitudinal_geometry_v1.json',ROOT/'analysis/power_scenarios_v1.json']
    probes = json.loads(paths[0].read_text())['records']+json.loads(paths[1].read_text())['records']
    assert [p['model'] for p in probes] == ['astra','fable','opus']
    moments = json.loads(paths[2].read_text())
    power = {p['model']:p for p in json.loads(paths[3].read_text())['cases']}
    rows = []
    for probe in probes:
        name = probe['model']
        attempt = '02' if name=='astra' else '03'
        geom = ROOT/f'analysis/results/avl_control_probe{attempt}/{name}/aircraft.avl'
        assert hashlib.sha256(geom.read_bytes()).hexdigest() == probe['geometry_sha256']
        area,chord,_ = map(float,geom.read_text().splitlines()[3].split())
        masspath = ROOT/f'analysis/{name}_v1_extracted.json'
        mass = summarize(json.loads(masspath.read_text(encoding='utf-8')))['mass_kg']
        paths.extend([geom,masspath])
        arm = moments[name.upper()+'-V1']['pitch_coefficient_per_N_forward_thrust']
        for cd in [0,.05,.10,.20]:
            for drag_arm in [-.5,0,.5]:
                roots = solve(probe['values'],mass,area,chord,arm,cd,drag_arm)
                for root in roots:
                    eta = power[name]['propeller_efficiency']
                    root['shaft_power_W_assuming_source_eta_and_lossless_drive'] = root['useful_propulsive_power_W']/eta
                    target = power[name]['target_engine_shaft_power_W']
                    root['margin_to_unverified_target_W'] = None if target is None else target-root['shaft_power_W_assuming_source_eta_and_lossless_drive']
                rows.append({'model':name,'added_CD':cd,'effective_added_drag_pitch_arm_m':drag_arm,
                             'status':'conditional_interpolated_candidate' if roots else 'no_root_in_tested_control_interval',
                             'candidates':roots})
    output = {'scope':'Fixed alpha 4 deg; control [-1,+1] deg only; unvalidated aero and hypothetical missing-drag closure',
              'assumptions':{'rho_kg_m3':1.225,'added_CD':[0,.05,.10,.20],'added_drag_moment_arm_m':[-.5,0,.5],
                             'drag_grid_meaning':'Illustrative probes, not physical uncertainty limits; zero added drag is a deliberately incomplete diagnostic',
                             'efficiency_definition':'Useful power along flight velocity / shaft power; source eta reapplied as hypothesis',
                             'omitted':'slipstream, installed thrust curve, clearance, hinge loads, Reynolds effects, deformation, structural strength, dynamics'},
              'input_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'cases':rows}
    (ROOT/'analysis/results/conditional_trim_v1.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    for row in rows:
        if row['effective_added_drag_pitch_arm_m']==0:
            print(json.dumps(row))


if __name__ == '__main__':
    main()
