#!/usr/bin/env python3
"""Reconcile existing four-aircraft evidence without new aerodynamic runs.

V1 aircraft screening is the common 12 m/s comparison. Later trim and propeller
revisions are separate evidence and never silently replace a frozen design.
"""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCREEN=ROOT/'analysis/results/screening_v1.json'
WRIGHT=ROOT/'analysis/results/wright_screening_v1.json'
RETRIM=ROOT/'analysis/results/retrim_v2_attempt01/summary.json'
FAMILY=ROOT/'analysis/results/wright_family_comparison_v1.json'
FABLE_PROP=ROOT/'analysis/results/fable_rpm_power_envelope01.json'
CONTROL_GRID=ROOT/'analysis/results/avl_control_grid01/summary.json'
FOURWAY=ROOT/'analysis/results/four_aircraft_comparison01/summary.json'
OUT=ROOT/'analysis/results/minimum_four_aircraft_gate01.json'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def main():
    screen=read(SCREEN)
    wright=read(WRIGHT)
    retrim=read(RETRIM)
    family=read(FAMILY)
    fable_prop=read(FABLE_PROP)
    control_grid=read(CONTROL_GRID)
    fourway=read(FOURWAY)
    labels={'ASTRA-V1':'Astra V1','FABLE-V1':'Fable V1','OPUS-V1':'Opus V1'}
    cases=[]
    for item in screen['models']:
        cases.append({'design':labels[item['id']],'version':'V1 frozen',
                      'mass_kg':item['mass_kg'],'area_m2':item['reference_area_m2'],
                      'CL_required_12_m_s_no_vertical_thrust':item['required_CL']['12'],
                      'common_speed_lift_result':'NOT_EVALUATED_AT_MATCHED_TRIM',
                      'common_speed_total_drag':'UNKNOWN',
                      'common_speed_installed_thrust':'UNKNOWN',
                      'common_speed_pitch_trim':'UNKNOWN'})
    cases.append({'design':'1903 Wright Flyer','version':'provisional historical statistics',
                  'mass_kg':wright['nominal_mass_kg'],
                  'area_m2':wright['nominal_wing_area_m2'],
                  'CL_required_12_m_s_no_vertical_thrust':wright['CL_required_at_12_m_s_assumed_density'],
                  'common_speed_lift_result':'UNMATCHED_RECONSTRUCTION_ONLY',
                  'common_speed_total_drag':'UNKNOWN',
                  'common_speed_installed_thrust':'UNKNOWN',
                  'common_speed_pitch_trim':'UNKNOWN'})
    q=.5*screen['density_kg_m3']*12**2
    for case in cases:
        expected=case['mass_kg']*screen['gravity_m_s2']/(q*case['area_m2'])
        if abs(expected-case['CL_required_12_m_s_no_vertical_thrust'])>1e-10:
            raise ValueError(f"Common-condition lift-demand mismatch: {case['design']}")
    neutral_rows=[]
    for case in cases[:3]:
        key=case['design'].split()[0].lower()
        matching=[r for r in control_grid['rows'] if r['model']==key and r['alpha_deg']==4]
        if len(matching)!=1:
            raise ValueError(f'Missing common neutral angle for {key}')
        coeff=matching[0]['values']['0']
        lift=q*case['area_m2']*coeff['CLtot']
        neutral_rows.append({'design':case['design'],'configuration':'V1 neutral, alpha=4 deg, coarse AVL',
                             'CL':coeff['CLtot'],'Cm_about_source_reference':coeff['Cmtot'],
                             'CD_induced_only':coeff['CDind'],'lift_N':lift,
                             'lift_minus_weight_N':lift-case['mass_kg']*screen['gravity_m_s2'],
                             'total_drag_available':False,'powered_trim_test':False})
    wright_cases=[r for r in fourway['wright']['fine_proxy_results'] if r['canard_proxy']=='flat']
    if len(wright_cases)!=1:
        raise ValueError('Expected one Wright flat-canard proxy result')
    wr=next(r for r in wright_cases[0]['loads'] if r['alpha_deg']==4)
    neutral_rows.append({'design':'1903 Wright Flyer researcher reconstruction',
                         'configuration':'flat-canard proxy, alpha=4 deg, fine AVL; not matched as-tested geometry',
                         'lift_N':wr['lift_N'],'lift_minus_weight_N':wr['lift_minus_weight_N_no_vertical_thrust'],
                         'total_drag_available':False,'powered_trim_test':False})
    versions=[c['version'] for c in cases]
    if versions!=['V1 frozen']*3+['provisional historical statistics']:
        raise ValueError('Primary comparison version drift')
    refinement=family['refinement']
    if len(refinement)!=4:
        raise ValueError('Expected four matched Wright coarse/fine pairs')
    max_cl=max(abs(r['percent_of_absolute_base']['CLtot']) for r in refinement)
    max_cdi=max(abs(r['percent_of_absolute_base']['CDind']) for r in refinement)
    max_cm=max(abs(r['absolute']['Cmtot']) for r in refinement)
    trim_evidence={}
    for item in retrim['records']:
        name=item['model']
        if name not in ('astra','opus'):
            raise ValueError('Unexpected retrim identity')
        trim_evidence[name]={'version':'V1 frozen, native-speed conditional fine-grid retrim',
                             'source':'analysis/results/retrim_v2_attempt01/summary.json',
                             'not_common_12_m_s':True,
                             'not_physical_flight_validation':True}
    if len(trim_evidence)!=2:
        raise ValueError('Missing Astra/Opus retrim evidence')
    if fable_prop['conditions']['blades_per_propeller']!=2:
        raise ValueError('Fable proposal count changed')
    result={'stage':'minimum_no_CFD_four_aircraft_gate',
            'input_sha256':{str(p.relative_to(ROOT)).replace('\\','/'):digest(p)
                            for p in (SCREEN,WRIGHT,RETRIM,FAMILY,FABLE_PROP,CONTROL_GRID,FOURWAY)},
            'common_condition':{'V_m_s':12,'density_kg_m3':1.225,
                                'vertical_thrust_assumed_zero_for_CL_demand':True},
            'primary_cases':cases,
            'same_speed_same_alpha_untrimmed_diagnostic':neutral_rows,
            'separate_native_condition_evidence':trim_evidence,
            'fable_later_propeller_revision':{'version':'V3b/V5 propeller proposal on V2 aircraft',
                                             'not_a_V1_or_full_aircraft_flight_result':True},
            'wright_reference_check':{'coarse_fine_pairs':len(refinement),
                                      'max_abs_CL_percent_change':max_cl,
                                      'max_abs_induced_CD_percent_change':max_cdi,
                                      'max_abs_Cm_change':max_cm,
                                      'only_two_meshes_no_asymptotic_convergence_order':True,
                                      'as_tested_geometry_and_condition_matched':False,
                                      'historical_CG_established':False,
                                      'experimental_validation_passed':False},
            'four_way_flyability_ranking_supported':False,
            'CFD_planned':False}
    OUT.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'cases':len(cases),'wright_mesh_pairs':len(refinement),
                      'max_abs_CL_percent_change':max_cl,
                      'max_abs_induced_CD_percent_change':max_cdi,
                      'max_abs_Cm_change':max_cm}))


if __name__=='__main__':
    main()
