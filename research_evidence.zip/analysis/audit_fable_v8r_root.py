#!/usr/bin/env python3
"""Audit the unadopted V8-R root numerical screen against its frozen inputs."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
INPUT=ROOT/'analysis/results/fable_v8r_root_inputs01/manifest.json'
RESULTS=ROOT/'analysis/results/fable_v8r_root_attempt01'
ARCHIVE=ROOT/'analysis/results/fable_v8r_root_results_64968721.tar.gz'
OUT=ROOT/'analysis/results/fable_v8r_root_audit01.json'
ARCHIVE_SHA='0b42e3eb271b61aad1dd191ee2d14da55c61724ebda0ec0c1d246d30f0ee813e'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    if sha(ARCHIVE)!=ARCHIVE_SHA:
        raise ValueError('Downloaded archive does not match Unity hash')
    manifest=json.loads(INPUT.read_text())
    summary=json.loads((RESULTS/'summary.json').read_text())
    records=json.loads((RESULTS/'records.json').read_text())
    if manifest['stage']!='fable_v8r_root_numerical_screen' or summary['cases']!=15 or len(records)!=15:
        raise ValueError('Unexpected dataset')
    filehash={s['file']:s['sha256'] for s in manifest['sections']}
    for record in records:
        if record['geometry_sha256']!=filehash[record['geometry_file']]:
            raise ValueError('Geometry provenance mismatch')
    grid=[]
    for angle in manifest['angles_deg']:
        group=[r for r in records if r['alpha_deg']==angle]
        if len(group)!=3:
            raise ValueError('Missing contour density')
        values={field:[r['reader']['coefficients'][field] for r in group]
                for field in ('CL','CD','CM') if all(r['status']=='NUMERICAL_SCREEN' for r in group)}
        row={'alpha_deg':angle,'statuses':{r['geometry_file'].split('_n')[-1].split('.')[0]:r['status'] for r in group}}
        if values:
            row['coefficients']={field:{r['geometry_file'].split('_n')[-1].split('.')[0]:r['reader']['coefficients'][field]
                                        for r in group} for field in values}
            row['spreads']={field:{'absolute':max(v)-min(v),
                                   'relative_to_mean':(max(v)-min(v))/(sum(v)/len(v)) if sum(v) else None}
                            for field,v in values.items()}
        grid.append(row)
    report={'job_id':'64968721','input_manifest_sha256':sha(INPUT),
            'result_archive_sha256':ARCHIVE_SHA,'case_count':len(records),
            'numerical_screen_count':summary['numerically_screened'],
            'operating_incidence_deg':manifest['station']['geometric_incidence_no_induction_deg'],
            'bracket_degrees':[4,5],
            'two_or_more_grids_each_side':all(sum(r['status']=='NUMERICAL_SCREEN' for r in records
                                               if r['alpha_deg']==a)>=2 for a in (4,5)),
            'grid':grid,'aerodynamic_validation':False,
            'propeller_performance_calculated':False,
            'structural_validation':False}
    OUT.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'screens':report['numerical_screen_count'],
                      'two_grid_bracket':report['two_or_more_grids_each_side'],
                      'four_deg_CL_spread':grid[1]['spreads']['CL'],
                      'five_deg_CL_spread':grid[2]['spreads']['CL']}))

if __name__=='__main__':
    main()
