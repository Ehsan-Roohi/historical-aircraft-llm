"""Postprocess existing reference artifacts without rerunning or overwriting them."""
import argparse
import hashlib
import json
from pathlib import Path
from xfoil_verified_reader import read_case


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--project',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    root=args.project/'reference_recheck_v4_attempt01'
    binary=args.project/'xfoil-build-v2-64871593/Xfoil/bin/xfoil'
    digest=hashlib.sha256(binary.read_bytes()).hexdigest()
    rows=json.loads((root/'raw_manifest.json').read_bytes())
    results=[]
    for row in rows:
        case=root/row['case']
        result=read_case((case/'polar.txt').read_text(),(case/'solver.log').read_text(),
                         binary_sha256=digest,expected_alpha=row['alpha'],returncode=row['returncode'])
        result.update(case=row['case'],polar_sha256=hashlib.sha256((case/'polar.txt').read_bytes()).hexdigest(),
                      log_sha256=hashlib.sha256((case/'solver.log').read_bytes()).hexdigest())
        results.append(result)
    summary=dict(cases=len(results),numerical_pass=sum(r['numerical_screen'] for r in results),
                 internal_CDp_disagreements=sum(r['internal_pressure_drag_discrepancy'] for r in results),
                 aerodynamic_acceptance=False,reader_sha256=hashlib.sha256(Path(__file__).with_name('xfoil_verified_reader.py').read_bytes()).hexdigest())
    with args.output.open('x') as stream:
        json.dump(dict(summary=summary,records=results),stream,indent=2)
    print(json.dumps(summary))
    for r in results:
        print(r['case'],r['numerical_screen'],r['final_iteration_pressure_drag_assignments'])


if __name__=='__main__':
    main()
