"""Plot matched-case coefficient differences; no experimental validation claim."""
import hashlib
import json
from html import escape
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output/figures'
FILES = ('wright_family_comparison_v1.json', 'wright_reconstruction_audit_v1.json',
         'wright_reconstruction_incidence_audit_v1.json')
W, H = 900, 540
SCALE = 180 / 25.4 * 300 / W


def load_rows():
    paths = [ROOT/'analysis/results'/name for name in FILES]
    comparison, base, alternative = [json.loads(p.read_bytes()) for p in paths]
    base = {r['case']: r for r in base['records']}
    alternate = {r['case']: r for r in alternative['records']}
    fine = {r['case']: r for r in comparison['fine_selected_cases']}
    rows = []
    refinements = {r['case']:r for r in comparison['refinement']}
    installations = {r['case']:r for r in comparison['installation']['comparisons']}
    assert set(refinements) == set(installations) == set(fine) == set(alternate)
    for case in ('flat_i+0_a0','flat_i+0_a4','eiffel10_raw_i+0_a0','eiffel10_raw_i+0_a4'):
        row = {'case':case, 'alpha_deg':base[case]['alpha_deg'],
               'section':base[case]['canard_section'], 'mesh':{}, 'installation':{}}
        for coefficient in ('CLtot','Cmtot'):
            for key, result, recorded in (
                ('mesh', fine, refinements), ('installation', alternate, installations)):
                delta = result[case]['coefficients'][coefficient]-base[case]['coefficients'][coefficient]
                assert abs(delta-recorded[case]['absolute'][coefficient]) < 1e-12
                row[key][coefficient] = delta
        rows.append(row)
    return rows, comparison['installation'], {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}


def main():
    rows, installation, hashes = load_rows()
    OUT.mkdir(parents=True, exist_ok=True)
    image = Image.new('RGB',(round(W*SCALE),round(H*SCALE)),'white')
    draw = ImageDraw.Draw(image)
    svg = [f'<svg xmlns="http://www.w3.org/2000/svg" width="180mm" height="108mm" viewBox="0 0 {W} {H}">',
           '<title>Wright reconstruction sensitivity: mesh and installation</title>',
           '<desc>Absolute changes in lift and pitch-moment coefficients for four matched conditions. Two distinct perturbations, not error bars or experimental residuals.</desc>',
           '<rect width="900" height="540" fill="white"/>']

    def text(x,y,value,size=18,bold=False,anchor='start'):
        font=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf' if bold else 'C:/Windows/Fonts/arial.ttf',round(size*SCALE))
        width=draw.textlength(value,font=font)
        left=x*SCALE-({'start':0,'middle':.5,'end':1}[anchor])*width
        assert left >= 0 and left+width <= W*SCALE, value
        draw.text((left,y*SCALE),value,font=font,fill='#222222',anchor='lt')
        svg.append(f'<text x="{x}" y="{y+size*.8}" text-anchor="{anchor}" font-family="Arial, Helvetica, sans-serif" font-size="{size}" font-weight="{700 if bold else 400}">{escape(value)}</text>')

    def line(x1,y1,x2,y2,color='#dce0e4',width=1):
        draw.line((x1*SCALE,y1*SCALE,x2*SCALE,y2*SCALE),fill=color,width=max(1,round(width*SCALE)))
        svg.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="{width}"/>')

    def marker(x,y,kind):
        color='#0072b2' if kind=='mesh' else '#a94f00'
        box=((x-5)*SCALE,(y-5)*SCALE,(x+5)*SCALE,(y+5)*SCALE)
        if kind=='mesh':
            draw.ellipse(box,fill=color)
            svg.append(f'<circle cx="{x}" cy="{y}" r="5" fill="{color}"/>')
        else:
            draw.rectangle(box,fill=color)
            svg.append(f'<rect x="{x-5}" y="{y-5}" width="10" height="10" fill="{color}"/>')

    text(26,20,'Wright reconstruction: sensitivity to two choices',25,True)
    text(26,58,'Coefficient changes relative to the same coarse-grid baseline',18)
    marker(39,102,'mesh'); text(54,93,'Mesh',18)
    marker(162,102,'installation'); text(177,93,'Installation',18)
    text(869,93,'Canard incidence fixed at 0°',17,anchor='end')
    panels = [(218,490,'CLtot',-.01,.06,[-.01,0,.02,.04,.06],'(a) Lift: ΔCL'),
              (590,862,'Cmtot',-.002,.008,[-.002,0,.002,.004,.006,.008],'(b) Pitch moment: ΔCm')]
    text(26,142,'Canard / α',17,True)
    for left,right,coefficient,lo,hi,ticks,title in panels:
        text(left,142,title,20,True)
        def xpos(value):
            assert lo-1e-12 <= value <= hi+1e-12
            return left+(right-left)*(value-lo)/(hi-lo)
        for tick in ticks:
            x=xpos(tick)
            line(x,180,x,398,'#7d858c' if tick==0 else '#dce0e4',1.2 if tick==0 else .7)
            label='0' if tick==0 else (f'{tick:.2f}' if coefficient=='CLtot' else f'{tick:.3f}')
            text(x,412,label,17,anchor='middle')
        line(left,398,right,398,'#555555')
        for i,row in enumerate(rows):
            y=199+58*i
            line(left,y,right,y,'#edf0f2',.6)
            marker(xpos(row['mesh'][coefficient]),y-7,'mesh')
            marker(xpos(row['installation'][coefficient]),y+7,'installation')
            if left==218:
                section='Flat' if row['section']=='flat' else 'Eiffel 10 proxy'
                text(26,y-8,f"{section}, {row['alpha_deg']}°",18)
    text(26,460,'Installation: main-wing incidence 3.417° → 4.248°; mesh unchanged.',18)
    text(26,493,'Sensitivity comparisons, not uncertainty bounds or historical validation.',18,True)
    svg.append('</svg>')
    (OUT/'wright_sensitivity_v1.svg').write_text('\n'.join(svg),encoding='utf-8')
    image.save(OUT/'wright_sensitivity_v1.png',dpi=(300,300))
    image.resize((W,H),Image.Resampling.LANCZOS).save(OUT/'wright_sensitivity_v1_preview.png')
    manifest={'input_sha256':hashes,'rows':rows,'main_incidence_deg':{
        'base':installation['base_main_incidence_deg'],'alternative':installation['alternative_main_incidence_deg']},
        'difference_checks':16,'print_mm':[180,108],'minimum_font_pt':17*.2*72/25.4,
        'font':'Arial; SVG fallback Helvetica, sans-serif; not embedded',
        'scope':'Matched numerical perturbations, not physical validation or statistical bounds.'}
    (OUT/'wright_sensitivity_v1_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print('Verified 16 coefficient differences; generated SVG, PNG, preview and manifest.')


if __name__=='__main__':
    main()
