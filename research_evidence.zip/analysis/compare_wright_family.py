"""Keep numerical refinement and assumed installation changes as separate comparisons."""
import json
from collect_wright_family import collect
from wright_reconstruction_family import ROOT, SIDE, sha


def difference(base, changed):
    keys = ['CLtot','CDind','Cmtot']
    return {'absolute':{k:changed[k]-base[k] for k in keys},
            'percent_of_absolute_base':{k:100*(changed[k]-base[k])/abs(base[k]) if base[k] else None for k in keys}}


def main():
    folders = {n:ROOT/f'analysis/results/wright_reconstruction_family{n:02d}' for n in [2,3,4,5]}
    audits = {n:collect(p) for n,p in folders.items()}
    for n in [2,4,5]:
        if not audits[n]['all_cases_verified']: raise ValueError('Required run incomplete')
    models = {n:json.loads((p/'definition.json').read_bytes()) for n,p in folders.items()}
    if not models[2] == models[3] == models[4]: raise ValueError('Refinement geometry changed')
    side = json.loads(SIDE.read_bytes())
    if abs(models[5]['main_incidence_deg']-side['selected_main_chord_angle_deg']) > 1e-12:
        raise ValueError('Alternative incidence differs from selected side-view angle')
    if models[2]['main_incidence_deg'] != 3+25/60: raise ValueError('Baseline incidence changed')
    for key in models[2]:
        if key not in ['main_incidence_deg','assumptions'] and models[2][key] != models[5][key]:
            raise ValueError('Installation comparison changes another field: '+key)
    fine = audits[3]['records']+audits[4]['records']
    if len(fine)!=4 or len({r['case'] for r in fine})!=4: raise ValueError('Fine selection incomplete/duplicate')
    # The retries must reproduce all three solver-input files byte for byte.
    retries = []
    for r in audits[4]['records']:
        old,new = folders[3]/r['case'],folders[4]/r['case']
        matches = {f:sha(old/f)==sha(new/f) for f in ['wing.avl','commands.txt','section.dat']}
        if not all(matches.values()): raise ValueError('Retry inputs changed')
        retries.append({'case':r['case'],'identical_input_files':matches})
    coarse = {r['case']:r for r in audits[2]['records']}
    refinement = [{'case':r['case'],**difference(coarse[r['case']]['coefficients'],r['coefficients'])} for r in fine]
    installation = [{'case':r['case'],**difference(coarse[r['case']]['coefficients'],r['coefficients'])} for r in audits[5]['records']]
    result = {
        'scope':__doc__,
        'input_summary_sha256':{str(n):a['summary_sha256'] for n,a in audits.items()},
        'selected_solver_output_count':sum(a['verified_count'] for a in audits.values()),
        'fine_selected_cases':fine,'retry_input_identity':retries,
        'refinement':refinement,
        'installation':{'base_main_incidence_deg':models[2]['main_incidence_deg'],
                        'alternative_main_incidence_deg':models[5]['main_incidence_deg'],
                        'difference_deg':models[5]['main_incidence_deg']-models[2]['main_incidence_deg'],
                        'source_side_summary_sha256':sha(SIDE),'comparisons':installation},
        'limits':['No empirical accuracy threshold or convergence order from two grids',
                  'Installation alternatives are not statistical uncertainty bounds',
                  'The raster chord angle is not proved equivalent to AVL incidence or Run 33 attitude',
                  'No matched validation, complete trim, total drag, stability or flight verdict',
                  'Failed/timeout attempts retained; not included as force results']}
    (ROOT/'analysis/results/wright_family_comparison_v1.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__ == '__main__': main()
