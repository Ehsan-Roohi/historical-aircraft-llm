"""Conditional point-centroid inertia contributions, NOT complete aircraft inertia."""
import hashlib
import json
import math
from copy import deepcopy
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tensor(rows, origin=None):
    if not rows or len({r['id'] for r in rows})!=len(rows):
        raise ValueError('Empty or duplicate row set')
    for r in rows:
        if len(r['cg'])!=3 or not all(math.isfinite(v) for v in [r['m'],*r['cg']]) or r['m']<=0:
            raise ValueError('Invalid mass/centroid')
    mass = sum(r['m'] for r in rows)
    cg = [sum(r['m']*r['cg'][i] for r in rows)/mass for i in range(3)]
    center = cg if origin is None else origin
    if len(center)!=3 or not all(math.isfinite(v) for v in center):
        raise ValueError('Invalid origin')
    matrix = [[0.0]*3 for _ in range(3)]
    for r in rows:
        d = [r['cg'][i]-center[i] for i in range(3)]
        norm2 = sum(v*v for v in d)
        for i in range(3):
            for j in range(3):
                matrix[i][j] += r['m']*((norm2 if i==j else 0)-d[i]*d[j])
    return {'mass_kg':mass,'cg_m':cg,'origin_m':center,'tensor_kg_m2':matrix,
            'diagonal_kg_m2':{axis:matrix[i][i] for i,axis in enumerate(['Ixx','Iyy','Izz'])}}


def body_rows(data):
    # Conventional right-handed body directions; origin remains the source origin.
    if data['axes']['y']!='right' or data['axes']['z']!='up' or data['axes']['x'] not in ['forward','aft']:
        raise ValueError('Unknown source axes')
    signs = [1 if data['axes']['x']=='forward' else -1,1,-1]
    return [{'id':r['id'],'m':r['m'],'cg':[signs[i]*r['cg'][i] for i in range(3)]} for r in data['parts']]


def split_fable_tips(rows):
    result = deepcopy(rows)
    tip = next(r for r in result if r['id']=='P03')
    if tip['m']!=6 or tip['cg']!=[-1.83,0,-1.91]:
        raise ValueError('Unexpected transformed P03')
    result.remove(tip)
    for suffix,y in [('L',-5),('R',5)]:
        result.append({'id':'P03_'+suffix,'m':3,'cg':[-1.83,y,-1.91]})
    return result


def main():
    models = [('astra','gpt-6-astra'),('fable','claude-fable-5-1'),('opus','claude-opus-5-5')]
    records = []
    for name,model in models:
        source = ROOT/f'analysis/{name}_v1_extracted.json'
        raw = ROOT/f'analysis/raw_v1/verified/{model}.json'
        verification = ROOT/f'analysis/results/{name}_raw_extraction_check_v1.json'
        data,checked = json.loads(source.read_bytes()),json.loads(verification.read_bytes())
        # Require the already reproduced full raw-table comparison for these exact bytes.
        if sha(raw)!=data['source']['registered_sha256'] or checked['raw_sha256']!=sha(raw):
            raise ValueError('Raw source hash mismatch')
        if checked['extraction_sha256']!=sha(source) or not checked['all_rows_equal']:
            raise ValueError('Extraction verification does not cover current input')
        rows = body_rows(data)
        result = tensor(rows)
        record = {'model':name,'baseline_id':data['baseline_id'],'extraction_sha256':sha(source),
                  'raw_sha256':sha(raw),'verification_sha256':sha(verification),'row_count':len(rows),
                  'aggregate_row_centroids':result,'intrinsic_component_inertias':'unknown; not set to zero as a physical claim'}
        if name=='fable':
            text = json.loads(raw.read_bytes())['response']
            line = next(l for l in text.splitlines() if l.startswith('| P03 |'))
            if 'Tip panels ×2' not in line or 'each (1.83, ±5.00, 1.91)' not in line:
                raise ValueError('Missing explicit member centroid evidence')
            refined = tensor(split_fable_tips(rows))
            record['P03_member_resolved'] = refined
            record['P03_added_tensor_kg_m2'] = [[refined['tensor_kg_m2'][i][j]-result['tensor_kg_m2'][i][j] for j in range(3)] for i in range(3)]
            record['qualification'] = 'P07 centroid outside stated box remains unresolved; all values conditional on frozen ledger. Other aggregate rows remain lumped.'
        if name=='opus':
            alternate = deepcopy(rows)
            next(r for r in alternate if r['id']=='S1')['cg'][0] = -data['alternate_source_precision']['S1_x_m']
            record['alternate_S1_precision'] = tensor(alternate)
            record['qualification'] = 'Main result uses displayed S1 centroid; alternate precision separated. All row y coordinates are zero, not proof that the wings have zero spanwise inertia.'
        records.append(record)
    output = {'scope':__doc__,'axes':'x forward, y right, z down; tensor about computed CG',
              'off_diagonal_convention':'Matrix entry Iij=-sum(m*di*dj) for i!=j; products defined as +sum(m*di*dj) have the opposite sign and can themselves be positive or negative',
              'equation':'I_true = sum(I_component_about_own_CG_in_common_axes) + sum(m*(dot(d,d)*identity - outer(d,d)))',
              'bound':'For physically valid declared masses and centroids, the omitted intrinsic tensor is positive semidefinite; each scalar-axis inertia is at least its centroid contribution. This is not an elementwise bound on off-diagonal entries.',
              'theory_source':'https://ocw.mit.edu/courses/16-07-dynamics-fall-2009/dd277ec654440f4c2b5b07d6c286c3fd_MIT16_07F09_Lec26.pdf',
              'records':records,
              'not_established':['True mass distributions or measured inertias','Intrinsic component tensors','Dynamic eigenvalues or damping','Physical trim or pilot controllability','Structural margins','Flight capability or comparative superiority']}
    (ROOT/'analysis/results/inertia_bookkeeping_v1.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(output,indent=2))


if __name__=='__main__': main()
