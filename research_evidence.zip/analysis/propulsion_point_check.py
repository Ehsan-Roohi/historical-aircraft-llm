"""Power/torque/disk and radial inflow checks, not a validated propeller model."""
import math

def check(T,V,alpha,D,count,rpm,engine_rpm,eta,drive,target,stations):
    if min(T,V,D,count,rpm,engine_rpm,target)<=0 or not 0<eta<=1 or not 0<drive<=1:
        raise ValueError('Invalid operating point')
    if any(b[0]<=a[0] for a,b in zip(stations,stations[1:])):
        raise ValueError('Radial stations must increase')
    omega=2*math.pi*rpm/60
    va=V*math.cos(math.radians(alpha));area=count*math.pi*D**2/4
    vi=(math.sqrt(va**2+2*T/(1.225*area))-va)/2
    useful=T*va;prop=useful/eta;engine=prop/drive
    return dict(axial_V_m_s=va,induced_V_ideal_m_s=vi,ideal_disk_minimum_W=T*(va+vi),
      useful_W=useful,propeller_shaft_W_total=prop,engine_W=engine,
      prop_torque_Nm_each=prop/(count*omega),engine_torque_Nm=engine/(2*math.pi*engine_rpm/60),
      speed_ratio=engine_rpm/rpm,advance_ratio=va/(rpm/60*D),
      tip_helical_mach=math.hypot(omega*D/2,va)/340,
      required_eta_prop_at_target=useful/(target*drive),
      required_eta_prop_25pct_demand=1.25*useful/(target*drive),
      engine_W_25pct_demand=1.25*engine,unverified_target_W=target,
      target_margin_W=target-engine,stress_target_margin_W=target-1.25*engine,
      radial_checks=[dict(r_m=r,chord_m=c,beta_deg=b,
                         alpha_geometric_ideal_inflow_deg=b-math.degrees(math.atan2(va+vi,omega*r)),
                         Reynolds_assumed_mu_1p81e5=1.225*math.hypot(omega*r,va+vi)*c/1.81e-5)
                     for r,c,b in stations],
      qualification='No polar, swirl, root/tip loss or installation model; radial angles and Re only, NOT thrust predicted from blade geometry.')
