"""Typeset the complete working manuscript for private review, not submission.

Uses ReportLab and installed Times New Roman. Source Markdown remains editable.
Equation renderings are explicit, guarded by the expected source expressions.
No analysis, network, solver, or model API calls are made.
"""
from pathlib import Path
import hashlib
import html
import json
import re

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, KeepTogether,
)
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "paper/manuscript_draft_v1.md"
OUT = ROOT / "output/pdf"

EQUATIONS = [
    (r"q=\tfrac12\rho V^2,\qquad W=mg,\qquad L=qSC_L,\qquad D=qS(C_{D,i}+\Delta C_D)",
     "q = ½ρV<super>2</super>,   W = mg,   L = qSC<sub>L</sub>,   D = qS(C<sub>D,i</sub> + ΔC<sub>D</sub>)"),
    (r"T\cos\alpha-D=0,\qquad L+T\sin\alpha-W=0",
     "T cos α - D = 0,   L + T sin α - W = 0"),
    (r"qScC_m+a_TT+a_DqS\Delta C_D=0",
     "qScC<sub>m</sub> + a<sub>T</sub>T + a<sub>D</sub>qSΔC<sub>D</sub> = 0"),
    (r"f(\delta)=C_m(\delta)+\frac{a_T[C_{D,i}(\delta)+\Delta C_D]}{c\cos\alpha} +\frac{a_D\Delta C_D}{c}=0",
     "f(δ) = C<sub>m</sub>(δ) + a<sub>T</sub>[C<sub>D,i</sub>(δ) + ΔC<sub>D</sub>]/(c cos α) + a<sub>D</sub>ΔC<sub>D</sub>/c = 0"),
    (r"q=\frac{W}{S[C_L+(C_{D,i}+\Delta C_D)\tan\alpha]},\quad V=\sqrt{\frac{2q}{\rho}},\quad T=\frac{qS(C_{D,i}+\Delta C_D)}{\cos\alpha}",
     "q = W/{S[C<sub>L</sub> + (C<sub>D,i</sub> + ΔC<sub>D</sub>) tan α]},<br/>V = √(2q/ρ),   T = qS(C<sub>D,i</sub> + ΔC<sub>D</sub>)/cos α"),
    (r"P_{\rm useful}=TV\cos\alpha=DV,\qquad P_{\rm shaft}=\frac{DV}{\eta}",
     "P<sub>useful</sub> = TV cos α = DV,   P<sub>shaft</sub> = DV/η"),
]

INLINE_MATH = {
    r"S,c,b": "S, c, b", r"m,W,g": "m, W, g", r"\rho,V,q": "ρ, V, q",
    r"L,D,T": "L, D, T", r"C_L,C_{D,i},C_m": "C<sub>L</sub>, C<sub>D,i</sub>, C<sub>m</sub>",
    r"\Delta C_D": "ΔC<sub>D</sub>", r"\alpha,\delta": "α, δ",
    r"a_T,a_D": "a<sub>T</sub>, a<sub>D</sub>",
    r"\eta,P_{\rm shaft}": "η, P<sub>shaft</sub>",
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalized_equation(value):
    return re.sub(r"\s+", "", value)


def inline(text):
    # Typography-only replacements; negative signs remain negative signs.
    text = text.replace("−", "-").replace("–", "-").replace("—", " - ").replace("‑", "-")
    text = html.escape(text)
    def math_replace(match):
        if match[1] not in INLINE_MATH:
            raise ValueError(f"Unmapped inline math: {match[1]}")
        return INLINE_MATH[match[1]]
    text = re.sub(r"\\\((.*?)\\\)", math_replace, text)
    def link(match):
        label, target = match.groups()
        return f'<a href="{target}" color="#234e70">{label}</a>' if target.startswith("https://") else label
    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", link, text)
    text = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)
    text = re.sub(r"\*([^*]+)\*", r"<i>\1</i>", text)
    if "\\" in text:
        raise ValueError(f"Unrendered source markup: {text}")
    return text


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    font_paths = {"Review": "times.ttf", "Review-Bold": "timesbd.ttf", "Review-Italic": "timesi.ttf", "Review-BoldItalic": "timesbi.ttf"}
    for name, filename in font_paths.items():
        pdfmetrics.registerFont(TTFont(name, str(Path("C:/Windows/Fonts") / filename)))
    pdfmetrics.registerFontFamily("Review", normal="Review", bold="Review-Bold", italic="Review-Italic", boldItalic="Review-BoldItalic")
    body = ParagraphStyle("Body", fontName="Review", fontSize=10.5, leading=15,
                          alignment=TA_JUSTIFY, spaceAfter=7, allowWidows=0, allowOrphans=0)
    styles = {
        "body": body,
        "title": ParagraphStyle("Title", parent=body, fontName="Review-Bold", fontSize=18, leading=22, alignment=TA_CENTER, spaceAfter=15),
        "h2": ParagraphStyle("H2", parent=body, fontName="Review-Bold", fontSize=12.5, leading=16, spaceBefore=12, spaceAfter=7, keepWithNext=True),
        "h3": ParagraphStyle("H3", parent=body, fontName="Review-Bold", fontSize=11, leading=14, spaceBefore=9, spaceAfter=5, keepWithNext=True),
        "cell": ParagraphStyle("Cell", parent=body, fontSize=9, leading=11, alignment=0, spaceAfter=0),
        "caption": ParagraphStyle("Caption", parent=body, fontSize=9.5, leading=12, alignment=0, spaceAfter=8),
        "equation": ParagraphStyle("Equation", parent=body, fontSize=11, leading=18, alignment=TA_CENTER, spaceAfter=0),
        "note": ParagraphStyle("Note", parent=body, fontSize=9, leading=12, alignment=0, textColor=colors.HexColor("#444444")),
    }
    width = A4[0] - 80
    pdf_path = OUT / "aircraft_manuscript_review_v1.pdf"
    doc = SimpleDocTemplate(str(pdf_path), pagesize=A4, leftMargin=40, rightMargin=40,
                            topMargin=44, bottomMargin=43, title="Engineering Assessment of Three Language-Model Aircraft Designs Against the Wright Flyer",
                            author="", subject="Private working draft; authorship details pending", invariant=1)
    lines = SOURCE.read_text(encoding="utf-8").splitlines()
    story, assets, counts = [], [], {"paragraphs": 0, "tables": 0, "figures": 0, "equations": 0}
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            continue
        if line.startswith("# "):
            story.append(Paragraph(inline(line[2:]), styles["title"]))
            story.append(Paragraph("PRIVATE REVIEW DRAFT | 26 September 2026<br/>Not submission-ready. Publication name and affiliation await author confirmation.<br/>Full text retained from the working Markdown. Supporting local-record links remain in that source; this PDF is not a standalone data package.", styles["note"]))
            story.append(Spacer(1, 10))
            i += 1
        elif line.startswith("## ") or line.startswith("### "):
            level = "h3" if line.startswith("### ") else "h2"
            story.append(Paragraph(inline(line.lstrip("# ")), styles[level]))
            i += 1
        elif line == r"\[":
            block = []
            i += 1
            while i < len(lines) and lines[i].strip() != r"\]":
                block.append(lines[i].strip())
                i += 1
            if i == len(lines):
                raise ValueError("Unclosed equation")
            expr = " ".join(block)
            tag = re.search(r"\\tag\{(\d+)\}", expr)
            if tag is None:
                raise ValueError("Untagged equation")
            number = int(tag[1])
            expected, rendered = EQUATIONS[number - 1]
            assert normalized_equation(expr[:tag.start()]) == normalized_equation(expected), number
            row = Table([[Paragraph(rendered, styles["equation"]), Paragraph(f"({number})", styles["cell"])]], colWidths=[width - 26, 26])
            row.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 9)]))
            story.append(row)
            counts["equations"] += 1
            i += 1
        elif line.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-+:?", c) for c in cells):
                    rows.append(cells)
                i += 1
            columns = len(rows[0])
            assert all(len(r) == columns for r in rows)
            ratios = {3: [0.23, 0.24, 0.53], 4: [0.23, 0.23, 0.23, 0.31], 5: [0.15, 0.16, 0.17, 0.22, 0.30], 6: [0.15, 0.13, 0.08, 0.08, 0.43, 0.13]}[columns]
            if counts["tables"] == 0:
                ratios = [0.25, 0.59, 0.16]
            table = Table([[Paragraph(("<b>" if j == 0 else "") + inline(c) + ("</b>" if j == 0 else ""), styles["cell"]) for c in row] for j, row in enumerate(rows)], colWidths=[width * r for r in ratios], repeatRows=1, hAlign="LEFT")
            table.setStyle(TableStyle([("LINEABOVE", (0, 0), (-1, 0), 0.7, colors.black), ("LINEBELOW", (0, 0), (-1, 0), 0.4, colors.black), ("LINEBELOW", (0, -1), (-1, -1), 0.7, colors.black), ("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5), ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
            story.extend([table, Spacer(1, 9)])
            counts["tables"] += 1
        elif line.startswith("!["):
            target = re.fullmatch(r"!\[[^\]]*\]\(([^)]+)\)", line)[1]
            path = (SOURCE.parent / target).resolve()
            from PIL import Image as PILImage
            with PILImage.open(path) as im:
                w, h = im.size
            figure = Image(str(path), width=width, height=width*h/w)
            assets.append({"path": str(path.relative_to(ROOT)), "sha256": digest(path), "pixels": [w, h], "effective_dpi": w/(width/72)})
            i += 1
            while i < len(lines) and not lines[i].strip():
                i += 1
            assert lines[i].startswith("**Figure ")
            caption = Paragraph(inline(lines[i]), styles["caption"])
            story.append(KeepTogether([figure, Spacer(1, 5), caption]))
            counts["figures"] += 1
            i += 1
        else:
            parts = [line]
            i += 1
            while i < len(lines) and lines[i].strip():
                parts.append(lines[i].strip())
                i += 1
            content = " ".join(parts)
            style = styles["caption"] if content.startswith("**Table ") else body
            para = Paragraph(inline(content), style)
            if content.startswith("**Table "):
                para.keepWithNext = True
            story.append(para)
            counts["paragraphs"] += 1
    assert counts["equations"] == 6 and counts["tables"] == 6 and counts["figures"] == 2
    def footer(canvas, document):
        canvas.saveState()
        canvas.setFont("Review", 8)
        canvas.setFillColor(colors.HexColor("#555555"))
        canvas.drawString(40, 25, "Private working draft - no flight validation or superiority claim")
        canvas.drawRightString(A4[0]-40, 25, str(document.page))
        canvas.restoreState()
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    reader = PdfReader(pdf_path)
    extracted = "\n".join(p.extract_text() or "" for p in reader.pages)
    for anchor in ["Table 1.", "Table 5.", "Figure 1.", "Figure 2.", "[7] Krus", "918.138", "0.6187"]:
        assert anchor in extracted, anchor
    manifest = {"scope": "Complete manuscript private review typesetting, not final journal formatting or new engineering evidence", "source_sha256": digest(SOURCE), "pdf_sha256": digest(pdf_path), "pages": len(reader.pages), "counts": counts, "figure_assets": assets, "font_sha256": {filename: digest(Path("C:/Windows/Fonts")/filename) for filename in font_paths.values()}, "equation_source_guards": "Six exact normalized TeX expressions matched explicit typesetting definitions", "visual_review": "Pending page rasterization and inspection", "author": "Human project owner; exact publication name/affiliation pending; no AI author"}
    (OUT / "aircraft_manuscript_review_v1_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"pdf": str(pdf_path), "pages": len(reader.pages), "counts": counts}, indent=2))


if __name__ == "__main__":
    main()
