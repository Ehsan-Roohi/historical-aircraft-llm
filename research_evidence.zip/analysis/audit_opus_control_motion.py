"""Rigid planar motion audit; not a complete interference or structural check."""
import hashlib
import json
import math
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def trailing_edge(xh,zh,chord,source_te_up_deg):
    angle=math.radians(source_te_up_deg)
    return [xh+chord*math.cos(angle),zh+chord*math.sin(angle)]


def main():
    path=ROOT/'analysis/opus_control_geometry_v1.json'
    data=json.loads(path.read_text())
    e,r=data['elevator'],data['rudder']
    endpoints={str(a):trailing_edge(e['hinge_x_m'],e['hinge_z_m'],e['chord_m'],a) for a in e['source_travel_deg']}
    rudder_y=r['chord_m']*math.sin(math.radians(max(abs(a) for a in r['travel_deg'])))
    output={'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'source_angle_trailing_edge_x_z_m':endpoints,
            'rudder_planar_max_abs_y_m':rudder_y,
            'elevator_cutout_minus_rudder_planar_sweep_m':e['center_cutout_halfwidth_m']-rudder_y,
            'nominal_area_m2':4.4*1.1+2*(e['outer_halfspan_m']-e['center_cutout_halfwidth_m'])*e['chord_m'],
            'source_to_AVL_sign':-1,
            'interpretation':'Planar swept surfaces have lateral separation at stated travels; no hardware/finite-thickness/elastic clearance claim'}
    (ROOT/'analysis/results/opus_control_motion_v1.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(output,indent=2))


if __name__=='__main__':
    main()
