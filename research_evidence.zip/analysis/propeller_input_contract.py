"""Fail-closed provenance audit, not a propulsion or installed-frame validator."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODELS = {'gpt-6-astra': 'astra', 'claude-fable-5-1': 'fable', 'claude-opus-5-5': 'opus'}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(inputs, baselines):
    inputs, baselines = Path(inputs), Path(baselines)
    manifest = json.loads((inputs/'manifest.json').read_bytes())
    context = json.loads((inputs/'baseline_context.json').read_bytes())
    errors = []
    files = set()
    counts = dict.fromkeys(('astra', 'fable', 'opus'), 0)
    for row in manifest['sections']:
        name = row['file']
        if Path(name).name != name or name in files:
            errors.append(f'Unsafe or duplicate filename: {name}')
            continue
        files.add(name)
        path = inputs/name
        if not path.is_file() or digest(path) != row['sha256']:
            errors.append(f'Section hash mismatch or missing: {name}')
        if row['family'] not in counts:
            errors.append(f'Unknown family: {name}')
        else:
            counts[row['family']] += 1
        if row['status'] != 'CANDIDATE_INPUT_NOT_POLAR':
            errors.append(f'Unexpected section status: {name}')
    if counts != {'astra': 2, 'fable': 16, 'opus': 16}:
        errors.append(f'Incomplete section inventory: {counts}')
    if {p.name for p in inputs.glob('*.dat')} != files:
        errors.append('Manifest/directory section inventory mismatch')
    seen = set()
    for entry in context:
        model = entry['model']
        if model not in MODELS or model in seen:
            errors.append(f'Unknown or duplicate context: {model}')
            continue
        seen.add(model)
        path = baselines/(model+'.design.json')
        if not path.is_file() or digest(path) != entry['baseline_sha256']:
            errors.append(f'Baseline hash mismatch or missing: {model}')
            continue
        original = json.loads(path.read_bytes())
        for key in ('coordinate_convention', 'propulsion'):
            if entry[key] != original[key]:
                errors.append(f'Context differs from hashed baseline: {model}/{key}')
    if seen != set(MODELS):
        errors.append('Incomplete baseline context')
    return {
        'integrity_pass': not errors, 'errors': errors, 'section_files': len(files),
        'manifest_sha256': digest(inputs/'manifest.json'),
        'context_sha256': digest(inputs/'baseline_context.json'),
        'isolated_section_input_provenance_ready': not errors,
        'solver_validated': False, 'installed_assembly_ready': False,
        'performance_validated': False,
        'frames': {
            'astra': {'native_axes': 'forward/right/up', 'handedness': 'left',
                      'blades': 2, 'blade_count_source': 'V2',
                      'gate': 'Explicit V4 local blade basis and transform to native aircraft absent.'},
            'fable': {'native_axes': 'aft/right/up', 'handedness': 'right',
                      'blades': 2, 'blade_count_source': 'V3b proposal; V2 remains UNKNOWN',
                      'gate': 'V4 forward +x contradicts baseline; opposite-hand assembly unresolved.'},
            'opus': {'native_axes': 'aft/starboard/up', 'handedness': 'right',
                     'blades': 2, 'blade_count_source': 'V2',
                     'gate': 'V4 changed camber is candidate only; signed installed blade mapping needs verification.'}
        },
        'limitations': ['Hash equality proves consistency with local records, not authenticity of model responses.',
                        'No frame transforms inferred or applied; no aerodynamic or engine acceptance.',
                        'Fable V3b blade-count provenance is documented transcription, not verified raw archive here.']
    }


if __name__ == '__main__':
    result = audit(ROOT/'analysis/results/v4_section_inputs01', ROOT/'analysis/results/received_v2_audit01')
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result['integrity_pass'] else 1)
