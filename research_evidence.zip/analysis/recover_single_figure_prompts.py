"""Audit single-figure request provenance without executing any generation code."""
import ast
import json
from pathlib import Path
from recover_original_prompts import digest

ROOT = Path(__file__).resolve().parents[1]


def expression(node, values):
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.Name) and node.id in values:
        return values[node.id]
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        return expression(node.left, values) + expression(node.right, values)
    if isinstance(node, ast.IfExp):
        test = node.test
        if (isinstance(test, ast.Compare) and isinstance(test.left, ast.Attribute)
                and isinstance(test.left.value, ast.Name) and test.left.value.id == 'a'
                and test.left.attr == 'view' and len(test.ops) == 1
                and isinstance(test.ops[0], ast.Eq) and len(test.comparators) == 1):
            branch = node.body if values['view'] == expression(test.comparators[0], values) else node.orelse
            return expression(branch, values)
    raise ValueError('Unsupported prompt expression; generation code will not be executed')


def compose(script, view, article):
    if view not in ('three_view', 'oblique'):
        raise ValueError('Unknown view')
    values = {'view': view, 'article': article}
    for name in ('form', 'prompt'):
        nodes = [n.value for n in ast.parse(script).body if isinstance(n, ast.Assign)
                 and any(isinstance(t, ast.Name) and t.id == name for t in n.targets)]
        if len(nodes) != 1:
            raise ValueError('Missing or duplicate ' + name)
        values[name] = expression(nodes[0], values)
    return values['prompt'].encode('utf-8')


def main():
    folder = ROOT / 'analysis/prompts_v0'
    driver = (folder / 'blind_single_figure.observed.py').read_bytes()
    observed = folder / 'single_figure_metadata_observed.json'
    records = json.loads(observed.read_bytes())['records']
    for record in records:
        record['evidence_kind'] = 'remote_metadata_transcription_response_body_not_archived_here'
    raw_path = ROOT / 'received_2026-09-24/astra_fable_opus_designs/claude-fable-5-1/oblique_original_response.jsonl'
    raw_bytes = raw_path.read_bytes()
    for line in raw_bytes.decode('utf-8').splitlines():
        record = json.loads(line)
        record.pop('response', None)
        record['evidence_kind'] = 'locally_archived_full_jsonl'
        records.append(record)
    instructions = (folder / 'instructions.txt').read_bytes()
    results = []
    for record in records:
        model, view = record['model_requested'], record['stage']
        article = (ROOT / 'received_2026-09-24/astra_fable_opus_designs' / model / 'article.md').read_bytes()
        if digest(article) != record['article_sha256'] or digest(instructions) != record['instruction_sha256']:
            raise ValueError('Article or instructions mismatch')
        candidate = compose(driver.decode('utf-8'), view, article.decode('utf-8'))
        matches = digest(candidate) == record['prompt_sha256']
        name = model + '.' + view + '.single.prompt.txt'
        if matches:
            target = folder / name
            if target.exists() and target.read_bytes() != candidate:
                raise ValueError('Refusing to replace different verified text')
            if not target.exists():
                target.write_bytes(candidate)
        results.append({'model': model, 'view': view, 'response_id': record['response_id'],
                        'response_status': record['status'], 'stop_reason': record.get('stop_reason'),
                        'generated_utc': record['generated_utc'], 'evidence_kind': record['evidence_kind'],
                        'recorded_prompt_sha256': record['prompt_sha256'],
                        'current_driver_candidate_sha256': digest(candidate),
                        'exact_prompt_recovered': matches, 'verified_prompt_file': name if matches else None})
    result = {'scope': 'Request-text audit only, not geometric conformity or full raw-response archive',
              'observed_driver_sha256': digest(driver), 'metadata_file_sha256': digest(observed.read_bytes()),
              'fable_oblique_raw_jsonl_sha256': digest(raw_bytes), 'records': results,
              'unmatched_policy': 'Retain recorded hash and mark unresolved; never substitute current code for historical prompt'}
    (folder / 'single_figure_audit.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
