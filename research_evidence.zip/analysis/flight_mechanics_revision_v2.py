"""Read-only reanalysis of archived AVL results; no API, solver or remote job.

Only writes the new flight_mechanics_revision_v2.json diagnostic. The archived
V1 geometries, force files, trim solutions and their hashes are not changed.
"""
import hashlib
import json
import math
import re
from collections import Counter
from pathlib import Path

from audit_mass_tables import summarize
from avl_reference_gate import parse
from collect_wright_family import collect
from trim_control_grid import fable_interference_witness

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(rel, provenance):
    path = ROOT / rel
    provenance[rel] = sha(path)
    return json.loads(path.read_bytes())


def checked(path, expected, provenance):
    digest = sha(path)
    if digest != expected:
        raise ValueError('Archived file changed: ' + str(path))
    provenance[path.relative_to(ROOT).as_posix()] = digest
    return path.read_text(encoding='utf-8')


def margin(cm_alpha, cl_alpha):
    if not math.isfinite(cm_alpha) or not math.isfinite(cl_alpha) or cl_alpha <= 0:
        raise ValueError('Require finite pitching slope and positive lift slope')
    return -cm_alpha / cl_alpha


def balance(cl, cd, cm, speed, thrust, alpha_deg, mass, area, chord, arm):
    qs = .5 * 1.225 * speed**2 * area
    a = math.radians(alpha_deg)
    lift, drag, weight = qs * cl, qs * cd, mass * 9.80665
    tv, th = thrust * math.sin(a), thrust * math.cos(a)
    ma, mt = qs * chord * cm, arm * thrust
    return {'aerodynamic_lift_N': lift, 'thrust_vertical_N': tv,
            'total_upward_N': lift + tv, 'weight_N': weight,
            'drag_N': drag, 'thrust_horizontal_N': th,
            'aerodynamic_pitch_moment_Nm': ma, 'thrust_pitch_moment_Nm': mt,
            'horizontal_residual_N': th - drag, 'vertical_residual_N': lift + tv - weight,
            'pitch_residual_Nm': ma + mt}


def surface_replays(fixed, prov):
    source='analysis/results/surface_loads_v2_attempt01/summary.json'
    replay=load(source,prov)
    results=[]
    for r in replay['records']:
        if r['status']!='completed' or any(r['FT_delta'].values()): raise ValueError('Incomplete or changed surface replay')
        work=ROOT/'analysis/results/surface_loads_v2_attempt01'/r['model']
        for name,digest in r['file_sha256'].items(): checked(work/name,digest,prov)
        base=next(v for v in fixed if v['model']==r['model'] and v['mesh_nc_ns'][0]==12)
        qs=.5*1.225*base['speed_m_s']**2*base['Sref_m2']
        cr=base['Cref_m']
        raw=(work/'strip_forces.txt').read_text()
        # FS surface summary gives five decimals versus FN's four. Use only
        # the block normalized by Sref, never the repeated Ssurf coefficient.
        surfaces=[]
        for block in re.split(r'(?=  Surface #)',raw)[1:]:
            name=re.search(r'Surface #\s*\d+\s+([^\r\n]+)',block).group(1).strip()
            common=block.split('Forces referred to Ssurf, Cave')[0]
            cl,cd,cm=[parse(common,k) for k in ['CLsurf','CDsurf','Cmsurf']]
            surfaces.append({'name':name,'CL_Sref':cl,'CD_Sref':cd,'Cm_Sref_Cref':cm,
                             'lift_N':qs*cl,'induced_drag_N':qs*cd,'pitch_moment_about_CG_Nm':qs*cr*cm})
        ft=(work/'forces.txt').read_text()
        n=len(surfaces)
        closure={}
        for key,ftkey,scale in [('CL_Sref','CLtot',qs),('CD_Sref','CDind',qs),('Cm_Sref_Cref','Cmtot',qs*cr)]:
            diff=sum(s[key] for s in surfaces)-parse(ft,ftkey)
            # Independent rounded surface values and rounded FT total.
            bound=n*5e-6+(5e-8 if ftkey=='CDind' else 5e-6)
            if abs(diff)>bound+1e-12: raise ValueError('Surface sum outside print precision')
            closure[key]={'sum_minus_FT_coefficient':diff,'printed_rounding_bound_coefficient':bound,
                          'sum_minus_FT_dimensional':diff*scale,'printed_rounding_bound_dimensional':bound*scale}
        groups={}
        for s in surfaces:
            key=s['name'].replace(' (YDUP)','')
            if key.startswith('tail_'): key='horizontal_tail'
            g=groups.setdefault(key,{'lift_N':0.,'induced_drag_N':0.,'pitch_moment_about_CG_Nm':0.})
            for k in g: g[k]+=s[k]
        results.append({'model':r['model'],'surfaces':surfaces,'component_groups':groups,
                        'closure':closure,'total_force_file_byte_identical_to_archived':sha(work/'forces.txt')==sha(ROOT/r['source_directory']/'forces_2.txt'),
                        'scope':'Surface loads include local induced-velocity and section effects in unchanged VLM; no body, viscous or propwash loads.'})
    return results


def build():
    prov = {}
    selected = load('analysis/results/fixed_control_slope_selected_v1.json', prov)
    moments = load('analysis/results/longitudinal_geometry_v1.json', prov)
    masses = {m: summarize(load(f'analysis/{m}_v1_extracted.json', prov)) for m in ['astra','fable','opus']}
    fixed = []
    for r in selected['records']:
        work = ROOT / r['selected_directory']
        geom = checked(work/'aircraft.avl', r['geometry_sha256'], prov)
        checked(work/'section.dat', r['foil_sha256'], prov)
        checked(work.parent/'summary.json', r['summary_sha256'], prov)
        area, chord, span = map(float, geom.splitlines()[3].split())
        ref = list(map(float, geom.splitlines()[4].split()))
        expected_cg = list(masses[r['model']]['cg_original_axes_m'])
        if r['model'] == 'astra': expected_cg[0] *= -1
        if any(abs(a-b) > 1e-12 for a,b in zip(ref,expected_cg)):
            raise ValueError('Moment point is not extracted V1 CG')
        values = {}
        c = r['frozen_candidate']
        for i,a in enumerate([3.5,3.75,4.,4.25,4.5]):
            name = f'forces_{i}.txt'
            raw = checked(work/name, r['force_sha256'][name], prov)
            if abs(parse(raw,'Alpha')-a)>1e-9 or abs(parse(raw,'pitch')-c['control_deg'])>5.01e-6:
                raise ValueError('Not fixed-control alpha series')
            values[a] = {k:parse(raw,k) for k in ['CLtot','CDind','Cmtot','CXtot','CZtot']}
            for k in ['CLtot','CDind','Cmtot']:
                if values[a][k] != r['values'][str(a)][k]: raise ValueError('Raw/summary mismatch')
        estimates = []
        for h in [.25,.5]:
            slopes = {k:(values[4+h][k]-values[4-h][k])/(2*h) for k in values[4.]}
            sm = margin(slopes['Cmtot'],slopes['CLtot'])
            # At fixed z and body attitude convention, translating moment origin
            # along geometric aft-x uses normal force CN=-CZ, not lift at alpha!=0.
            normal_margin = margin(slopes['Cmtot'],-slopes['CZtot'])
            estimates.append({'alpha_half_step_deg':h,'slopes_per_deg':slopes,
                              'effective_CL_slope_margin_Cref':sm,
                              'effective_CL_slope_margin_percent_Cref':100*sm,
                              'constant_z_CN_slope_neutral_offset_m':normal_margin*chord,
                              'constant_z_CN_slope_neutral_x_aft_m':ref[0]+normal_margin*chord})
        v = values[4.]
        b = balance(v['CLtot'],v['CDind']+.05,v['Cmtot'],c['speed_m_s'],c['thrust_N'],4,
                    masses[r['model']]['mass_kg'],area,chord,
                    moments[r['model'].upper()+'-V1']['pitch_coefficient_per_N_forward_thrust'])
        for new, old in [('horizontal_residual_N','horizontal_N'),('vertical_residual_N','vertical_N'),('pitch_residual_Nm','pitch_Nm')]:
            if abs(b[new]-r['center_residual_at_original_candidate'][old])>1e-8: raise ValueError('Residual mismatch')
        fixed.append({'model':r['model'],'mesh_nc_ns':[r['nc'],r['ns']],
                      'selected_directory':work.relative_to(ROOT).as_posix(),
                      'Sref_m2':area,'Cref_m':chord,'Bref_m':span,'reference_CG_aft_right_up_m':ref,
                      'frozen_control_deg':c['control_deg'],'speed_m_s':c['speed_m_s'],
                      'estimates':estimates,'center_force_and_moment_balance':b})

    trim = load('analysis/results/trim_control_grid_v1.json',prov)
    power = load('analysis/power_scenarios_v1.json',prov)
    power_cases = {r['model']:r for r in power['cases']}
    gridpath = ROOT/'analysis/results/avl_control_grid01/summary.json'
    grid = json.loads(checked(gridpath,trim['grid_summary_sha256'],prov))
    for row in grid['rows']:
        base = gridpath.parent/row['model']
        checked(base/'aircraft.avl',row['geometry_sha256'],prov)
        for name,digest in row['force_sha256'].items(): checked(base/name,digest,prov)
    counts, representatives = {}, []
    for model in ['astra','fable','opus']:
        cases = [r for r in trim['cases'] if r['model']==model]
        candidates = [(r,c) for r in cases for c in r['candidates']]
        target = power_cases[model]['target_engine_shaft_power_W']
        badpower, collision = 0,0
        for row,c in candidates:
            useful = c['thrust_N']*c['speed_m_s']*math.cos(math.radians(row['alpha_deg']))
            if abs(useful-c['useful_propulsive_power_W'])>1e-7: raise ValueError('Power mismatch')
            badpower += target is not None and useful>target+1e-8
            if model=='fable':
                witness=fable_interference_witness(c['control_deg'])
                if witness != c['mechanical_witness']: raise ValueError('Mechanical witness mismatch')
                collision += witness['inside_declared_fin']
            if row['alpha_deg']==4 and row['added_CD']==.05 and row['added_drag_moment_arm_m']==0:
                geom=(gridpath.parent/model/'aircraft.avl').read_text()
                s,cr,_=map(float,geom.splitlines()[3].split())
                b=balance(c['CL'],c['CD_total_scenario'],c['Cm_aero'],c['speed_m_s'],c['thrust_N'],4,
                          masses[model]['mass_kg'],s,cr,moments[model.upper()+'-V1']['pitch_coefficient_per_N_forward_thrust'])
                representatives.append({'model':model,'evidence_type':'interpolated algebraic root, not direct full-model trim',
                                        'control_deg':c['control_deg'],'speed_m_s':c['speed_m_s'],
                                        'shaft_power_at_assumed_efficiency_W':useful/power_cases[model]['propeller_efficiency'],
                                        'engine_target_W':target,'balance':b})
        counts[model]={'scenarios':len(cases),'candidates':len(candidates),
                       'no_root_scenarios':sum(not r['candidates'] for r in cases),
                       'useful_power_exceeds_target':badpower,'tail_fin_conflicts':collision}

    wright=[]
    # The original run marked several valid rounded-reference files failed;
    # established collector explicitly audits printed rounding and geometry.
    groups=[('coarse',collect(ROOT/'analysis/results/wright_reconstruction_family02')['records'])]
    comparison=load('analysis/results/wright_family_comparison_v1.json',prov)
    fine=[]
    for n in [3,4]: fine += collect(ROOT/f'analysis/results/wright_reconstruction_family{n:02d}')['records']
    if fine != comparison['fine_selected_cases']: raise ValueError('Wright fine selection mismatch')
    groups.append(('fine',fine))
    for n in [2,3,4]:
        folder=ROOT/f'analysis/results/wright_reconstruction_family{n:02d}'
        for path in folder.rglob('*'):
            if path.is_file() and path.name in ['summary.json','definition.json','forces.txt','wing.avl','section.dat','commands.txt']:
                prov[path.relative_to(ROOT).as_posix()]=sha(path)
    for mesh,rows in groups:
        keys=sorted({(r['canard_section'],r['canard_incidence_deg']) for r in rows})
        for section,inc in keys:
            pair=sorted([r for r in rows if (r['canard_section'],r['canard_incidence_deg'])==(section,inc)],key=lambda r:r['alpha_deg'])
            if len(pair)!=2: raise ValueError('Incomplete Wright secant')
            slopes={k:(pair[1]['coefficients'][k]-pair[0]['coefficients'][k])/4 for k in ['CLtot','Cmtot','CDind']}
            wright.append({'mesh':mesh,'canard_section':section,'canard_incidence_deg':inc,
                           'alpha_interval_deg':[0,4],'secant_per_deg':slopes,
                           'minus_Cm_over_CL_secant_about_ARBITRARY_reference':margin(slopes['Cmtot'],slopes['CLtot']),
                           'aircraft_static_margin':None})
    loads=surface_replays(fixed,prov)
    return {'scope':'Archived conditional mechanics audit plus two unchanged-input local surface-load replays; no demonstrated flight',
            'input_sha256':dict(sorted(prov.items())), 'fixed_control_results':fixed,
            'representative_interpolated_balances':representatives,'scenario_counts':counts,
            'wright_fixed_canard_secants':wright,'surface_load_replays':loads,
            'individual_surface_loads':{'available':True,'available_models':['astra','opus'],'missing_models':['fable','wright'],
                                        'reason':'Historical FT archive had no component loads; two new local FN/FS replays recovered Astra/Opus loads without changing geometry or control.',
                                        'do_not_do':'Do not split total lift by area or assume a center of pressure to invent surface loads.'},
            'interpretation':['Positive local margin means restoring aerodynamic pitch slope only in this frozen simplified model.',
                              'Cref is declared normalization, not verified whole-configuration mean aerodynamic chord.',
                              'The -Cm_alpha/CL_alpha quantity is an effective lift-based metric; the CN-based offset uses fixed z and body normal force for the aft-x reference translation.',
                              'Fine-grid centers reuse coarse interpolated settings and are not exact trims.',
                              'Wright reference (x,z)=(0.59436,0.59436) m is not a measured CG; its secants cannot rank aircraft stability.',
                              'No validated total drag, powered derivatives, structural margins, control forces, full inertia tensor or dynamic modes.']}


def main():
    result=build()
    out=ROOT/'analysis/results/flight_mechanics_revision_v2.json'
    out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'scenario_counts':result['scenario_counts'],
                      'margins':[(r['model'],r['mesh_nc_ns'],r['estimates'][0]['effective_CL_slope_margin_percent_Cref']) for r in result['fixed_control_results']],
                      'verified_input_count':len(result['input_sha256'])},indent=2))


if __name__=='__main__': main()
