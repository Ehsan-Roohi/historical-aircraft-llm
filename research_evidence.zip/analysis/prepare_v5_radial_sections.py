#!/usr/bin/env python3
"""Freeze radial V5 section contours from archived, separately versioned inputs.

This makes only two-dimensional section inputs. It does not accept V5 blade
assemblies, alter V2 aircraft geometry, or predict propeller performance.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path

RHO = 1.225
MU = 1.81e-5
A_SOUND = 340.0
ANGLES = (-2, 0, 2, 4, 6, 8, 10, 12, 14)
RESPONSE_HASHES = {
    'gpt-6-astra': '39452d0e399a6fc7884b7dfc6c480ef2a657ebc6357d740cb39acb7e00825f61',
    'claude-fable-5-1': 'f42e6c956bd4f323480400c8136218662970edd47a9f03f411f84f1a98e829c3',
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ordinates(family, thickness, x):
    if family == 'astra':
        if thickness != .12:
            raise ValueError('Astra V5_S1 requires t/c=0.12')
        a = 27 / (35 * math.sqrt(21))
        upper = a * math.sqrt(x * (1 - x)) * (1 - 20*x/27)
        return upper, -upper
    if family == 'fable':
        camber = 4*.06*x*(1-x)
        half = 5*thickness*(.2969*math.sqrt(x)-.1260*x-.3516*x*x+.2843*x**3-.1015*x**4)
        return camber+half, camber-half
    raise ValueError(family)


def contour(family, thickness, density, label):
    xs = [(1-math.cos(math.pi*i/density))/2 for i in range(density+1)]
    upper = [(x, ordinates(family, thickness, x)[0]) for x in reversed(xs)]
    lower = [(x, ordinates(family, thickness, x)[1]) for x in xs[1:]]
    return label+'\n'+''.join(f'{x:.12f} {y:.12f}\n' for x,y in upper+lower)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--project-root', type=Path, default=Path('.'))
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    root = args.project_root
    v3path = root/'analysis/v3b_propulsion_inputs.json'
    v3 = {r['model']:r for r in json.loads(v3path.read_text())['records']}
    args.output.mkdir(parents=True, exist_ok=False)
    sections, stations = [], []
    for model, family in [('gpt-6-astra','astra'), ('claude-fable-5-1','fable')]:
        response_path = root/'received_v5_64962376/responses'/model/'response.json'
        if sha(response_path) != RESPONSE_HASHES[model]:
            raise ValueError('V5 model response hash mismatch: '+model)
        response = json.loads(json.loads(response_path.read_text())['response'])
        parent = v3[model]
        if family == 'astra':
            assignment = response['station_assignment']
            radii = assignment['radii_m']
            betas = assignment['V3c_candidate_twist_deg']
            thicknesses = [.12]*len(radii)
        else:
            assignments = response['station_assignment']
            radii = [s['r_m'] for s in assignments]
            betas = [s['beta_deg'] for s in assignments]
            thicknesses = [s['t'] for s in assignments]
        if len(radii) != len(parent['stations']):
            raise ValueError('Station count mismatch: '+model)
        for i,(radius,beta,thickness) in enumerate(zip(radii,betas,thicknesses)):
            parent_radius, chord, parent_beta = parent['stations'][i]
            if not math.isclose(radius, parent_radius, abs_tol=1e-9):
                raise ValueError('Radial mismatch: '+model)
            if family == 'fable' and not math.isclose(beta,parent_beta,abs_tol=1e-9):
                raise ValueError('Fable inherited beta mismatch')
            omega = 2*math.pi*parent['rpm']/60
            speed = math.hypot(parent['V'], omega*radius)
            reynolds = RHO*speed*chord/MU
            incidence = beta-math.degrees(math.atan2(parent['V'],omega*radius))
            stem = f'{family}_r{round(radius*100):03d}'
            station = dict(stem=stem, family=family, model=model, radius_m=radius,
                           chord_m=chord, thickness_parameter=thickness,
                           beta_deg=beta, parent_v3b_beta_deg=parent_beta,
                           rpm=parent['rpm'], advance_speed_m_s=parent['V'],
                           relative_speed_no_induction_m_s=speed,
                           reynolds_no_induction=reynolds, mach_no_induction=speed/A_SOUND,
                           geometric_incidence_no_induction_deg=incidence,
                           alpha_screen_deg=list(ANGLES),
                           input_qualification='no induction, swirl, root/tip or installation effect')
            stations.append(station)
            for density in (80,120):
                filename = f'{stem}_n{density}.dat'
                path = args.output/filename
                path.write_text(contour(family,thickness,density,filename))
                sections.append(dict(file=filename,sha256=sha(path),stem=stem,
                                     family=family,station_index=len(stations)-1,
                                     points=2*density+1))
    manifest = dict(stage='v5_radial_section_numerical_screen',
                    parent_v3b_sha256=sha(v3path),parent_v5_model_job='64962376',
                    response_sha256=RESPONSE_HASHES, rho_kg_m3=RHO,
                    dynamic_viscosity_Pa_s=MU,speed_of_sound_m_s=A_SOUND,
                    stations=stations,sections=sections,
                    interpretation='section-only, not a blade-load or propulsion result')
    (args.output/'manifest.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps(dict(stations=len(stations),files=len(sections),
                          incidence_min=min(s['geometric_incidence_no_induction_deg'] for s in stations),
                          incidence_max=max(s['geometric_incidence_no_induction_deg'] for s in stations))))


if __name__ == '__main__':
    main()
