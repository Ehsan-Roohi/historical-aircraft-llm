"""Source-backed launch bookkeeping and structural-input gaps, not load/takeoff validation."""
import hashlib
import json
import math
from pathlib import Path
from audit_mass_tables import summarize

ROOT = Path(__file__).resolve().parents[1]
G = 9.80665


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def evidence(text, needle):
    found = [{'line_1_based':i,'text':line} for i,line in enumerate(text.splitlines(),1) if needle in line]
    if len(found)!=1: raise ValueError('Evidence anchor not unique: '+needle)
    return found[0]


def constant_force(mass, airspeed_target, headwind, net_force):
    if not all(math.isfinite(v) for v in [mass,airspeed_target,headwind,net_force]) or min(mass,net_force)<=0 or min(airspeed_target,headwind)<0:
        raise ValueError('Invalid work-energy inputs')
    groundspeed = max(0,airspeed_target-headwind)
    energy = .5*mass*groundspeed**2
    return {'target_groundspeed_m_s':groundspeed,'kinetic_energy_from_rest_J':energy,
            'constant_net_force_N':net_force,'distance_m':energy/net_force,
            'scope':'Kinematic constant NET force illustration; no variable thrust/drag/rolling, pitch or lift-off solution'}


def slope_energy(mass, length, grade, target_groundspeed):
    if not all(math.isfinite(v) for v in [mass,length,grade,target_groundspeed]) or min(mass,length,target_groundspeed)<=0 or grade<0:
        raise ValueError('Invalid slope inputs')
    sine = grade/math.sqrt(1+grade**2)
    drop = length*sine
    gravity = mass*G*drop
    kinetic = .5*mass*target_groundspeed**2
    return {'slope_path_length_m':length,'grade_vertical_over_horizontal':grade,'vertical_drop_m':drop,
            'gravity_work_J':gravity,'target_kinetic_energy_J':kinetic,
            'gravity_work_fraction_of_target_KE':gravity/kinetic,
            'lossless_gravity_only_speed_m_s':math.sqrt(2*G*drop),
            'required_average_other_net_force_N':(kinetic-gravity)/length,
            'scope':'Zero-wind researcher bookkeeping; other net force means thrust minus aerodynamic and rolling resistance. Not a launch prediction.'}


def main():
    names = {'astra':'gpt-6-astra','fable':'claude-fable-5-1','opus':'claude-opus-5-5'}
    anchors = {
        'astra':{'article':['Departure is from a smooth','Loaded structures require proof loading'],
                 'response':['| W01-R / W02-R |','| W01-T / W02-T |','Truss node graph, member sizes']},
        'fable':{'article':['prepared grass slope of 1 in 12','Ribs at 0.4 m spacing'],
                 'response':['| Decks P01–P03 |','| Body frame P10 |','Spring deflection, skid flexure']},
        'opus':{'article':['**Launch.**','- structural strength in gusts;'],
                'response':['| Wings W1–W3 |','| Struts and wires W4–W5 |','**Nosing-over protection is contradicted']}}
    sources, masses = {}, {}
    for name,model in names.items():
        article_path = ROOT/f'received_2026-09-24/astra_fable_opus_designs/{model}/article.md'
        raw_path = ROOT/f'analysis/raw_v1/verified/{model}.json'
        mass_path = ROOT/f'analysis/{name}_v1_extracted.json'
        mass_data = json.loads(mass_path.read_bytes())
        if sha(raw_path)!=mass_data['source']['registered_sha256']: raise ValueError('Selected raw source changed')
        article = article_path.read_text(encoding='utf-8')
        response = json.loads(raw_path.read_bytes())['response']
        sources[name] = {'article_path':article_path.relative_to(ROOT).as_posix(),'article_sha256':sha(article_path),
                         'raw_path':raw_path.relative_to(ROOT).as_posix(),'raw_sha256':sha(raw_path),
                         'mass_input_sha256':sha(mass_path),
                         'article_evidence':[evidence(article,a) for a in anchors[name]['article']],
                         'decoded_response_evidence':[evidence(response,a) for a in anchors[name]['response']],
                         'line_convention':'Article lines or decoded response-text lines, not raw JSON line numbers',
                         'structural_status':'Explicitly incomplete sections/topology/load-path data; no strength margin established, not a structural failure verdict'}
        masses[name] = summarize(mass_data)['mass_kg']
    # Values taken from separately evidenced V0 launch statements; V1 substitutions are labeled.
    astra = constant_force(masses['astra'],14.5,0,300)
    opus_v0 = constant_force(340,12.8,2,300)
    opus_v1_same_target = constant_force(masses['opus'],12.8,2,300)
    v1_source_cl_speed = math.sqrt(2*masses['opus']*G/(1.2*38*.9))
    opus_v1_same_cl = constant_force(masses['opus'],v1_source_cl_speed,2,300)
    fable = slope_energy(masses['fable'],80,1/12,12.5)
    output = {'scope':__doc__,'sources':sources,'V1_mass_kg':masses,
              'astra_source_arithmetic':astra,
              'opus_V0_illustration_at_source_cruise_speed_not_verified_liftoff_speed':opus_v0,
              'opus_V1_mass_same_speed_researcher_variant':opus_v1_same_target,
              'opus_V1_mass_same_CL_researcher_variant':{'airspeed_target_m_s':v1_source_cl_speed,**opus_v1_same_cl},
              'fable_V1_zero_wind_slope_energy_illustration':fable,
              'qualifications':['Astra 300 N is explicitly average net accelerating force; constant-force substitution is only an arithmetic replay.',
                                'Opus says 300 N excess over rolling resistance, not unambiguously over aerodynamic drag too. Treating it as total net force is an additional assumption.',
                                'Opus 12.8 m/s is labeled cruising speed in V0; no established liftoff criterion is inferred.',
                                'Fable specifies into-wind but no numeric wind speed; zero wind here is an analyst case. The 80 m length is interpreted along the slope.',
                                'Fable gravity work does not include thrust, aerodynamic drag, rolling losses, variable lift, rotation or obstacle clearance.',
                                'Do not compare launch distances across unlike slope, wind, mass and liftoff conditions.',
                                'Existing nominal clearances do not establish elastic or moving ground clearances.',
                                'No dimensions, material strengths or joint capacities are fabricated to run a structural solver.'],
              'not_established':['Complete load cases/distributions','Member and joint strength margins','Ground-run force history','Rotation/liftoff/obstacle clearance','Landing impact and stopping','Actual flight capability']}
    (ROOT/'analysis/results/launch_structure_audit_v1.json').write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in output.items() if k!='sources'},indent=2))


if __name__=='__main__': main()
