"""Package only reviewed postprocessing code, no credentials or third-party files."""
import hashlib
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
dest=root/'output/delivery/reference_reader_v2.zip'
with ZipFile(dest,'x',ZIP_DEFLATED) as z:
    for name in ('postprocess_reference_v4.py','xfoil_verified_reader.py'):
        z.write(root/'analysis'/name,name)
print(hashlib.sha256(dest.read_bytes()).hexdigest())
