"""Small-angle control-normal probe; not moving geometry or powered trim."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
from avl_aircraft_pilot import ROOT, EXE, geometry
from avl_reference_gate import parse


def controlled_geometry(model, nc=8, ns=40):
    # AVL CONTROL rotates normals, not vertices. Full-surface xhinge=0
    # is not a claim that Astra's physical quarter-chord hinge moved to LE.
    target = {'astra': 'forward', 'fable': 'tail', 'opus': 'tail_outer'}[model]
    hinge = 1.1/1.6 if model == 'opus' else 0.0
    lines = geometry(model, nc, ns).splitlines()
    out = []
    active = False
    i = 0
    while i < len(lines):
        line = lines[i]
        if line == 'SURFACE':
            active = lines[i+1] == target
        out.append(line)
        if line == 'SECTION' and active:
            i += 1
            out.append(lines[i])
            out.extend(['CONTROL', f'pitch 1.0 {hinge:.12f} 0 1 0 1'])
        i += 1
    return '\n'.join(out)+'\n'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--fine', action='store_true')
    ap.add_argument('--models', nargs='+', choices=['astra','fable','opus'], default=['astra','fable','opus'])
    args = ap.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    records = []
    nc, ns = (12,80) if args.fine else (8,40)
    for model, attempt in [('astra','01'),('fable','03'),('opus','03')]:
        if model not in args.models:
            continue
        case = out/model
        case.mkdir()
        (case/'aircraft.avl').write_text(controlled_geometry(model,nc,ns), encoding='ascii')
        foil = ROOT/f'analysis/results/avl_aircraft_pilot{attempt}/{model}_c8_s40_a4/section.dat'
        (case/'section.dat').write_bytes(foil.read_bytes())
        commands = 'load aircraft.avl\noper\na a 4\n'
        for label, delta in [('minus',-1),('half_minus',-.5),('zero',0),('half_plus',.5),('plus',1)]:
            commands += f'd1 d1 {delta}\nx\nft\n{label}.txt\n'
        commands += '\nquit\n'
        (case/'commands.txt').write_text(commands,encoding='ascii')
        try:
            p = subprocess.run([str(EXE)],input=commands,cwd=case,capture_output=True,text=True,
                               timeout=300,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        except subprocess.TimeoutExpired as error:
            (case/'timeout.txt').write_text(str(error),encoding='utf-8')
            for stream in ['stdout','stderr']:
                value = getattr(error,stream) or b''
                if isinstance(value,bytes):
                    value = value.decode(errors='replace')
                (case/f'{stream}.txt').write_text(value,encoding='utf-8')
            raise
        (case/'stdout.txt').write_text(p.stdout,encoding='utf-8')
        (case/'stderr.txt').write_text(p.stderr,encoding='utf-8')
        if p.returncode:
            raise RuntimeError(f'AVL failed: {model}')
        values = {}
        for label in ['minus','half_minus','zero','half_plus','plus']:
            raw = (case/f'{label}.txt').read_text()
            values[label] = {k:parse(raw,k) for k in ['CLtot','CDind','Cmtot']}
        prior = ROOT/f'analysis/results/avl_aircraft_pilot{attempt}/{model}_c{nc}_s{ns}_a4/forces.txt'
        baseline = {k:parse(prior.read_text(),k) for k in ['CLtot','CDind','Cmtot']}
        row = {'model':model,'nc':nc,'ns':ns,'alpha_deg':4,'delta_deg':[-1,-.5,0,.5,1], 'values':values,
               'zero_minus_prior':{k:values['zero'][k]-baseline[k] for k in baseline},
               'central_derivative_per_deg':{k:(values['plus'][k]-values['minus'][k])/2 for k in baseline},
               'half_step_derivative_per_deg':{k:values['half_plus'][k]-values['half_minus'][k] for k in baseline},
               'geometry_sha256':hashlib.sha256((case/'aircraft.avl').read_bytes()).hexdigest()}
        records.append(row)
        print(json.dumps(row),flush=True)
        (out/'summary.json').write_text(json.dumps({'scope':'alpha=4 deg, normal tilt only; not trim or physical control clearance','records':records},indent=2)+'\n',encoding='utf-8')


if __name__ == '__main__':
    main()
