"""Replay selected deterministic analyses in a retained isolated copy, never over originals.

No solver, network, API generation, or Unity submission is performed.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import shlex
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
STEPS = [
    ('recover_original_prompts.py', ['analysis/prompts_v0/article.prompt.txt', 'analysis/prompts_v0/instructions.txt', 'analysis/prompts_v0/gpt-6-astra.figures.prompt.txt', 'analysis/prompts_v0/claude-fable-5-1.figures.prompt.txt', 'analysis/prompts_v0/claude-opus-5-5.figures.prompt.txt', 'analysis/prompts_v0/manifest.json']),
    ('recover_clarification_prompts.py', ['analysis/prompts_v1/gpt-6-astra.prompt.txt', 'analysis/prompts_v1/claude-fable-5-1.prompt.txt', 'analysis/prompts_v1/claude-opus-5-5.prompt.txt', 'analysis/prompts_v1/instructions.txt', 'analysis/prompts_v1/manifest.json']),
    ('recover_single_figure_prompts.py', ['analysis/prompts_v0/claude-fable-5-1.three_view.single.prompt.txt', 'analysis/prompts_v0/claude-fable-5-1.oblique.single.prompt.txt', 'analysis/prompts_v0/claude-opus-5-5.three_view.single.prompt.txt', 'analysis/prompts_v0/single_figure_audit.json']),
    ('check_source_archive.py', ['analysis/results/source_archive_check_v1.json']),
    ('verify_astra_extraction.py', ['analysis/results/astra_raw_extraction_check_v1.json']),
    ('verify_fable_extraction.py', ['analysis/results/fable_raw_extraction_check_v1.json']),
    ('verify_opus_extraction.py', ['analysis/results/opus_raw_extraction_check_v1.json']),
    ('audit_mass_tables.py', ['analysis/results/mass_table_audit_v1.json']),
    ('longitudinal_balance.py', ['analysis/results/longitudinal_geometry_v1.json']),
    ('screening_v1.py', ['analysis/results/screening_v1.json','analysis/results/screening_v1.md']),
    ('wright_screening.py', ['analysis/results/wright_screening_v1.json']),
    ('coefficient_normalization.py', ['analysis/results/coefficient_normalization_v1.json']),
    ('digitize_wright_reference.py', ['analysis/results/wright_props_off_digitized_v1.json']),
    ('audit_uiuc_reference.py', ['analysis/references/uiuc_wright1903/manifest.json']),
    ('power_envelope.py', ['analysis/results/power_envelope_v1.json']),
    ('collect_aircraft_pilot.py', ['analysis/results/aircraft_pilot_selected_v1.json']),
    ('compare_control_probes.py', ['analysis/results/control_probe_comparison_v1.json']),
    ('conditional_trim.py', ['analysis/results/conditional_trim_v1.json']),
    ('audit_opus_control_motion.py', ['analysis/results/opus_control_motion_v1.json']),
    ('trim_control_grid.py', ['analysis/results/trim_control_grid_v1.json']),
    ('audit_astra_control_budget.py', ['analysis/results/astra_control_budget_v1.json']),
    ('ideal_propulsion_bound.py', ['analysis/results/ideal_propulsion_bound_v1.json']),
    ('collect_fixed_control_slope.py', ['analysis/results/fixed_control_slope_selected_v1.json']),
    ('digitize_wright_planform.py', ['analysis/results/wright_planform_trace_v1.json']),
    ('digitize_wright_side.py', ['analysis/results/wright_side_landmarks_v1.json']),
    ('audit_eiffel10.py', ['analysis/results/eiffel10_section_audit_v1.json']),
    ('collect_section_probe.py', ['analysis/results/section_probe_audit_v1.json']),
    ('collect_wright_family.py --folder analysis/results/wright_reconstruction_family02 --output analysis/results/wright_reconstruction_audit_v1.json', ['analysis/results/wright_reconstruction_audit_v1.json']),
    ('collect_wright_family.py --folder analysis/results/wright_reconstruction_family03 --output analysis/results/wright_reconstruction_fine_audit_v1.json', ['analysis/results/wright_reconstruction_fine_audit_v1.json']),
    ('collect_wright_family.py --folder analysis/results/wright_reconstruction_family04 --output analysis/results/wright_reconstruction_fine_retry_audit_v1.json', ['analysis/results/wright_reconstruction_fine_retry_audit_v1.json']),
    ('collect_wright_family.py --folder analysis/results/wright_reconstruction_family05 --output analysis/results/wright_reconstruction_incidence_audit_v1.json', ['analysis/results/wright_reconstruction_incidence_audit_v1.json']),
    ('compare_wright_family.py', ['analysis/results/wright_family_comparison_v1.json']),
    ('inertia_bookkeeping.py', ['analysis/results/inertia_bookkeeping_v1.json']),
    ('trim_power_necessity.py', ['analysis/results/trim_power_necessity_v1.json']),
    ('launch_structure_audit.py', ['analysis/results/launch_structure_audit_v1.json']),
    ('plot_wright_response.py', ['output/figures/wright_response_v1.svg', 'output/figures/wright_response_v1.png', 'output/figures/wright_response_v1_preview.png', 'output/figures/wright_response_v1_manifest.json']),
    ('plot_fixed_control_response.py', ['output/figures/fixed_control_response_v1.svg', 'output/figures/fixed_control_response_v1.png', 'output/figures/fixed_control_response_v1_preview.png', 'output/figures/fixed_control_response_v1_manifest.json']),
    ('audit_manuscript_structure.py', ['analysis/results/manuscript_structure_audit_v1.json']),
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def comparison(original, regenerated):
    if not regenerated.is_file():
        return {'status':'not_generated'}
    if not original.is_file():
        return {'status':'no_archived_comparator','generated_sha256':sha(regenerated)}
    same = original.read_bytes() == regenerated.read_bytes()
    return {'status':'identical' if same else 'different',
            'archived_sha256':sha(original),'generated_sha256':sha(regenerated)}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True,help='New directory; retained with logs and copied inputs')
    parser.add_argument('--figure-python',type=Path,default=Path(sys.executable),help='Python with Pillow for the selected figure only; analysis uses the invoking Python')
    args=parser.parse_args()
    figure_python=args.figure_python.resolve()
    figure_check=subprocess.run([str(figure_python),'-c','import sys,PIL; print(sys.version); print(PIL.__version__)'],capture_output=True,text=True,timeout=30)
    if figure_check.returncode:
        raise ValueError('Figure interpreter must have Pillow: '+figure_check.stderr)
    font_paths=[Path('C:/Windows/Fonts/arial.ttf'),Path('C:/Windows/Fonts/arialbd.ttf')]
    font_hashes={str(p):sha(p) for p in font_paths}
    output=args.output.resolve()
    targets=[rel for _,paths in STEPS for rel in paths]
    if len(targets)!=len(set(targets)):
        raise ValueError('Duplicate selected artifact')
    for rel in targets:
        if not (ROOT/rel).is_file():
            raise ValueError('Selected comparator not found: '+rel)
    for protected in [ROOT/'analysis', ROOT/'paper', ROOT/'received_2026-09-24']:
        if output == protected or output.is_relative_to(protected):
            raise ValueError('Output must not be inside copied input trees')
    output.mkdir(parents=True,exist_ok=False)
    stage=output/'workspace'; stage.mkdir()
    copied=['analysis','paper','received_2026-09-24/astra_fable_opus_designs']
    for rel in copied:
        shutil.copytree(ROOT/rel,stage/rel,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    (stage/'unity_jobs').mkdir()
    shutil.copy2(ROOT/'unity_jobs/run_geometry_clarifications.py',stage/'unity_jobs/run_geometry_clarifications.py')
    for rel in targets:
        original=ROOT/rel
        if original.is_file():
            archived=output/'archived_comparators'/rel
            archived.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(original,archived)
    # Remove only named derived files in the newly created copy: require actual regeneration.
    for rel in targets:
        path=(stage/rel).resolve()
        if not path.is_relative_to(stage.resolve()):
            raise ValueError('Derived target escaped staging directory')
        if path.is_file(): path.unlink()
    inventory={str(p.relative_to(stage)):sha(p) for p in stage.rglob('*') if p.is_file()}
    (output/'input_manifest.json').write_text(json.dumps(inventory,indent=2)+'\n',encoding='utf-8')
    env=dict(os.environ, PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1')
    runs=[]
    commands=[]
    for index,(invocation,paths) in enumerate(STEPS,1):
        parts=shlex.split(invocation)
        interpreter=str(figure_python) if parts[0] in ('plot_wright_response.py','plot_fixed_control_response.py') else sys.executable
        commands.append((f'step_{index:02d}_'+parts[0], [interpreter,str(Path('analysis')/parts[0]),*parts[1:]],paths))
    # Some integration-style tests inspect regenerated definitions; run only after fresh generation.
    commands.append(('unit_tests',[sys.executable,'-m','unittest','discover','-s','analysis','-p','test_*.py'],[]))
    for name,cmd,paths in commands:
        row={'step':name,'command':cmd}
        try:
            proc=subprocess.run(cmd,cwd=stage,env=env,capture_output=True,text=True,encoding='utf-8',timeout=60)
            row.update(returncode=proc.returncode,status='completed' if proc.returncode==0 else 'failed')
            (output/(name+'.stdout.txt')).write_text(proc.stdout,encoding='utf-8')
            (output/(name+'.stderr.txt')).write_text(proc.stderr,encoding='utf-8')
        except subprocess.TimeoutExpired:
            row.update(status='timed_out',returncode=None)
        row['outputs']={rel:comparison(ROOT/rel,stage/rel) for rel in paths}
        runs.append(row)
        print(name,row['status'],[v['status'] for v in row['outputs'].values()],flush=True)
        if row['status']!='completed': break
    mutated=[rel for rel,digest in inventory.items() if not (stage/rel).is_file() or sha(stage/rel)!=digest]
    passed=(len(runs)==len(commands) and not mutated and
            all(r['status']=='completed' and all(v['status']=='identical' for v in r['outputs'].values()) for r in runs))
    result={'scope':'Selected postprocessing replay from archived source and solver files; NOT solver re-execution or physical validation',
            'python':sys.version,'platform':platform.platform(),'runner_sha256':sha(Path(__file__)),
            'figure_runtime':{'executable':str(figure_python),'python_and_pillow':figure_check.stdout.strip(),'external_font_sha256':font_hashes},
            'input_manifest_sha256':sha(output/'input_manifest.json'),
            'copied_input_files':len(inventory),'mutated_staged_inputs':mutated,
            'all_selected_outputs_reproduced_byte_for_byte':passed,'steps':runs,
            'not_covered':['Full API-generation/transport history and unresolved historical prompts','new solver runs','Wright matched-geometry validation','experimental physics','publication licensing']}
    (output/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    if not passed: sys.exit(1)


if __name__=='__main__': main()
