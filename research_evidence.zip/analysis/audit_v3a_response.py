"""Read-only acceptance of response packaging, NOT engineering approval."""
import argparse
import hashlib
import json
import re
from pathlib import Path

def inspect_case(case):
    response_path=case/'response.json'
    outcome=json.loads((case/'outcome.json').read_bytes())
    if not response_path.exists():
        return dict(model=case.name,status=outcome['status'],complete=False)
    raw=response_path.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=outcome['response_sha256']:
        raise ValueError('Response hash mismatch')
    response=json.loads(raw)
    blocks=re.findall(r'```json\s*(.*?)\s*```',response.get('response',''),re.S)
    record=dict(model=case.name,status=response['status'],stop_reason=response.get('stop_reason'),hash_verified=True,complete=False)
    if response['status']!='completed' or len(blocks)!=1:
        return record
    try: data=json.loads(blocks[0])
    except json.JSONDecodeError:
        record['error']='Invalid JSON';return record
    required={'stage','parent_model','changes','geometry_checks','mass_check','unresolved','next_gate'}
    record.update(complete=required.issubset(data),missing_keys=sorted(required-set(data)),proposal=data,
                  engineering_validation='NOT_EVALUATED; do not automatically apply model changes')
    return record

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('responses',type=Path);a=p.parse_args()
    print(json.dumps([inspect_case(x.parent) for x in sorted(a.responses.glob('*/outcome.json'))],indent=2))
