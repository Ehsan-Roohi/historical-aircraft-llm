"""Assemble an author-identified article and full-text research supplement.

No remote operations, solver runs, or claims of successful TeX compilation.
"""
from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'output/overleaf/aircraft_complete_roohi_v3'
REPORTS = [
    'comparison_conditions_v1', 'power_feasibility_v1',
    'avl_aircraft_pilot_v1', 'conditional_trim_v1',
    'expanded_control_trim_v1', 'trim_power_necessity_v1',
    'fixed_control_slope_v1', 'inertia_evidence_v1',
    'launch_structure_evidence_v1', 'wright_validation_gate_v1',
    'wright_reconstruction_family_v1', 'wright_measured_reference_v1',
    'wright_reference_acquisition_v1', 'wright_section_proxy_v1',
    'wright_section_input_probe_v1', 'wright_planform_trace_v1',
    'wright_side_registration_v1', 'llm_prior_work_review_v1',
    'bibliographic_verification_v1', 'postprocessing_reproduction_v1',
    'single_figure_provenance_v1', 'manuscript_methods_audit_v1',
]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def esc(text):
    # XeLaTeX preserves Unicode in these archived English reports.
    chars = {'\\': r'\textbackslash{}', '&': r'\&', '%': r'\%',
             '$': r'\$', '#': r'\#', '_': r'\_', '{': r'\{',
             '}': r'\}', '~': r'\textasciitilde{}', '^': r'\textasciicircum{}'}
    return ''.join(chars.get(c, c) for c in text)

def prose(text):
    text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'\1 (\2)', text)
    return esc(text.replace('**', '').replace('`', ''))

def report_tex(text):
    lines = text.splitlines()
    out = []
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line.startswith('```'):
            i += 1
            block = []
            while i < len(lines) and not lines[i].startswith('```'):
                block.append(lines[i]); i += 1
            out.append('\\begin{quote}\\ttfamily\\footnotesize\n' + '\n\\par\n'.join(esc(x) for x in block) + '\n\\end{quote}')
        elif line.startswith('#'):
            depth = len(line) - len(line.lstrip('#'))
            cmd = 'section' if depth == 1 else 'subsection' if depth == 2 else 'subsubsection'
            out.append('\\' + cmd + '{' + prose(line.lstrip('# ')) + '}')
        elif line.startswith('|'):
            rows = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                row = lines[i].strip().strip('|').split('|')
                if not all(re.fullmatch(r'\s*:?-+:?\s*', cell) for cell in row):
                    rows.append(row)
                i += 1
            n = len(rows[0])
            assert all(len(row) == n for row in rows)
            landscape = n >= 5
            if landscape: out.append(r'\begin{landscape}')
            out.append(r'\begingroup\footnotesize\setlength{\tabcolsep}{3pt}')
            spec = ('>{\\raggedright\\arraybackslash}p{\\dimexpr\\linewidth/' + str(n) + '-6pt\\relax}') * n
            out.append(r'\begin{longtable}{' + spec + '}\n\\toprule')
            for j, row in enumerate(rows):
                out.append(' & '.join(prose(cell.strip()) for cell in row) + r' \\')
                if j == 0: out.append(r'\midrule\endhead')
            out.append('\\bottomrule\n\\end{longtable}\n\\endgroup')
            if landscape: out.append(r'\end{landscape}')
            continue
        elif line:
            out.append(prose(line) + '\n\\par')
        i += 1
    return '\n\n'.join(out)

def build():
    if DEST.exists(): raise FileExistsError(DEST)
    base = ROOT / 'output/overleaf/aircraft_overleaf_v2'
    # Read from the sealed archive, not an assumed staging folder.
    with zipfile.ZipFile(base.with_suffix('.zip')) as z:
        main = z.read('main.tex').decode('ascii')
        bibliography = z.read('references.tex')
    source = (ROOT / 'paper/manuscript_draft_v1.md').read_text(encoding='utf-8')
    author = ('Ehsan Roohi\\\\\n{\\small Department of Mechanical and Industrial Engineering}\\\\\n'
              '{\\small University of Massachusetts Amherst}\\\\\n'
              '{\\small 160 Governors Drive, Amherst, MA 01003, USA}\\\\\n'
              '{\\small\\texttt{roohie@umass.edu}}')
    main = main.replace(r'\usepackage[T1]{fontenc}', r'\usepackage{fontspec}')
    main = main.replace(r'\usepackage[utf8]{inputenc}', r'\setmainfont{TeX Gyre Termes}')
    main = main.replace(r'\usepackage{lmodern}', r'\usepackage{pdflscape}')
    main = re.sub(r'\\author\{\}[^\n]*', lambda _: '\\author{' + author + '}', main)
    main = main.replace('Private working draft -- 26 September 2026', '26 September 2026')
    main = re.sub(r'\\noindent\\textit\{Not submission-ready\.[^\n]*\}\n', '', main)
    start = main.index('Working manuscript, 26 September 2026.')
    end = main.index('\\section*{Abstract', start)
    main = main[:start] + main[end:]
    main = main.replace('Abstract (provisional)', 'Abstract').replace('Data, code and AI-use disclosure (draft)', 'Data, code and AI-use disclosure')
    # Remove superseded milestone prose from the article; preserve it in original records.
    a = main.index('An expanded checkpoint, attempt10,')
    b = main.index('Local analysis scripts,', a)
    disclosure = ('The archived postprocessing checkpoint (attempt10) regenerated 57 selected artifacts through 38 invocations of 35 scripts, with 103 passing tests and 804 unchanged staged inputs. Both scientific response figures and structural cross-reference checks were included. This same-host replay uses archived solver outputs; it is neither a new AVL run, a portability test, nor physical validation. Historical checkpoints and unsuccessful attempts are retained in the research records. The Supplementary Research Record provides the detailed scope and limitations.\n\n')
    main = main[:a] + disclosure + main[b:]
    note = ('\\section*{Original design configurations}\n'
            'The following plates reproduce the original V0 design artifacts without geometric repair. '
            'Their embedded dates refer to the historical design prompt, not to actual nineteenth-century documents. '
            'Dimensions, masses, contradictions and unknowns in these plates must not be substituted for the frozen V1 analysis inputs. '
            'Astra uses tandem lifting surfaces; Fable and Opus use biplane layouts with aft horizontal surfaces. '
            'These drawings document the proposals, not validated construction plans. The archived Fable orthographic plate contains overlapping and clipped annotations; its original SVG and source text are supplied for inspection.\n')
    plates = [note]
    DEST.mkdir(parents=True)
    (DEST / 'figures').mkdir()
    (DEST / 'original-drawings').mkdir()
    (DEST / 'research-source').mkdir()
    for model, folder in [('astra', 'gpt-6-astra'), ('fable', 'claude-fable-5-1'), ('opus', 'claude-opus-5-5')]:
        for view in ['three_view', 'oblique']:
            name = f'{model}_{view}_v0.png'
            shutil.copy2(ROOT / 'output/aircraft_atlas_v0' / name, DEST / 'figures' / name)
            original = ROOT / 'received_2026-09-24/astra_fable_opus_designs' / folder / (view + '.svg')
            shutil.copy2(original, DEST / 'original-drawings' / f'{model}_{view}_v0.svg')
            caption = f'{model.title()} V0: ' + ('orthographic views.' if view == 'three_view' else 'oblique view.')
            plates.append('\\begin{landscape}\n\\begin{figure}[p]\n\\centering\n'
                          '\\includegraphics[width=0.98\\linewidth,height=0.87\\textheight,keepaspectratio]{figures/' + name + '}\n'
                          '\\caption{' + caption + '}\n\\end{figure}\n\\end{landscape}')
    main = main.replace(r'\end{document}', '\\clearpage\n\\appendix\n' + '\n'.join(plates) + '\n\\end{document}')
    main = main.replace('compiler = pdfLaTeX', 'compiler = XeLaTeX')
    (DEST / 'main.tex').write_text(main, encoding='utf-8')
    (DEST / 'references.tex').write_bytes(bibliography)
    for name in ['wright_response_v1.png', 'fixed_control_response_v1.png']:
        shutil.copy2(ROOT / 'output/figures' / name, DEST / 'figures' / name)
    (DEST / 'research-source/original-manuscript.md').write_text(source, encoding='utf-8')
    supplementary = [r'''\documentclass[11pt,a4paper]{article}
\usepackage{fontspec}
\setmainfont{TeX Gyre Termes}
\setmonofont{Latin Modern Mono}
\usepackage[margin=22mm]{geometry}
\usepackage{longtable,booktabs,array,pdflscape,amsmath,amssymb}
\usepackage[hidelinks]{hyperref}
\setlength{\emergencystretch}{4em}
\title{Supplementary Research Record\\Engineering Assessment of Three Language-Model Aircraft Designs}
\author{Ehsan Roohi}
\date{26 September 2026}
\begin{document}
\maketitle
This document contains the full text of 22 archived analysis reports, not merely an index. Reports retain their original scope and historical checkpoint wording. Later results supersede earlier checkpoints only where explicitly stated. Their local file paths identify records in the separate private research archive; they are not external download links. This is a research record, not additional physical validation. The main article gives the consolidated conclusions. Original Markdown files are included alongside this typeset edition.
\tableofcontents
\clearpage
''']
    for name in REPORTS:
        path = ROOT / 'paper' / (name + '.md')
        text = path.read_text(encoding='utf-8')
        shutil.copy2(path, DEST / 'research-source' / path.name)
        supplementary.append('\\clearpage\n' + report_tex(text))
    supplementary.append(r'\end{document}')
    (DEST / 'supplement.tex').write_text('\n'.join(supplementary), encoding='utf-8')
    readme = '''# Complete article package — Ehsan Roohi

Upload this ZIP directly as a new Overleaf project. It is not the raw research archive.
Set Compiler = XeLaTeX and Main document = main.tex. Compile twice for references.
To typeset the 22 full research reports, select supplement.tex as Main document and compile twice.

Contents: author-identified full article, six unchanged original V0 aircraft plates,
two scientific response plots, six equations, five numbered scientific tables plus
nomenclature, seven references, full-text research supplement, editable source reports,
and six original SVG drawings. No API key, external computation or shell escape is needed.

Author details were transcribed from the supplied Our TAML.pdf, page 1:
Ehsan Roohi; Department of Mechanical and Industrial Engineering, University of
Massachusetts Amherst, 160 Governors Drive, Amherst, MA 01003, USA;
roohie@umass.edu. No coauthors from that unrelated paper were added.

Compilation: static checks only; no local TeX engine is available. This package has
NOT been compiled or page-layout-verified. No new Unity job was submitted.
This is the consolidated current-evidence manuscript, not a claim of journal readiness,
flight certification, demonstrated flight, or superiority to the Wright Flyer.
It uses a generic review layout rather than a certified current AIAA template.

V0 plates preserve inconsistent annotations. In particular the original Fable
orthographic artwork contains overlaps/clipping; increasing resolution does not repair
the source. The SVGs and source reports preserve the evidence. V1 engineering inputs
must be taken from the versioned research archive, not these earlier drawings.

Keep the raw research archive private until third-party redistribution rights are checked.
'''
    (DEST / 'README.md').write_text(readme, encoding='utf-8')
    for filename in ['main.tex', 'supplement.tex']:
        text = (DEST / filename).read_text(encoding='utf-8')
        stack = []
        for m in re.finditer(r'\\(begin|end)\{([^}]+)\}', text):
            if m[1] == 'begin': stack.append(m[2])
            else: assert stack and stack.pop() == m[2], (filename, m[0])
        assert not stack
        assert 'ZZTOKEN' not in text
    assert main.count(r'\includegraphics') == 8
    assert main.count(r'\tag{') == 6
    assert 'affiliation are pending' not in main
    files = {p.relative_to(DEST).as_posix(): digest(p.read_bytes()) for p in sorted(DEST.rglob('*')) if p.is_file()}
    manifest = {'files': files, 'author': 'Ehsan Roohi', 'compiled': False,
                'research_reports': len(REPORTS), 'figures': 8,
                'original_plates_version': 'V0', 'analysis_version': 'V1',
                'source_manuscript_sha256': digest(source.encode('utf-8'))}
    (DEST / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    archive = DEST.with_suffix('.zip')
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(DEST.rglob('*')):
            if p.is_file(): z.write(p, p.relative_to(DEST).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for name, value in files.items(): assert digest(z.read(name)) == value
    print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size,
                      'sha256': digest(archive.read_bytes()), 'files': len(files)+1,
                      'reports': len(REPORTS), 'compiled': False}, ensure_ascii=True, indent=2))

if __name__ == '__main__':
    build()
