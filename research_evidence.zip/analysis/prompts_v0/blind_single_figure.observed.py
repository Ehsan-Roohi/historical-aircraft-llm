#!/usr/bin/env python3
"""Ask original model for one standalone SVG when paired drawing was truncated."""
import argparse, hashlib, json, os
from pathlib import Path
from datetime import datetime, timezone
from blind_aircraft_eval import INSTRUCTIONS, sha
from frontier_wright_eval import generate

p=argparse.ArgumentParser()
p.add_argument('--model',choices=['gpt-6-astra','claude-opus-5-5','claude-fable-5-1'],required=True)
p.add_argument('--view',choices=['three_view','oblique'],required=True)
a=p.parse_args()
stem=a.model.replace('/','-')
records=[json.loads(line) for line in Path('blind-'+stem+'.jsonl').read_text().splitlines() if line]
article=next(r['response'] for r in records if r['stage']=='article' and r['status']=='completed')
form=('one SVG (1200 × 900) with separate top, front, and side orthographic '
      'projections, consistent coordinate scales and a legend' if a.view=='three_view'
      else 'one simple SVG (1200 × 900) of the ENTIRE machine seen obliquely, '
           'with all major parts in one frame, a few readable labels, and a short legend. '
           'Keep the drawing compact, fewer than 100 primitives and 6000 characters')
prompt=("You wrote the engineering article below. Draw YOUR OWN "+form+". "
        "Place the operator and each actual part according to YOUR original "
        "article. Do not add, remove or rearrange any device, and do not silently "
        "fix contradictory or absent coordinates; visibly mark UNKNOWN or "
        "SCHEMATIC. Output a single valid standalone <svg>...</svg> element, "
        "with no preface or code fence, no external resources, scripts, "
        "stylesheets or embedded HTML. Use compact SVG primitives; devote "
        "the available output to one complete figure.\n\nYOUR ORIGINAL ARTICLE:\n"+article)
out=Path('blind-'+stem+'-'+a.view+'.jsonl')
if out.exists() and any(json.loads(x).get('status')=='completed' for x in out.read_text().splitlines() if x):
    print('already completed',flush=True);raise SystemExit
key=os.environ['OPENAI_API_KEY' if a.model=='gpt-6-astra' else 'ANTHROPIC_API_KEY']
record={'model_requested':a.model,'stage':a.view,'article_sha256':sha(article),
        'prompt_sha256':sha(prompt),'instruction_sha256':sha(INSTRUCTIONS),
        'generated_utc':datetime.now(timezone.utc).isoformat(),
        'modern_pretraining_contamination':True}
try:
    record.update(generate(a.model,prompt,22000 if a.view=='oblique' else 12000,
                           key,reasoning_effort='low',instructions=INSTRUCTIONS))
except Exception as e:
    record.update(status='error',error_type=type(e).__name__,error_message=str(e)[:180])
with out.open('a') as f:f.write(json.dumps(record,ensure_ascii=False)+'\n')
print(a.model,a.view,record['status'],record.get('stop_reason'),len(record.get('response','')),flush=True)
