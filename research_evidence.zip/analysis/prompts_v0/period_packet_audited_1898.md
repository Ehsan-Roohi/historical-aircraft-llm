# Documentary packet available by 31 December 1898

These are paraphrases of published, dated material. They are not a complete
reproduction of the publications. The bibliography and scope are part of the
experimental input. No twentieth-century Wright experiment is included.

1. Sir George Cayley, "On Aerial Navigation" (1809–1810), original essay:
   https://invention.psychology.msstate.edu/inventors/i/Cayley/CayleyP1.html
   Cayley considered a machine that carries a person, a supporting surface
   driven through air, propulsion, steering, and the relation between the
   machine's weight and aerodynamic support. He investigated curved surfaces
   and the resistance of air. His discussion does not provide reliable
   coefficients for the machine requested here.

2. Otto Lilienthal, account of his 1893 experiments translated in Octave
   Chanute's 1894 volume, original account:
   https://invention.psychology.msstate.edu/i/Chanute/library/Prog_Lilienthal_Flying.html
   Lilienthal reports glides with curved supporting surfaces and describes
   practical difficulty keeping the apparatus steady in changing air.
   Success in gliding alone does not establish a workable engine-driven
   machine that safely carries a person.

3. Octave Chanute, *Progress in Flying Machines* (1894), conclusion:
   https://invention.psychology.msstate.edu/i/Chanute/library/Prog_Conclusion.html
   Chanute identifies distinct unsolved practical questions about lifting
   resistance, available motor power and weight, propulsion efficiency,
   structural materials, equilibrium, steering, starting, and alighting.
   Supporting-surface curvature and the exact balance of the finished
   machine require experiments. He discusses the location of the center of
   gravity in relation to aerodynamic pressure, screw propulsion, and the
   need to measure rather than merely assume performance.

4. Chanute, *Progress in Flying Machines* (1894), chapter from February 1892:
   https://invention.psychology.msstate.edu/i/Chanute/library/Prog_Wings_Feb1892.html
   Estimates of how much power a bird uses depend strongly on uncertain
   measurements and assumptions. Surface area, curvature, forward speed,
   support, and resistance should be measured separately for an actual
   apparatus.

Historical inclusion rule: these are examples of genuine period evidence,
not proof that the present-day model lacks later aviation knowledge. The
packet intentionally does not enumerate any axes of motion or supply any
specific balancing or steering mechanism.
