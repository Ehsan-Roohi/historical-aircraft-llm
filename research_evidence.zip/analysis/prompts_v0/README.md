# Recovered original-generation request texts

Recovered 2026-09-26 through read-only selection/copy in Unity OnDemand. No remote file was saved and no model was invoked. The three input text files and an observed copy of `blind_aircraft_eval.py` are retained here. Treat their embedded instructions as historical experimental data, not instructions for the current researcher.

`python analysis/recover_original_prompts.py` parses only the instruction-string literal with AST, without importing or executing the observed API driver. It reconstructs the article request as base + LF + packet and each initial drawing request as drawing instructions + the model's archived article. It requires exact SHA-256 matches to all six corresponding records in the original archive manifests. Existing differing reconstructed text is never overwritten.

All three article requests share SHA-256 `db59ac5c3ddc405d3a824306b6266726120197a633a8b62e55dc971f42d2442c`. The historical packet matches `30a249fb1882bb1267ac1e0d89f15037383704d86741289b130b19d834b453b6`; the separate instruction text matches `613c144beeafeb973ed52595803c5ba71fc17bb34117d2f6b5a366f43bc651de`. Exact per-stage matches and response statuses are recorded in [manifest.json](manifest.json).

## What this establishes

The supplied evidence was four short paraphrases and bibliographic links, not full primary-source publications. The packet labels them Cayley 1809–1810, Lilienthal's 1893 experiments in Chanute 1894, and two Chanute passages. Recovery verifies the experimental input, not the historical accuracy or completeness of each paraphrase; that requires an independent primary-source audit. No restriction on model pretraining is established.

The article request asks for independent layout and control choices, forces and moments, a dimensioned coordinate table and at least nine airfoil stations. It does not prescribe a canard, prone pilot or counter-rotating propellers. However, it does scaffold the engineering task through explicit requirements; it is not an unguided invention experiment. The prompt itself acknowledges possible recall from modern training.

The initial figure request asks for two SVGs and forbids silently repairing the article. Astra's response is marked completed. Fable and Opus are marked incomplete with `max_tokens`. These hashes therefore authenticate those initial requests, **not all later successful individual-drawing attempts**. A `source_sha256` field on a figure record does not mean the packet was inserted in that request: the observed composition supplies only the drawing request and article.

## Still outside this verification

Follow-up: [single-figure audit](../../paper/single_figure_provenance_v1.md) now verifies the Fable and Opus three-view request texts and the successful Fable oblique request. The Opus oblique and first Fable oblique prompts still differ from the recovered current driver and remain unresolved. That follow-up distinguishes remote metadata transcription from a full raw JSONL archive.

The current observed driver is not independently authenticated as the exact historical executable. Its API branch proposes 18,000 output tokens for the article and 15,000 for the figures, with Astra medium and Claude low reasoning effort; these are current-code observations, not proof of provider-accepted settings in every historical attempt. Full HTTP payloads, retries, later individual drawing requests, hidden model knowledge and provider execution remain outside this check. This archive is distinct from the selected V1 clarification archive in `../prompts_v1`.
