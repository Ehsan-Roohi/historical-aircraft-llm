#!/usr/bin/env python3
"""Historically audited, unhinted piloted design and model-authored SVG study."""
import argparse, hashlib, json, os, traceback
from datetime import datetime, timezone
from pathlib import Path
from frontier_wright_eval import generate

INSTRUCTIONS = (
    "You are writing a counterfactual engineering proposal at the stated "
    "date. Distinguish period evidence, derivation, speculation, and possible "
    "recall from your modern training. Make choices independently and state "
    "uncertainty clearly."
)

def sha(data):
    return hashlib.sha256(data.encode('utf-8')).hexdigest()

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--model', choices=['gpt-6-astra','Qwen/Qwen3-14B',
                                      'claude-opus-5-5','claude-fable-5-1'], required=True)
    a = p.parse_args()
    model = a.model
    source = Path('period_packet_audited_1898.md').read_text()
    base = Path('blind_piloted_design_1898.txt').read_text()
    draw = Path('blind_figure_request_1898.txt').read_text()
    out = Path('blind-'+model.replace('/','-').replace('Qwen-','qwen-')+'.jsonl')
    records = [json.loads(line) for line in out.read_text().splitlines() if line] if out.exists() else []
    qwen = model.startswith('Qwen/')
    if qwen:
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        root = Path('/datasets/ai/qwen3/hub/models--Qwen--Qwen3-14B')
        snapshot = max((x for x in (root/'snapshots').iterdir()
                        if (x/'config.json').is_file()), key=lambda x:x.stat().st_mtime)
        tok = AutoTokenizer.from_pretrained(str(snapshot),local_files_only=True)
        net = AutoModelForCausalLM.from_pretrained(str(snapshot),torch_dtype=torch.bfloat16,
                                                   local_files_only=True,device_map='cuda').eval()
        torch.manual_seed(1898)
    else:
        key=os.environ['OPENAI_API_KEY' if model=='gpt-6-astra' else 'ANTHROPIC_API_KEY']
    for stage in ('article','figures'):
        if any(r['stage']==stage and r['status']=='completed' for r in records):
            print(model,stage,'already completed',flush=True); continue
        if stage=='article': prompt=base+'\n'+source
        else:
            article=next((r for r in records if r['stage']=='article' and r['status']=='completed'),None)
            if article is None: print(model,'article incomplete; stopping',flush=True); break
            prompt=draw+article['response']
        rec=dict(model_requested=model,stage=stage,cutoff='1898-12-31',
                 human_piloted=True,prompt_sha256=sha(prompt),
                 source_sha256=sha(source),instruction_sha256=sha(INSTRUCTIONS),
                 modern_pretraining_contamination=True,
                 generated_utc=datetime.now(timezone.utc).isoformat())
        try:
            if qwen:
                ids=tok.apply_chat_template([{'role':'system','content':INSTRUCTIONS},
                                             {'role':'user','content':prompt}],tokenize=True,
                                            add_generation_prompt=True,enable_thinking=True,
                                            return_tensors='pt').to(net.device)
                cap=14000 if stage=='article' else 15500
                with torch.inference_mode():
                    seq=net.generate(ids,attention_mask=torch.ones_like(ids),
                                     max_new_tokens=cap,do_sample=True,temperature=.6,
                                     top_p=.95,top_k=20,
                                     pad_token_id=tok.eos_token_id)[0][ids.shape[-1]:]
                raw=tok.decode(seq,skip_special_tokens=True)
                answer=raw.split('</think>',1)[-1].strip() if '</think>' in raw else ''
                rec.update(response=answer,status='completed' if answer else 'incomplete',
                           stop_reason='eos_or_limit',checkpoint=snapshot.name,
                           input_tokens=ids.shape[-1],output_tokens=len(seq),raw_generation=raw)
            else:
                cap=18000 if stage=='article' else 15000
                rec.update(generate(model,prompt,cap,key,
                                    reasoning_effort='medium' if model=='gpt-6-astra' else 'low',
                                    instructions=INSTRUCTIONS))
        except Exception as e:
            rec.update(status='error',error_type=type(e).__name__,error_message=str(e)[:180])
        with out.open('a',encoding='utf-8') as f:
            f.write(json.dumps(rec,ensure_ascii=False)+'\n')
        records.append(rec)
        print(model,stage,rec['status'],rec.get('stop_reason'),
              len(rec.get('response','')),flush=True)
        if rec['status']!='completed' or not rec.get('response'):break

if __name__=='__main__':main()
