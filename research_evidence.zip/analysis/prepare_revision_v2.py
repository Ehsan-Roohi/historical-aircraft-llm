"""Prepare exact V2 model requests; never calls an API or reads credentials."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'analysis/prompts_v2_retrim'
COMMON = '''You are revising your own archived aircraft design in a fresh API request.
This is a RESEARCHER-ASSISTED REVISION, not a new historically blind trial. The
documentary cutoff remains 31 December 1898, but the supplied evaluator feedback
uses modern, simplified calculations. Do not pretend it is a historical measurement.
Do not claim memory of previous requests, real tests, or successful flight.

Propose a version-2 complete person-carrying powered aircraft. You may retain or
change your architecture, but explain every change and preserve version-1 facts
as the immutable parent. No particular canard, aft-tail or propeller arrangement
is prescribed. Disclose possible recall from modern training. Do not silently
replace missing material or engine evidence with assumed modern capability.

First address the attached evidence, including its uncertainty and omitted physics.
Seek simultaneous force/moment equilibrium, realizable control travel and a
restoring longitudinal tendency; distinguish that target from pilot-stabilizable
flight. Positive static margin alone cannot establish dynamic stability or safety.
Report your own numerical estimates as estimates, not as independent validation.

Provide a concise English technical explanation and ONE valid JSON code block with:
schema_version, parent_model, coordinate_convention, units, change_log,
lifting_surfaces (section stations, leading-edge xyz, chord, incidence, twist,
dihedral, normalized upper/lower section ordinates and actual area), controls
(hinge axis, deflection sign/limits, mixing, linkage, motion envelope), mass_items
(unique ID, mass, centroid xyz, bounding geometry, overlap/inclusion, intrinsic
inertia or UNKNOWN), propulsion (engine/drive/propeller geometry, mass, power or
torque curve and source/assumption, thrust estimate), structural_members
(nodes, connectivity, cross sections, material/allowable evidence, joints),
claimed_flight_state (rho,V,alpha,controls,individual_surface_forces,thrust,drag,
moment_terms,residuals,method), stability (fixed-control derivatives, reference
point/chord, method, damping/inertia limitations), launch_and_landing,
remaining_unknowns, proposed_tests and suspected_modern_recall.

Use SI units and one explicit coordinate system. UNKNOWN is preferable to a
fabricated measurement. Calculate mass and CG from the same non-overlapping ledger.
Do not generate pictures in this response. A drawing will be generated only from
the frozen returned geometry after independent consistency checks.
'''

def sha(data): return hashlib.sha256(data).hexdigest()

def main():
    DEST.mkdir(exist_ok=False)
    evidence = json.loads((ROOT/'analysis/results/flight_mechanics_revision_v2.json').read_text())
    retrim_path = ROOT/'analysis/results/retrim_v2_attempt01/summary.json'
    retrim = json.loads(retrim_path.read_text())
    packet = (ROOT/'analysis/prompts_v0/period_packet_audited_1898.md').read_text(encoding='utf-8')
    protocol = ROOT/'paper/revision_experiment_v2.md'
    records = []
    for short, model in [('astra','gpt-6-astra'),('fable','claude-fable-5-1'),('opus','claude-opus-5-5')]:
        rawpath = ROOT/'analysis/raw_v1/verified'/f'{model}.json'
        raw = rawpath.read_bytes(); parent = json.loads(raw)
        # Select only the recipient's numerical results, never another model's design.
        selected = {}
        for key in ['fixed_control_results','representative_interpolated_balances','surface_load_replays']:
            rows = evidence.get(key, [])
            if isinstance(rows, list):
                selected[key] = [row for row in rows if short in str(row.get('model','')).lower()]
        selected['subsequent_direct_retrim'] = [
            {'model':r['model'],'status':r['status'],'accepted_state':r['accepted_state'],
             'fixed_control_alpha_probe':r['fixed_control_alpha_probe']}
            for r in retrim['records'] if r['model']==short]
        feedback = {
            'astra': 'The frozen-control local pitch slope is positive in the lifting-surface model (destabilizing); control mixing shares a limited collective/differential budget. Unverified engine target 18 kW is not a measured installed power curve. Specify structural topology and long-shaft/ground-clearance limits.',
            'fable': 'All 24 conditional trim candidates in the sampled grid conflict with the declared fixed fin when the continuous horizontal tail rotates about its stated leading-edge hinge. Resolve actual hardware geometry, not just a coefficient. One mass centroid lies outside its assembly envelope; engine available power remains unestablished.',
            'opus': 'The frozen-control local pitch slope is negative in the lifting-surface model, but no dynamic or lateral-directional stability is established. At the selected illustrative drag case, required shaft power at assumed efficiency 0.60 is about 13.4 kW versus an unverified 13 kW target. Resolve the actual-area/reference-area distinction, structure and loaded clearances.'
        }[short]
        prompt = COMMON + '\nEVALUATOR FEEDBACK\n' + feedback + '\nCONDITIONAL NUMERICAL RECORD\n' + json.dumps(selected, indent=2) + '\nUNCHANGED PERIOD PACKET\n' + packet + '\nIMMUTABLE PARENT V1 RESPONSE\n' + parent['response']
        path = DEST/f'{model}.prompt.txt'
        path.write_text(prompt, encoding='utf-8')
        records.append({'model_requested':model,'parent_sha256':sha(raw),'prompt_file':path.name,
                        'prompt_sha256':sha(path.read_bytes()),'maximum_output_tokens':32000,
                        'sent':False,'response':None})
    (DEST/'instructions.txt').write_text('Separate historical evidence, assumptions, conditional evaluator output and proposed revisions. Never claim unperformed experiments or successful flight.',encoding='utf-8')
    manifest = {'stage':'researcher_assisted_revision_v2_prepared_not_sent','protocol_sha256':sha(protocol.read_bytes()),
                'supersedes_prepared_unsent_prompts':'analysis/prompts_v2',
                'direct_retrim_sha256':sha(retrim_path.read_bytes()),
                'evidence_sha256':sha((ROOT/'analysis/results/flight_mechanics_revision_v2.json').read_bytes()),
                'historical_packet_sha256':sha((ROOT/'analysis/prompts_v0/period_packet_audited_1898.md').read_bytes()),
                'records':records}
    (DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'prepared':len(records),'sent':0,'output':str(DEST)},ensure_ascii=True))

if __name__=='__main__': main()
