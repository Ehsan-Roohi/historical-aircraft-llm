// Independent SVG rasterization for visual QA, not a change to source artwork.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const sharp = require('C:/Users/roohie/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const root = path.resolve(__dirname, '..');
const out = path.join(root, 'output', 'figure_svg_qa');
const digest = b => crypto.createHash('sha256').update(b).digest('hex');

async function main() {
  fs.mkdirSync(out, {recursive:true});
  const records=[];
  for (const stem of ['wright_response_v1','fixed_control_response_v1']) {
    const source=path.join(root,'output','figures',stem+'.svg');
    const bytes=fs.readFileSync(source);
    const target=path.join(out,stem+'_svg.png');
    const info=await sharp(bytes,{density:300}).png().toFile(target);
    await sharp(target).resize({width:920}).png().toFile(path.join(out,stem+'_svg_preview.png'));
    records.push({source:path.relative(root,source),source_sha256:digest(bytes),
      raster:path.relative(root,target),raster_sha256:digest(fs.readFileSync(target)),
      width:info.width,height:info.height,density_requested:300});
  }
  const result={scope:'Independent librsvg rasterization; visual review still required',
    node:process.version,renderer_versions:sharp.versions,records,
    limits:['Fonts are resolved on this host, not embedded','No final journal-page placement check','Not a cross-platform guarantee']};
  fs.writeFileSync(path.join(out,'render_manifest.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result,null,2));
}
main().catch(e=>{console.error(e);process.exitCode=1;});
