"""Audit manuscript cross-references and local targets; not content or layout QA."""
import hashlib
import json
import re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'paper/manuscript_draft_v1.md'


def main():
    text=SOURCE.read_text(encoding='utf-8')
    links=[]
    for match in re.finditer(r'!?\[[^\]\n]*\]\(([^)\n]*)\)',text):
        target=match.group(1)
        if target.startswith(('https://','http://','#')):
            continue
        path=(SOURCE.parent/target.split('#',1)[0]).resolve()
        links.append({'target':target,'exists':path.is_file()})
    captions=re.findall(r'\*\*Table (\d+)\.',text)
    figures=re.findall(r'\*\*Figure (\d+)\.',text)
    equations=re.findall(r'\\tag\{(\d+)\}',text)
    tables=re.findall(r'(?m)^\|[^\n]+\n\|[-:| ]+\|$',text)
    before,after=text.split('## References',1)
    first_refs=list(dict.fromkeys(re.findall(r'\[(\d+)\]',before)))
    refs=re.findall(r'(?m)^\[(\d+)\]',after)
    checks={
        'all_local_targets_exist':all(row['exists'] for row in links),
        'five_sequential_table_captions':captions==list(map(str,range(1,6))),
        'five_tables_plus_nomenclature':len(tables)==6,
        'tables_called_out_before_caption':all(text.index('Table '+n)<text.index('**Table '+n+'.') for n in captions),
        'two_sequential_figure_captions':figures==['1','2'],
        'figures_called_out_before_caption':all(text.index('Figure '+n)<text.index('**Figure '+n+'.') for n in figures),
        'six_sequential_equations':equations==list(map(str,range(1,7))),
        'reference_order_matches_first_use':first_refs==refs==list(map(str,range(1,8))),
    }
    result={'source':SOURCE.relative_to(ROOT).as_posix(),
            'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            'checks':checks,'local_links':links,'all_checks_pass':all(checks.values()),
            'limits':['No remote-link availability check','No scientific claim verification',
                      'No DOCX/PDF rendering or layout verification','Links are checked in the current workspace, not a portable package']}
    out=ROOT/'analysis/results/manuscript_structure_audit_v1.json'
    out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'checks':checks,'local_link_count':len(links),'all_checks_pass':result['all_checks_pass']},indent=2))
    if not result['all_checks_pass']:
        raise SystemExit(1)


if __name__=='__main__':
    main()
