"""Locate stability-derivative discussions in the user's private FD2 notes.

Run only on the locally extracted PDFs. Do not add source PDFs/text to the
public reproducibility archive; the notes are third-party teaching material.
"""
from pathlib import Path
import pdfplumber

folder = Path(__file__).resolve().parents[1] / "tmp/flight_dynamics_reader"
terms = ("alpha dot", "alphadot", "Cmq", "C_mq", "mشتق", "مشتقات",
         "stability derivative", "pitch rate", "qhat", "downwash")
for path in (folder / f"CH{i}.pdf" for i in range(2, 5)):
    with pdfplumber.open(path) as pdf:
        print(path.name, len(pdf.pages))
        for page_number, page in enumerate(pdf.pages, 1):
            text = page.extract_text() or ""
            found = [term for term in terms if term.lower() in text.lower()]
            if found:
                print("  page", page_number, "terms", ", ".join(found))
                print("   ", ascii(" ".join(text[:220].split())))
