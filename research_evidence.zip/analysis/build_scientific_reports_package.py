"""Mechanically split the expanded source into 8-display-item main text and SI.

The master paper/article_scientific_reports.tex retains every figure and table.
Only the generated journal-target files are rearranged; no result is deleted.
"""

from pathlib import Path
import re
import shutil

ROOT = Path(__file__).resolve().parents[1]
MASTER = ROOT / "paper/article_scientific_reports.tex"
OUT = ROOT / "output/overleaf/scientific_reports_aircraft_2026_09_28"
PREVIOUS = ROOT / "output/overleaf/scientific_reports_aircraft_2026_09_27"

SUPP_FIGURES = ["fig:wrightthree", "fig:astra", "fig:fable", "fig:opus", "fig:wright", "fig:pitch"]
SUPP_TABLES = ["tab:interpolated", "tab:loads", "tab:residual", "tab:stability", "tab:architecture", "tab:v2", "tab:stage"]

def main() -> None:
    source = MASTER.read_text(encoding="utf-8")
    main_text = source
    figure_blocks: dict[str, str] = {}
    table_blocks: dict[str, str] = {}

    for match in re.finditer(r"\\begin\{figure\}(?:\[[^]]+\])?.*?\\end\{figure\}", source, re.S):
        block = match.group()
        label = re.search(r"\\label\{([^}]+)\}", block)
        if label and label.group(1) in SUPP_FIGURES:
            figure_blocks[label.group(1)] = block
            main_text = main_text.replace(block, "")

    for match in re.finditer(r"\\begin\{table\}(?:\[[^]]+\])?.*?\\end\{table\}", source, re.S):
        block = match.group()
        label = re.search(r"\\label\{([^}]+)\}", block)
        if label and label.group(1) in SUPP_TABLES:
            table_blocks[label.group(1)] = block
            main_text = main_text.replace(block, "")

    assert set(figure_blocks) == set(SUPP_FIGURES), set(SUPP_FIGURES)-set(figure_blocks)
    assert set(table_blocks) == set(SUPP_TABLES), set(SUPP_TABLES)-set(table_blocks)

    # Remove a landscape wrapper only when its figure moved to SI. Some such
    # wrappers also contain an explanatory paragraph, which stays in main.
    def unwrap_empty_landscape(match: re.Match[str]) -> str:
        inner = match.group(1)
        return inner if "\\begin{figure}" not in inner and "\\begin{table}" not in inner else match.group()
    main_text = re.sub(r"\\begin\{landscape\}(.*?)\\end\{landscape\}", unwrap_empty_landscape, main_text, flags=re.S)

    for num, label in enumerate(SUPP_FIGURES, start=1):
        main_text = main_text.replace(r"Figure~\ref{" + label + "}", f"Supplementary Fig.~S{num}")
        main_text = main_text.replace(r"Fig.~\ref{" + label + "}", f"Supplementary Fig.~S{num}")
    for num, label in enumerate(SUPP_TABLES, start=1):
        main_text = main_text.replace(r"Table~\ref{" + label + "}", f"Supplementary Table~S{num}")

    assert main_text.count(r"\begin{figure}") == 6
    assert main_text.count(r"\begin{table}") == 2
    assert main_text.count(r"\begin{landscape}") == main_text.count(r"\end{landscape}")
    for label in SUPP_FIGURES + SUPP_TABLES:
        assert not re.search(r"\\(?:label|ref)\{" + re.escape(label) + r"\}", main_text), label

    header = r"""\documentclass[11pt,a4paper]{article}
\usepackage[T1]{fontenc}
\usepackage{mathptmx}
\usepackage[margin=22mm]{geometry}
\usepackage{amsmath,amssymb,graphicx,booktabs,tabularx,array,float,pdflscape}
\usepackage{microtype}
\usepackage[hidelinks]{hyperref}
\usepackage{url}
\usepackage[font=small,labelfont=bf]{caption}
\newcommand{\figdir}{figures}
\renewcommand{\thefigure}{S\arabic{figure}}
\renewcommand{\thetable}{S\arabic{table}}
\title{Supplementary Information: Historically Constrained Aircraft Design with Language Models}
\author{Ehsan Roohi}
\date{}
\begin{document}
\maketitle
\noindent These source-backed figures and detailed computational tables accompany the main article. Model-authored V0 plates are proposals, not fabricated aircraft; the Wright three-view is a researcher lifting-surface reconstruction. Numerical digits support reproducibility, not measurement precision.
\section*{Supplementary figures}
"""
    parts = [header]
    for label in SUPP_FIGURES:
        block = figure_blocks[label]
        if label in {"fig:wrightthree", "fig:astra", "fig:fable", "fig:opus"}:
            parts.append("\\begin{landscape}\n" + block + "\n\\end{landscape}\n")
        else:
            parts.append(block + "\n")
    parts.append("\\section*{Supplementary tables}\n")
    parts.extend(table_blocks[label] + "\n" for label in SUPP_TABLES)
    parts.append("\\end{document}\n")

    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "figures").mkdir(exist_ok=True)
    for asset in (PREVIOUS / "figures").iterdir():
        if asset.is_file() and asset.name != "configuration_comparison_v2.png":
            shutil.copy2(asset, OUT / "figures" / asset.name)
    shutil.copy2(ROOT / "output/figures_v2/configuration_comparison_v3.png", OUT / "figures/configuration_comparison_v3.png")
    for name in ("threeview_manifest.json", "references_scientific_reports.tex"):
        shutil.copy2(PREVIOUS / name, OUT / name)
    (OUT / "audit_data").mkdir(exist_ok=True)
    audit_records = {
        "v1_common_condition.json": ROOT / "analysis/results/aircraft_pilot_selected_v1.json",
        "v1_direct_retrim.json": ROOT / "analysis/results/retrim_v2_attempt01/summary.json",
        "wright_reference_statistic.json": ROOT / "analysis/results/wright_screening_v1.json",
        "wright_fourway_screen.json": ROOT / "analysis/results/four_aircraft_comparison01/summary.json",
        "v2_longitudinal_retrim.json": ROOT / "analysis/results/v2_trim_solve01/compact_report.json",
        "v2_subsystem_scenarios.json": ROOT / "analysis/results/v2_subsystems01/summary.json",
    }
    for filename, source_path in audit_records.items():
        shutil.copy2(source_path, OUT / "audit_data" / filename)
    (OUT / "main.tex").write_text(main_text, encoding="utf-8")
    (OUT / "supplementary.tex").write_text("\n".join(parts), encoding="utf-8")
    print("Generated Scientific Reports package: 6 main figures + 2 main tables; 6 SI figures + 7 SI tables")

if __name__ == "__main__":
    main()
