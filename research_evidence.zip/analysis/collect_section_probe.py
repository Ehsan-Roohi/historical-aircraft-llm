"""Recheck the retained synthetic section probe directly from force files."""
import hashlib
import json
from pathlib import Path
from avl_reference_gate import parse

ROOT=Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    folder=ROOT/'analysis/results/avl_section_probe01'
    summary=folder/'summary.json'; run=json.loads(summary.read_bytes())
    if not run['complete'] or len(run['records'])!=8: raise ValueError('Incomplete probe')
    if sha(ROOT/'analysis/tools/avl/avl352.exe')!=run['solver_sha256']: raise ValueError('Solver changed')
    rows=[]
    for r in run['records']:
        case=folder/r['case']
        for file,key in [('wing.avl','geometry_sha256'),('commands.txt','commands_sha256'),('forces.txt','forces_sha256')]:
            if sha(case/file)!=r[key]: raise ValueError('Hash mismatch '+r['case']+' '+file)
        if r['section']=='eiffel10_raw':
            if sha(case/'section.dat')!=run['section_source_sha256']: raise ValueError('Section changed')
            if (case/'stdout.txt').read_text(encoding='utf-8').count('Reading airfoil from file: section.dat')!=2:
                raise ValueError('Missing two AFILE read confirmations')
        text=(case/'forces.txt').read_text()
        values={key:parse(text,key) for key in r['coefficients']}
        if values!=r['coefficients']: raise ValueError('Force summary mismatch')
        for key,expected in [('Sref',10),('Cref',1),('Bref',10),('Xref',.25),('Yref',0),('Zref',0)]:
            if abs(parse(text,key)-expected)>1e-9: raise ValueError('Reference mismatch')
        rows.append(r)
    comparisons=[]
    for section in ['flat','eiffel10_raw']:
        for alpha in [0,4]:
            coarse=next(r for r in rows if r['section']==section and r['requested_alpha_deg']==alpha and r['nc']==4)['coefficients']
            fine=next(r for r in rows if r['section']==section and r['requested_alpha_deg']==alpha and r['nc']==8)['coefficients']
            comparisons.append({'section':section,'alpha_deg':alpha,'fine_minus_coarse':{k:fine[k]-coarse[k] for k in ['CLtot','CDind','Cmtot']},
                                'relative_change_percent':{k:100*(fine[k]-coarse[k])/abs(coarse[k]) if coarse[k]!=0 else None for k in ['CLtot','CDind','Cmtot']}})
    result={'scope':'Synthetic rectangular-wing input/mesh probe only; no Wright geometry or empirical validation',
            'source_summary_sha256':sha(summary),'verified_force_files':len(rows),'comparisons':comparisons,
            'acceptance':'No physical accuracy threshold or convergence order assigned from two meshes',
            'not_covered':['AVL internal spline independently reconstructed','normalized-section equivalence','Wright biplane/canard interactions','viscous drag or stall','as-tested shape','flight capability']}
    (ROOT/'analysis/results/section_probe_audit_v1.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
