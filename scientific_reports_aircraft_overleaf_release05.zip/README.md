# Historical-aircraft LLM manuscript: dynamic-gate revision

Compile main.tex and supplementary.tex separately with pdfLaTeX. The main document has seven figures and two tables; the supplement has six figures and nine tables. The new Table S9 reports a reduced two-state alpha/pitch-rate sign screen, not installed-aircraft eigenmodes. The missing full inertia and unsteady/lateral derivatives are not silently zero-filled. Figure sources are unchanged from release04.

The full research record and model-feedback prompts are versioned in the public project tag aircraft-sr-2026-09-28-r3. The author should compile and visually proof both documents before journal submission. No flightworthiness or journal acceptance is claimed.
