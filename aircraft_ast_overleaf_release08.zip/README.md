# Historical-aircraft LLM manuscript: V11b audit release

Compile `main.tex` and `supplementary.tex` separately with pdfLaTeX. The main
paper contains seven figures and three tables; the supplement has six figures
and eleven tables. The added main-text table distinguishes the V11b model
responses from independently checked arithmetic. `V11_RESPONSE_GATE.md` and
the two V11 audit JSON files explain the full-context feedback round. No V3
or V11b full-aircraft three-view, installed trim, dynamic-mode result or flight
acceptance is claimed. The current research record is at tag
`aircraft-ast-2026-09-28-g5`; the older `research_evidence.zip` remains the R5
snapshot, with later files available as separate paths at G5. This package is
an updated research manuscript for review, **not a submission-ready proof of
flight**. Both TeX documents need compilation and visual proof before journal
submission; no TeX compiler was available in the local workspace for this
release.
