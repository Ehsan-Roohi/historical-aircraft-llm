# Revision notes: draft 27 → Journal of Aircraft submission draft (1 Oct 2026)

## What was done
- **Format:** moved to the AIAA journal template (`new-aiaa.cls`, `journal` option: 10 pt, double-spaced, single column, Roman-numeral sections, "Fig."/"Eq." style). The references are in `references.bib` and are formatted and ordered by first citation through `new-aiaa.bst`.
- **Title:** shortened to 10 words: *Language-Model Aircraft Concepts from Pre-1899 Sources: A Flight-Mechanics Audit*. AIAA's limit is 12 words.
- **Abstract:** 197 words in one paragraph, with no acronyms or citations, as AIAA requires (100–200 words).
- **Nomenclature:** now complete with units, as AIAA requires. Symbol definitions were removed from the running text.
- **Length:** draft 27 had ≈25,600 words, 18 figures and 23 tables. The main text now has ≈5,900 words of running text, 6 figures and 5 tables. That is ≈10,100 words including figure/table equivalents (450 words per full-width display), or ≈11,700 if the abstract, nomenclature and references are also counted. AIAA's guideline is 10,000–12,000.
- **Supplemental Material** (`supplementary.tex`, 18 pp.): holds everything that was moved out of the main text (18 figures, 18 tables). No result was deleted.
- **New presentation devices (please approve):**
  - Evidence levels E0–E4 and evaluation gates G1–G6. These replace the hundreds of sentence-level caveats in draft 27; they summarize what draft 27 already said and add no new analysis.
  - Fig. 1, a workflow diagram in TikZ, editable in the `.tex` source.
  - Fig. 6, which plots the existing V16 audit data (`audit_data/v16/...`). The script is `figures/make_fable_v16_envelope.py`.
  - Table 5, an evidence matrix.
  - Numbered conclusions.

## Corrections made while rewriting
1. The draft's Introduction quoted the **superseded** Fable V15 margin of 0.53–1.23 %. Only the corrected value (0.97 % fine / 1.08 % coarse) is now reported. The superseded value is mentioned once, in Supp. S6.B.
2. The AVL component-identifier rule was cited to Katz & Plotkin (ref22). It now cites the AVL primer.
3. The two AVL primer entries (refs 20 and 40) were merged into one.
4. Non-archival web sources were removed from the reference list, following AIAA's policy. These were the Franklin Institute page, the Wright Flyer Project structural-test page, and the GitHub repo. The GitHub repo now appears only in the Data Availability text.
5. The FAIR (Wilkinson) and NeurIPS-reproducibility (Pineau) references were dropped; they were not needed for a JoA audience.
6. Two references were added: Raymer (*Aircraft Design*) and Etkin & Reid (*Dynamics of Flight*), for standard design-closure and static-margin definitions.
7. Internal process details (Unity job IDs, "post-G8", draft numbers, file names) were removed from the main text.
8. Spelling was converted to American English (center, centerline, meters, disk).

## Where draft-27 material went
| Draft 27 | New location |
|---|---|
| Intro + I.A Wright history | Main §I (condensed) + Supp S1.A |
| I.B Wright derivative table, pilot-in-loop | Supp S1.B (Table S1) |
| II.A design experiment, version table | Main §II, Table 1 (now covers all phases V0–V16) |
| V0 plates + keys | Main Fig. 2 (labeled details) + Supp S2 (full plates, keys) |
| Wright photo, 3-view, sensitivity | Supp Figs. S1–S3 |
| V1 plan comparison (v3) | Main Fig. 3; older v2 plate left in archive only |
| V2 three-views | Main Fig. 4 (combined) |
| II.B definitions, equations | Main §III + Nomenclature |
| Force–moment schematic; V2 force plot | Supp Figs. S7, S9 |
| V1 results (interpolated, loads, residuals, stability) | Main §IV, Table 2; details Supp S3 (Tables S2–S5, Fig. S8) |
| V2 results, derivative gate, reduced 2-state screen | Main §V.A, Table 3; Supp S4 (Tables S6–S8) |
| V3–V13 (V3, V11b, V12/V13, ground, clearance, inertia) | Main §V.B; Supp S5 (Tables S9–S10) |
| V15 six-axis, correction, lateral/rate tables | Main §VI.A; Supp S6 (Tables S11–S13) |
| Loading envelope, tail trade, structural loop, braced tail | Main §VI.B–C, Table 4, Fig. 5; Supp S7 (Tables S14–S16) |
| V16 loading, sweep, power, Astra/Opus propellers | Main §VI.D–F, Fig. 6; Supp S8 (Tables S17–S18) |
| Discussion; "strongest design"; architecture table | Main §VII (Table 5 replaces the V1 architecture table) |

## Open items for the author before submission
1. **Author footnote:** add your AIAA member grade if you have one.
2. **Funding and conflict-of-interest statements:** confirm them.
3. **AI disclosure:** this rewrite was produced with Anthropic's Claude, running under the identifier `claude-opus-5-5`. That is the same identifier as one of the evaluated models, and the same model family as a second (`claude-fable-5-1`).
   - No result, number or ranking was changed; every value traces to draft 27 or its audit files.
   - You may still wish to (a) re-read the ranking language in §VII.A and Conclusions 2–4 yourself, and (b) disclose this in the cover letter.
   - The Acknowledgments already state Claude's role. Confirm the wording.
4. **Data:** mint a persistent identifier (e.g., a Zenodo DOI from the GitHub release) and add the V14–V16 records to it. Then update the Data Availability paragraph.
5. **References:** do a final source-to-entry check, especially:
   - AIAA Paper numbers;
   - the NASM web record;
   - the Wright 1901 volume and month;
   - Strauss 2025 (supplement only).

   Note that the official `new-aiaa.bst` prints DOIs as "doi:".
6. **Fig. 5 artwork:** it still says "RESEARCHER CONCEPT", while the text says "evaluator". Optionally relabel the figure.
7. **Editor inquiry:** `EDITOR_INQUIRY_DRAFT.txt` in draft 27 describes a 25,600-word paper. It is now obsolete; if you still send an inquiry, describe the ≈11k-word version.
8. **Strongest scientific addition, if time allows:**
   - Do a component drag build-up.
   - Calibrate the AVL + drag + efficiency chain against the Ames 1903 replica data.

   Together these would turn the power verdicts from scenarios into estimates. Reviewers are likely to raise this, together with n = 3 and the evaluator-designed tail.

## Build
- **Overleaf:** set `main.tex` as the main document. Compile with pdfLaTeX; BibTeX runs automatically.
- **Supplement:** switch the main document to `supplementary.tex` to compile it.
- **Locally:** run `pdflatex` → `bibtex` → `pdflatex` → `pdflatex`.
- **Fig. 6:** to regenerate it, run `python3 figures/make_fable_v16_envelope.py` from inside `figures/`.
