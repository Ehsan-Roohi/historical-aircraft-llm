"""Fig. 7: Fable V16 conditional surface-model results.

All values are copied from the draft-27 audit archive:
  audit_data/v16/fable_v16_surface_retrim01/summary.json   (panel a)
  audit_data/v16/power_speed/fable_v16_power_sensitivity01.json and
  audit_data/v16/power_speed/fable_v16_speed_screen01/power_audit.json (panel b)
No value is fitted, interpolated or extrapolated.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["STIXGeneral", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 9,
    "axes.linewidth": 0.6,
    "axes.edgecolor": "#52514e",
    "axes.labelcolor": "#0b0b0b",
    "xtick.color": "#52514e",
    "ytick.color": "#52514e",
    "xtick.major.width": 0.6,
    "ytick.major.width": 0.6,
    "legend.frameon": False,
})

BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
INK, MUTED, GRID = "#0b0b0b", "#52514e", "#e4e3df"

# (pilot kg, seat x m, fuel kg, mass kg, x_CG m, SM % c_ref)
cases = [
    (75, 0.10, 8, 365.106, 1.5907, 7.006),
    (75, 0.15, 8, 365.106, 1.6010, 6.423),
    (75, 0.05, 8, 365.106, 1.5804, 7.589),
    (75, 0.10, 0, 357.106, 1.5905, 7.039),
    (65, 0.15, 8, 355.106, 1.6419, 4.006),
    (65, 0.15, 0, 347.106, 1.6428, 3.978),
    (85, 0.05, 8, 375.106, 1.5396, 10.031),
    (85, 0.05, 0, 367.106, 1.5383, 10.122),
]
style = {65: (AQUA, "s", "65 kg pilot"), 75: (BLUE, "o", "75 kg pilot"),
         85: (ORANGE, "^", "85 kg pilot")}

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(6.5, 2.75),
                               gridspec_kw={"wspace": 0.34})

# ---- (a) static margin versus CG station -------------------------------
for pilot in (65, 75, 85):
    col, mk, lab = style[pilot]
    for p, sx, fuel, m, xcg, sm in cases:
        if p != pilot:
            continue
        if fuel == 8:   # filled marker: 8 kg fuel
            ax1.plot(xcg, sm, linestyle="none", marker=mk, markersize=6.0,
                     markeredgewidth=0.8, markeredgecolor=col,
                     markerfacecolor=col, zorder=3)
        else:           # larger outline drawn on top: 0 kg fuel
            ax1.plot(xcg, sm, linestyle="none", marker=mk, markersize=9.5,
                     markeredgewidth=1.1, markeredgecolor=col,
                     markerfacecolor="none", zorder=4)
    ax1.plot([], [], linestyle="none", marker=mk, markersize=6.5,
             color=col, label=lab)
ax1.plot([], [], linestyle="none", marker="o", markersize=6.0,
         color=MUTED, label="filled: 8 kg fuel")
ax1.plot([], [], linestyle="none", marker="o", markersize=9.5,
         markerfacecolor="none", markeredgecolor=MUTED, label="outline: 0 kg fuel")
ax1.axhline(3.0, color=MUTED, linewidth=0.9, linestyle=(0, (4, 3)), zorder=1)
ax1.text(1.5365, 3.25, "3% exploratory screen", fontsize=7.5, color=MUTED,
         ha="left", va="bottom")
ax1.set_xlim(1.528, 1.655)
ax1.set_ylim(0, 12)
ax1.set_xlabel(r"$x_{CG}$, m (model frame, aft positive)")
ax1.set_ylabel(r"Surface-model $SM$, % $c_{\mathrm{ref}}$")
ax1.grid(axis="y", color=GRID, linewidth=0.5)
ax1.set_axisbelow(True)
ax1.spines[["top", "right"]].set_visible(False)
ax1.annotate("min. 3.98%", xy=(1.6428, 3.978), xytext=(1.618, 1.2),
             fontsize=7.5, color=INK,
             arrowprops=dict(arrowstyle="-", color=MUTED, linewidth=0.6))
ax1.legend(loc="upper right", fontsize=7.2, handletextpad=0.3,
           borderaxespad=0.2, labelspacing=0.3)
ax1.set_title("(a) Eight loading states, 13 m/s", fontsize=9, loc="left")

# ---- (b) heavy-case shaft power versus speed -----------------------------
avail = 20.045
v = [12, 13, 16]
p_h = [16.362, 18.053, 26.037]
ax2.axhline(avail, color=INK, linewidth=1.0)
ax2.text(15.95, avail + 0.35, "assumed available 20.05 kW", fontsize=7.5,
         color=INK, ha="right", va="bottom")
ax2.axhline(avail / 1.15, color=MUTED, linewidth=0.9, linestyle=(0, (4, 3)))
ax2.text(15.95, avail / 1.15 - 0.4, "15% reserve limit 17.43 kW", fontsize=7.5,
         color=MUTED, ha="right", va="top")
ax2.plot(v, p_h, linestyle="none", marker="o", markersize=6.5, color=BLUE,
         zorder=3, label="evaluator hybrid demand")
ax2.plot([13], [17.356], linestyle="none", marker="D", markersize=5.5,
         markerfacecolor="white", markeredgecolor=ORANGE, markeredgewidth=1.1,
         zorder=3, label="model-printed demand")
for x, y, t, dy, va in [(12, 16.362, "16.36", -0.55, "top"),
                        (13, 18.053, "18.05", 0.55, "bottom"),
                        (16, 26.037, "26.04", -0.55, "top")]:
    ax2.text(x + (0.12 if x < 16 else -0.12), y + dy, t, fontsize=7.5,
             color=INK, ha="left" if x < 16 else "right", va=va)
ax2.text(12.05, 23.6, r"12 m/s: $C_L=0.99$, $\alpha=9.1^\circ$;" "\nstall margin unknown",
         fontsize=7.2, color=MUTED, ha="left", va="top")
ax2.set_xlim(11.5, 16.5)
ax2.set_xticks([12, 13, 14, 15, 16])
ax2.set_ylim(12, 28)
ax2.set_xlabel(r"Flight speed $V$, m/s")
ax2.set_ylabel(r"Shaft power, kW")
ax2.grid(axis="y", color=GRID, linewidth=0.5)
ax2.set_axisbelow(True)
ax2.spines[["top", "right"]].set_visible(False)
ax2.legend(loc="lower right", fontsize=7.2, handletextpad=0.3,
           borderaxespad=0.2, labelspacing=0.3)
ax2.set_title("(b) Heavy case, 375.1 kg", fontsize=9, loc="left")

fig.savefig("fable_v16_envelope.pdf", bbox_inches="tight")
fig.savefig("fable_v16_envelope.png", dpi=600, bbox_inches="tight")
print("ok")
