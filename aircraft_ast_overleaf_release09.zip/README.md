# Historical-aircraft LLM manuscript: V12/V13 audit release

Compile `main.tex` and `supplementary.tex` separately with pdfLaTeX. The main
paper contains seven figures and three tables; the supplement has six figures
and eleven tables. The main text now covers the V12 non-minimal installation
responses and V13 Fable arithmetic correction. `V11_RESPONSE_GATE.md`,
`V12_V13_RESPONSE_GATE.md` and the audit JSON files identify model claims and
independent checks. No V3--V13 complete geometry-gated three-view, installed
trim, dynamic-mode result or flight acceptance is claimed. The current
research record is at tag `aircraft-ast-2026-09-28-g6`; the older
`research_evidence.zip` remains the R5
snapshot, with later files available as separate paths at G5. This package is
an updated research manuscript for review, **not a submission-ready proof of
flight**. Both TeX documents need compilation and visual proof before journal
submission; no TeX compiler was available in the local workspace for this
release.
