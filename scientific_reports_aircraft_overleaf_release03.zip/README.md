# Aircraft LLM paper: revised Scientific Reports review package

Compile `main.tex` with pdfLaTeX. To obtain the separate supplement, compile `supplementary.tex` as root. The main file has seven figures and two tables; the supplement has six figures and eight tables.

Figure 7 separates independent conditional Astra/Opus V2 loads from Fable's unverified model claim. Table 2 is explicitly V1. The new derivative audit does not assign numerical pitch-rate or angle-of-attack-rate derivatives without supporting runs/data.

`audit_data/` contains compact numerical source records; the full prompt/response/code archive is at https://github.com/Ehsan-Roohi/historical-aircraft-llm/tree/aircraft-sr-2026-09-28 .

The author should compile and visually proof both TeX roots, check all citations and declarations, and apply the selected journal's current submission template before submission. No flightworthiness or journal acceptance is claimed.
